import { useState, useCallback, useEffect } from "react";
import { Save, FileText, Eye, EyeOff, ShieldCheck, ShieldAlert, Loader, AlertCircle, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { platformConfig } from "@/lib/data";
import type { JobPlatform } from "@/lib/data";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";

/*
 * ==========================================
 * УПРОЩЁННЫЕ НАСТРОЙКИ (v1.3.5)
 * ==========================================
 * Исправлено: реальное сохранение в БД + честная проверка входа
 */

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  searchQuery: string;
  region: string;
  salaryFrom: string;
  salaryTo: string;
  experience: string;
  remote: boolean;
  coverLetter: string;
  maxApplies: number;
  platforms: Record<JobPlatform, { enabled: boolean; login: string; password: string }>;
}

const allPlatforms = Object.keys(platformConfig) as JobPlatform[];

const initialForm: FormState = {
  fullName: "Иван Петров",
  email: "ivan@example.com",
  phone: "+7 (999) 123-45-67",
  searchQuery: "Python разработчик",
  region: "Москва",
  salaryFrom: "200000",
  salaryTo: "500000",
  experience: "between1And3",
  remote: true,
  coverLetter: `Здравствуйте!\n\nМеня заинтересовала вакансия "{position}" в компании {company}.\n\nУ меня есть релевантный опыт и я хотел бы стать частью вашей команды.\n\nС уважением,\n{candidate_name}`,
  maxApplies: 20,
  platforms: Object.fromEntries(
    allPlatforms.map((p) => [p, { enabled: p === "hh", login: "", password: "" }])
  ) as Record<JobPlatform, { enabled: boolean; login: string; password: string }>,
};

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h3 className="text-base font-semibold text-hf-red">{title}</h3>
      {subtitle && <p className="text-xs text-hf-text-secondary mt-0.5">{subtitle}</p>}
    </div>
  );
}

function Input({ label, type = "text", value, onChange, placeholder }: {
  label: string; type?: string; value: string; onChange: (val: string) => void; placeholder?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      <input
        type={type}
        className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

function PasswordInput({ label, value, onChange }: { label: string; value: string; onChange: (val: string) => void }) {
  const [show, setShow] = useState(false);
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 pr-10 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-hf-text-muted hover:text-hf-text-primary transition-colors p-1"
          tabIndex={-1}
        >
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
    </div>
  );
}

function Toggle({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div onClick={onChange} className={cn("w-10 h-6 rounded-full transition-colors relative flex-shrink-0 mt-0.5", checked ? "bg-hf-red" : "bg-hf-border-subtle")}>
        <span className={cn("absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-[18px]" : "translate-x-0.5")} />
      </div>
      <div>
        <span className="text-sm text-hf-text-primary group-hover:text-hf-red transition-colors">{label}</span>
        {description && <p className="text-xs text-hf-text-secondary mt-0.5">{description}</p>}
      </div>
    </label>
  );
}

export default function Settings() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [checkingLogin, setCheckingLogin] = useState<Record<string, "idle" | "loading" | "success" | "error" | "info">>({});
  const [checkMessage, setCheckMessage] = useState<Record<string, string>>({});
  const navigate = useNavigate();

  // Загрузка существующих настроек из БД
  const { data: profileData } = trpc.profile.get.useQuery({ userId: 1 });

  useEffect(() => {
    if (profileData) {
      setForm(prev => ({
        ...prev,
        fullName: profileData.fullName || prev.fullName,
        email: profileData.email || prev.email,
        phone: profileData.phone || prev.phone,
        region: profileData.region || prev.region,
        experience: profileData.experience || prev.experience,
        remote: profileData.remoteOnly ?? prev.remote,
        coverLetter: profileData.coverLetterTemplate || prev.coverLetter,
        salaryFrom: profileData.salaryFrom ? String(profileData.salaryFrom) : prev.salaryFrom,
        salaryTo: profileData.salaryTo ? String(profileData.salaryTo) : prev.salaryTo,
        // Загружаем maxApplies и searchQuery из jsonb settings
        maxApplies: (profileData.settings as Record<string, unknown>)?.maxApplies ? Number((profileData.settings as Record<string, unknown>).maxApplies) : prev.maxApplies,
        searchQuery: ((profileData.settings as Record<string, unknown>)?.searchQuery as string) || prev.searchQuery,
        // Загружаем площадки
        platforms: Object.fromEntries(
          allPlatforms.map(key => {
            const fields = getPlatformFields(key);
            const settings = (profileData.settings as Record<string, unknown> || {}) as Record<string, { enabled?: boolean }>;
            return [key, {
              enabled: settings[key]?.enabled || false,
              login: (profileData as Record<string, unknown>)[fields.login] as string || "",
              password: (profileData as Record<string, unknown>)[fields.password] as string || "",
            }];
          })
        ) as Record<JobPlatform, { enabled: boolean; login: string; password: string }>,
      }));
    }
  }, [profileData]);

  // tRPC mutations
  const saveMutation = trpc.profile.saveSettings.useMutation({
    onSuccess: () => {
      setSaved(true);
      setSaveError(null);
      setTimeout(() => setSaved(false), 3000);
    },
    onError: (err) => {
      setSaveError(err.message || "Ошибка сохранения");
      setTimeout(() => setSaveError(null), 5000);
    },
  });

  const checkMutation = trpc.profile.checkPlatformLogin.useMutation({
    onSuccess: (data, variables) => {
      setCheckingLogin(prev => ({ ...prev, [variables.platform]: data.success ? "success" : "error" }));
      if (data.message) {
        setCheckMessage(prev => ({ ...prev, [variables.platform]: data.message }));
      }
      // Сброс статуса через 5 сек
      setTimeout(() => {
        setCheckingLogin(prev => ({ ...prev, [variables.platform]: "idle" }));
        setCheckMessage(prev => { const n = { ...prev }; delete n[variables.platform]; return n; });
      }, 5000);
    },
    onError: (err, variables) => {
      setCheckingLogin(prev => ({ ...prev, [variables.platform]: "error" }));
      setCheckMessage(prev => ({ ...prev, [variables.platform]: err.message || "Ошибка проверки" }));
      setTimeout(() => {
        setCheckingLogin(prev => ({ ...prev, [variables.platform]: "idle" }));
        setCheckMessage(prev => { const n = { ...prev }; delete n[variables.platform]; return n; });
      }, 5000);
    },
  });

  // Проверка входа — реальная валидация через API (v1.3.5: убран фейк)
  const handleCheckLogin = useCallback((platformKey: JobPlatform, login: string, password: string) => {
    if (!login.trim() || !password.trim()) return;
    setCheckingLogin(prev => ({ ...prev, [platformKey]: "loading" }));
    checkMutation.mutate({ platform: platformKey, login, password });
  }, [checkMutation]);

  const update = <K extends keyof Omit<FormState, "platforms">>(field: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  };

  const updatePlatform = (platform: JobPlatform, key: "enabled" | "login" | "password", value: boolean | string) => {
    setForm((prev) => ({
      ...prev,
      platforms: { ...prev.platforms, [platform]: { ...prev.platforms[platform], [key]: value } },
    }));
    setSaved(false);
  };

  // Реальное сохранение в БД
  const handleSave = () => {
    setSaveError(null);
    saveMutation.mutate({
      userId: 1, // TODO: из auth контекста
      fullName: form.fullName,
      email: form.email,
      phone: form.phone,
      searchQuery: form.searchQuery,
      region: form.region,
      salaryFrom: form.salaryFrom,
      salaryTo: form.salaryTo,
      experience: form.experience,
      remote: form.remote,
      coverLetter: form.coverLetter,
      maxApplies: form.maxApplies,
      platforms: form.platforms,
    });
  };

  // Хелпер для маппинга полей платформ
  function getPlatformFields(key: string): { login: string; password: string } {
    const map: Record<string, { login: string; password: string }> = {
      hh: { login: "hhLogin", password: "hhPassword" },
      zarplata: { login: "zarplataLogin", password: "zarplataPassword" },
      rabota: { login: "rabotaLogin", password: "rabotaPassword" },
      superjob: { login: "superjobLogin", password: "superjobPassword" },
      yandex_smena: { login: "yandexSmenaLogin", password: "yandexSmenaPassword" },
      karierist: { login: "karieristLogin", password: "karieristPassword" },
      rabotaru: { login: "rabotaruLogin", password: "rabotaruPassword" },
      avito: { login: "avitoLogin", password: "avitoPassword" },
      trudvsem: { login: "trudvsemLogin", password: "trudvsemPassword" },
      gorodrabot: { login: "gorodrabotLogin", password: "gorodrabotPassword" },
    };
    return map[key] || { login: "", password: "" };
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Настройки</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">Профиль, поиск, площадки</p>
        </div>
        <div className="flex items-center gap-3">
          {saveError && (
            <span className="flex items-center gap-1 text-xs text-hf-red">
              <AlertCircle size={14} /> {saveError}
            </span>
          )}
          <button
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
              saved ? "bg-hf-green text-white" : "bg-hf-red text-white hover:brightness-110",
              saveMutation.isPending && "opacity-70 cursor-wait"
            )}
          >
            {saveMutation.isPending ? <Loader size={14} className="animate-spin" /> : <Save size={14} />}
            {saved ? "Сохранено!" : saveMutation.isPending ? "Сохранение..." : "Сохранить"}
          </button>
        </div>
      </div>

      {/* Profile */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Профиль" subtitle="Ваши контактные данные для откликов" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="ФИО" value={form.fullName} onChange={(v) => update("fullName", v)} />
          <Input label="Email" type="email" value={form.email} onChange={(v) => update("email", v)} />
          <Input label="Телефон" value={form.phone} onChange={(v) => update("phone", v)} />
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Поиск" subtitle="Какие вакансии искать" />
        <div className="space-y-4">
          <Input label="Ключевые слова" value={form.searchQuery} onChange={(v) => update("searchQuery", v)} placeholder="Python разработчик" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Input label="Регион" value={form.region} onChange={(v) => update("region", v)} />
            <Input label="Зарплата от" type="number" value={form.salaryFrom} onChange={(v) => update("salaryFrom", v)} />
            <Input label="Зарплата до" type="number" value={form.salaryTo} onChange={(v) => update("salaryTo", v)} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label>
              <select value={form.experience} onChange={(e) => update("experience", e.target.value)} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors">
                <option value="noExperience">Нет опыта</option>
                <option value="between1And3">1-3 года</option>
                <option value="between3And6">3-6 лет</option>
                <option value="moreThan6">Более 6 лет</option>
              </select>
            </div>
            <div className="flex items-center pt-5">
              <Toggle label="Только удалённо" checked={form.remote} onChange={() => update("remote", !form.remote)} />
            </div>
          </div>
        </div>
      </div>

      {/* Cover Letter */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <FileText size={16} className="text-hf-red" />
          <h3 className="text-base font-semibold text-hf-red">Сопроводительное письмо</h3>
        </div>
        <p className="text-xs text-hf-text-secondary mb-3">
          Переменные: {"{company}"}, {"{position}"}, {"{candidate_name}"} — автозамена при отправке
        </p>
        <textarea
          className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors resize-none"
          rows={6}
          value={form.coverLetter}
          onChange={(e) => update("coverLetter", e.target.value)}
        />
      </div>

      {/* Platforms */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Площадки" subtitle="Выберите, где искать вакансии" />
        <div className="space-y-3">
          {allPlatforms.map((key) => {
            const cfg = platformConfig[key];
            const plat = form.platforms[key];
            return (
              <div key={key} className={cn("border rounded-lg p-3 transition-all", plat.enabled ? "border-hf-red/30 bg-hf-red/[0.02]" : "border-hf-border-subtle")}>
                <div className="flex items-center justify-between">
                  <Toggle label={cfg.label} checked={plat.enabled} onChange={() => updatePlatform(key, "enabled", !plat.enabled)} />
                  <span className={cn("text-[10px] px-2 py-0.5 rounded font-medium", cfg.bg, cfg.color)}>{cfg.domain}</span>
                </div>
                {plat.enabled && (
                  <div className="mt-3 pl-[52px] space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <Input label={`Логин`} value={plat.login} onChange={(v) => updatePlatform(key, "login", v)} />
                      <PasswordInput label={`Пароль`} value={plat.password} onChange={(v) => updatePlatform(key, "password", v)} />
                    </div>
                    {/* Check login button + status (v1.3.5 — реальная проверка) */}
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => handleCheckLogin(key, plat.login, plat.password)}
                          disabled={checkingLogin[key] === "loading" || !plat.login.trim() || !plat.password.trim()}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border",
                            checkingLogin[key] === "success" && "bg-hf-green/10 text-hf-green border-hf-green/20",
                            checkingLogin[key] === "error" && "bg-hf-red/10 text-hf-red border-hf-red/20",
                            checkingLogin[key] === "info" && "bg-blue-50 text-blue-600 border-blue-200",
                            (!checkingLogin[key] || checkingLogin[key] === "idle") && "bg-hf-highlight text-hf-text-secondary border-hf-border-subtle hover:text-hf-red hover:border-hf-red/30",
                            "disabled:opacity-50 disabled:cursor-not-allowed"
                          )}
                        >
                          {checkingLogin[key] === "loading" && <Loader size={12} className="animate-spin" />}
                          {checkingLogin[key] === "success" && <CheckCircle size={12} />}
                          {checkingLogin[key] === "error" && <ShieldAlert size={12} />}
                          {(!checkingLogin[key] || checkingLogin[key] === "idle") && <ShieldCheck size={12} />}
                          {checkingLogin[key] === "loading" ? "Проверка..." :
                           checkingLogin[key] === "success" ? "Формат OK" :
                           checkingLogin[key] === "error" ? "Ошибка" :
                           "Проверить вход"}
                        </button>
                        {checkingLogin[key] === "success" && (
                          <span className="text-[10px] text-hf-green flex items-center gap-1">
                            <CheckCircle size={10} /> Данные сохранены
                          </span>
                        )}
                        {checkingLogin[key] === "error" && (
                          <span className="text-[10px] text-hf-red flex items-center gap-1">
                            <AlertCircle size={10} /> {checkMessage[key] || "Проверьте логин и пароль"}
                          </span>
                        )}
                      </div>
                      {/* Сообщение от сервера с пояснением */}
                      {checkMessage[key] && checkingLogin[key] !== "error" && (
                        <div className="text-[10px] text-hf-text-secondary bg-hf-highlight rounded-lg px-3 py-2 border border-hf-border-subtle">
                          {checkMessage[key]}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Simple Bot Settings */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Настройки бота" subtitle="Простые параметры" />
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Макс. откликов за запуск</label>
              <input
                type="number"
                min={1}
                max={50}
                value={form.maxApplies}
                onChange={(e) => update("maxApplies", Number(e.target.value))}
                className="w-20 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red"
              />
            </div>
          </div>
          <p className="text-xs text-hf-text-muted">
            Все технические настройки (stealth, задержки, прокси) включены автоматически для безопасной работы.
            AI-анализ и генерация письма используют настройки из профиля.
          </p>
        </div>
      </div>

      {/* Resume link */}
      <div className="bg-hf-red/5 border border-hf-red/20 rounded-[10px] p-4 text-center">
        <p className="text-sm text-hf-text-secondary mb-2">Управление резюме</p>
        <button
          onClick={() => navigate("/resumes")}
          className="px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all"
        >
          Перейти к резюме
        </button>
      </div>
    </div>
  );
}

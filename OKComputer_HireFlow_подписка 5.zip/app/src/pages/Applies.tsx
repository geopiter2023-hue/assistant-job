import { useState, useMemo } from "react";
import { Check, X, Search, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { recentApplications } from "@/lib/data";
import type { Application } from "@/lib/data";
import PlatformBadge from "@/components/PlatformBadge";

function StatusBadge({ status, label }: { status: string; label: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium", status === "success" ? "bg-[#10B98120] text-hf-green" : "bg-[#EF444420] text-hf-red")}>
      {status === "success" ? <Check size={12} strokeWidth={2.5} /> : <X size={12} strokeWidth={2.5} />}{label}
    </span>
  );
}

function DetailModal({ app, onClose }: { app: Application; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[14px] p-6 max-w-md w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-hf-text-primary">Детали отклика</h3>
          <button onClick={onClose} className="text-hf-text-muted hover:text-hf-text-primary transition-colors"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <div><p className="text-xs text-hf-text-secondary uppercase">Вакансия</p><p className="text-sm text-hf-text-primary font-medium">{app.vacancy}</p></div>
          <div><p className="text-xs text-hf-text-secondary uppercase">Компания</p><p className="text-sm text-hf-text-primary">{app.company}</p></div>
          <div className="flex gap-6">
            <div><p className="text-xs text-hf-text-secondary uppercase">Статус</p><StatusBadge status={app.status} label={app.statusLabel} /></div>
            <div><p className="text-xs text-hf-text-secondary uppercase">Площадка</p><PlatformBadge platform={app.platform} /></div>
          </div>
          {app.salary && <div><p className="text-xs text-hf-text-secondary uppercase">Зарплата</p><p className="text-sm text-hf-green font-medium">{app.salary}</p></div>}
          {app.location && <div><p className="text-xs text-hf-text-secondary uppercase">Локация</p><p className="text-sm text-hf-text-primary">{app.location}</p></div>}
          {app.coverLetter && <div><p className="text-xs text-hf-text-secondary uppercase">Сопроводительное</p><div className="bg-hf-base rounded-lg p-3 mt-1"><p className="text-xs text-hf-text-secondary leading-relaxed">{app.coverLetter}</p></div></div>}
          <div><p className="text-xs text-hf-text-secondary uppercase">Время</p><p className="text-sm text-hf-text-muted">{app.timeAgo}</p></div>
        </div>
      </div>
    </div>
  );
}

export default function Applies() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "success" | "error">("all");
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  const filtered = useMemo(() => {
    return recentApplications.filter((a) => {
      const matchSearch = !search || a.vacancy.toLowerCase().includes(search.toLowerCase()) || a.company.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "all" || a.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [search, statusFilter]);

  const stats = {
    total: recentApplications.length,
    success: recentApplications.filter((a) => a.status === "success").length,
    error: recentApplications.filter((a) => a.status === "error").length,
    successRate: ((recentApplications.filter((a) => a.status === "success").length / recentApplications.length) * 100).toFixed(1),
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card"><p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p><p className="text-2xl font-bold text-hf-text-primary mt-1">{stats.total}</p></div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card"><p className="text-xs uppercase text-hf-text-secondary tracking-wider">Успешно</p><p className="text-2xl font-bold text-hf-green mt-1">{stats.success}</p></div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card"><p className="text-xs uppercase text-hf-text-secondary tracking-wider">Ошибок</p><p className="text-2xl font-bold text-hf-red mt-1">{stats.error}</p></div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card"><p className="text-xs uppercase text-hf-text-secondary tracking-wider">Успешность</p><p className="text-2xl font-bold text-hf-red mt-1">{stats.successRate}%</p></div>
      </div>

      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
            <input type="text" placeholder="Поиск по вакансии или компании..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg pl-9 pr-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors" />
          </div>
          <div className="flex gap-2">
            {(["all", "success", "error"] as const).map((s) => (
              <button key={s} onClick={() => setStatusFilter(s)} className={cn("px-3 py-2 rounded-lg text-xs font-medium transition-all", statusFilter === s ? (s === "success" ? "bg-hf-green text-white" : s === "error" ? "bg-hf-red text-white" : "bg-hf-red text-white") : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary")}>{s === "all" ? "Все" : s === "success" ? "Успешно" : "Ошибка"}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="hidden md:block bg-hf-elevated border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-hf-border-subtle">
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[100px]">СТАТУС</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ВАКАНСИЯ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">КОМПАНИЯ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ПЛОЩАДКА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАРПЛАТА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-right px-5 py-3">ВРЕМЯ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[60px]"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((app) => (
              <tr key={app.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-[#1E2A4260] transition-colors">
                <td className="px-5 py-3.5 text-center"><StatusBadge status={app.status} label={app.statusLabel} /></td>
                <td className="px-5 py-3.5"><span className="text-sm text-hf-red">{app.vacancy}</span></td>
                <td className="px-5 py-3.5 text-sm text-hf-text-primary">{app.company}</td>
                <td className="px-5 py-3.5 text-center"><PlatformBadge platform={app.platform} /></td>
                <td className="px-5 py-3.5 text-sm text-hf-green">{app.salary || "—"}</td>
                <td className="px-5 py-3.5 text-sm text-hf-text-muted text-right">{app.timeAgo}</td>
                <td className="px-5 py-3.5 text-center"><button onClick={() => setSelectedApp(app)} className="text-hf-text-muted hover:text-hf-red transition-colors"><Eye size={14} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {filtered.map((app) => (
          <button key={app.id} onClick={() => setSelectedApp(app)} className="w-full text-left bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card hover:bg-[#1E2A4230] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0"><span className="text-sm text-hf-red block truncate">{app.vacancy}</span><p className="text-xs text-hf-text-secondary mt-0.5">{app.company}</p></div>
              <StatusBadge status={app.status} label={app.statusLabel} />
            </div>
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-2"><PlatformBadge platform={app.platform} />{app.salary && <span className="text-xs text-hf-green">{app.salary}</span>}</div>
              <span className="text-xs text-hf-text-muted">{app.timeAgo}</span>
            </div>
          </button>
        ))}
      </div>

      {selectedApp && <DetailModal app={selectedApp} onClose={() => setSelectedApp(null)} />}
    </div>
  );
}

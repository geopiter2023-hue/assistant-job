import { useState } from "react";
import { Search, Zap, Bot, CheckCircle, Building2, MapPin, Wallet, Sparkles, FileText, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router";

/*
 * ==========================================
 * ПОЛНОСТЬЮ АВТОМАТИЧЕСКИЙ ОТКЛИК
 * ==========================================
 * 1 кнопка = поиск + AI-анализ + адаптация резюме + письмо + сохранение
 * Без выбора вакансий пользователем!
 */

interface ProcessedVacancy {
  vacancy: {
    id: string;
    title: string;
    company: string;
    salary: string;
    location: string;
    url: string;
  };
  analysis: {
    matchScore: number;
    keySkills: string[];
    aiSummary: string;
  };
  status: "processed" | "low_match" | "error";
  draftId?: number;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [query, setQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{
    totalFound: number;
    processed: number;
    lowMatch: number;
    errors: number;
    results: ProcessedVacancy[];
  } | null>(null);

  const autoMutation = trpc.auto.autoApply.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setIsProcessing(false);
    },
    onError: () => {
      setIsProcessing(false);
    },
  });

  const handleAutoApply = () => {
    if (!query.trim()) return;
    setIsProcessing(true);
    setResult(null);

    autoMutation.mutate({
      userId: user?.id ?? 1,
      query,
      platforms: ["hh"],
      resumeId: 1,
      candidateName: "Иван Петров",
      minMatchScore: 60,
      maxVacancies: 10,
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Title */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-hf-text-primary">Поиск вакансий</h1>
        <p className="text-sm text-hf-text-secondary mt-1">
          Введите должность — система найдёт вакансии, отберёт лучшие и подготовит отклики
        </p>
      </div>

      {/* Search Box */}
      <div className="bg-white border border-hf-border-subtle rounded-[12px] p-5 shadow-card">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
          <input
            type="text"
            placeholder="Python разработчик, QA инженер..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAutoApply()}
            className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg pl-10 pr-4 py-3 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
          />
        </div>

        {/* ONE BUTTON — ВСЁ ДЕЛАЕТ СИСТЕМА */}
        <button
          onClick={handleAutoApply}
          disabled={!query.trim() || isProcessing}
          className={cn(
            "w-full mt-4 py-3.5 rounded-lg text-sm font-bold text-white transition-all duration-200 flex items-center justify-center gap-2",
            isProcessing
              ? "bg-hf-text-muted cursor-wait"
              : "bg-hf-red hover:brightness-110 active:scale-[0.98] shadow-lg shadow-hf-red/25"
          )}
        >
          {isProcessing ? (
            <>
              <Bot size={16} className="animate-pulse" />
              Ищем → Анализируем → Адаптируем → Готово...
            </>
          ) : (
            <>
              <Zap size={16} />
              Найти и откликнуться
            </>
          )}
        </button>

        {/* Progress steps */}
        {isProcessing && (
          <div className="flex items-center justify-center gap-2 mt-3 text-[10px] text-hf-text-muted">
            <span className="flex items-center gap-0.5"><Search size={9} /> Поиск</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><Bot size={9} /> AI-анализ</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><FileText size={9} /> Резюме</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><Sparkles size={9} /> Письмо</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><CheckCircle size={9} /> Отклик</span>
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-4 animate-fade-in-up">
          {/* Summary */}
          <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle size={20} className="text-hf-green" />
              <h3 className="text-sm font-bold text-hf-text-primary">
                Готово! Обработано {result.totalFound} вакансий
              </h3>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-hf-green/10 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-hf-green">{result.processed}</p>
                <p className="text-[10px] text-hf-text-secondary mt-0.5">Подготовлено</p>
              </div>
              <div className="bg-hf-amber/10 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-hf-amber">{result.lowMatch}</p>
                <p className="text-[10px] text-hf-text-secondary mt-0.5">Низкое совпадение</p>
              </div>
              <div className="bg-hf-red/10 rounded-lg p-3 text-center">
                <p className="text-2xl font-bold text-hf-red">{result.errors}</p>
                <p className="text-[10px] text-hf-text-secondary mt-0.5">Ошибок</p>
              </div>
            </div>
          </div>

          {/* Processed vacancies */}
          {result.results.filter(r => r.status === "processed").length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-hf-text-primary flex items-center gap-2">
                <Sparkles size={15} className="text-hf-green" />
                Подготовленные отклики ({result.processed})
              </h3>

              {result.results
                .filter(r => r.status === "processed")
                .map((r) => (
                  <div key={r.vacancy.id} className="bg-white border border-hf-green/30 rounded-[10px] p-4 shadow-card">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-sm font-semibold text-hf-red">{r.vacancy.title}</h4>
                          <span className={cn(
                            "text-xs px-2 py-0.5 rounded-full font-bold",
                            r.analysis.matchScore >= 80 ? "bg-hf-green/10 text-hf-green" :
                            r.analysis.matchScore >= 60 ? "bg-hf-amber/10 text-hf-amber" :
                            "bg-hf-red/10 text-hf-red"
                          )}>
                            {r.analysis.matchScore}%
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5">
                          <span className="text-xs text-hf-text-secondary flex items-center gap-1">
                            <Building2 size={10} />{r.vacancy.company}
                          </span>
                          <span className="text-xs text-hf-text-secondary flex items-center gap-1">
                            <MapPin size={10} />{r.vacancy.location}
                          </span>
                          <span className="text-xs text-hf-text-secondary flex items-center gap-1">
                            <Wallet size={10} />{r.vacancy.salary}
                          </span>
                        </div>
                        <p className="text-xs text-hf-text-secondary mt-2 bg-hf-highlight rounded-lg p-2">
                          {r.analysis.aiSummary}
                        </p>
                        {r.analysis.keySkills.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {r.analysis.keySkills.slice(0, 5).map((skill, j) => (
                              <span key={j} className="text-[10px] px-2 py-0.5 bg-hf-red/10 text-hf-red rounded-full">{skill}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      <CheckCircle size={18} className="text-hf-green flex-shrink-0" />
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Low match vacancies */}
          {result.results.filter(r => r.status === "low_match").length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-hf-text-primary flex items-center gap-2">
                <AlertCircle size={15} className="text-hf-amber" />
                Низкое совпадение ({result.lowMatch})
              </h3>
              {result.results
                .filter(r => r.status === "low_match")
                .map((r) => (
                  <div key={r.vacancy.id} className="bg-white border border-hf-amber/20 rounded-[10px] p-4 shadow-card opacity-70">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-hf-text-primary">{r.vacancy.title}</h4>
                        <span className="text-xs text-hf-text-secondary">{r.vacancy.company}</span>
                      </div>
                      <span className="text-xs font-bold text-hf-amber">{r.analysis.matchScore}%</span>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={() => navigate("/applies")}
              className="flex-1 py-3 bg-hf-red text-white text-sm font-bold rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
            >
              <FileText size={16} /> Смотреть мои отклики
            </button>
            <button
              onClick={() => setResult(null)}
              className="px-4 py-3 bg-hf-base text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary transition-colors"
            >
              Новый поиск
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

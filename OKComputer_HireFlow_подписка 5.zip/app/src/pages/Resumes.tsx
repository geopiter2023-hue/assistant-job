import { useState, useEffect, useRef } from "react";
import { Plus, Trash2, Pencil, Star, Check, X, Upload, FileText, Loader } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";

interface Resume {
  id: string;
  title: string;
  summary: string;
  skills: string;
  experience: string;
  education: string;
  languages: string;
  desiredSalary: string;
  desiredPosition: string;
  isDefault: boolean;
  source?: "manual" | "file_upload";
}

/* ─── Resume Card ─── */
function ResumeCard({ resume, onEdit, onDelete, onSetDefault }: {
  resume: Resume;
  onEdit: (r: Resume) => void;
  onDelete: (id: string) => void;
  onSetDefault: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={cn(
      "bg-white border rounded-[10px] shadow-card transition-all",
      resume.isDefault ? "border-hf-red/40" : "border-hf-border-subtle"
    )}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-semibold text-hf-text-primary">{resume.title}</h3>
              {resume.isDefault && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-hf-red/20 text-hf-red border border-hf-red/30">
                  <Star size={10} /> По умолчанию
                </span>
              )}
              {resume.source === "file_upload" && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-hf-blue/10 text-hf-blue border border-hf-blue/20">
                  <FileText size={10} /> Из файла
                </span>
              )}
            </div>
            <p className="text-xs text-hf-text-secondary mt-1 line-clamp-2">{resume.summary}</p>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {!resume.isDefault && (
              <button onClick={() => onSetDefault(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-amber hover:bg-hf-amber/10 transition-colors" title="Сделать основным">
                <Star size={14} />
              </button>
            )}
            <button onClick={() => onEdit(resume)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 transition-colors" title="Редактировать">
              <Pencil size={14} />
            </button>
            <button onClick={() => onDelete(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 transition-colors" title="Удалить">
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {resume.skills.split(",").slice(0, 6).map((s) => (
            <span key={s.trim()} className="text-[11px] text-hf-text-secondary bg-hf-highlight px-2 py-0.5 rounded border border-hf-border-subtle">{s.trim()}</span>
          ))}
          {resume.skills.split(",").length > 6 && <span className="text-[11px] text-hf-text-muted">+{resume.skills.split(",").length - 6}</span>}
        </div>

        <button onClick={() => setExpanded(!expanded)} className="text-xs text-hf-red hover:underline mt-3 transition-colors">
          {expanded ? "Скрыть детали" : "Показать детали"}
        </button>

        {expanded && (
          <div className="mt-3 space-y-3 pt-3 border-t border-hf-border-subtle">
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</p><p className="text-xs text-hf-text-primary mt-1 whitespace-pre-line">{resume.experience}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</p><p className="text-xs text-hf-text-primary mt-1">{resume.education}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</p><p className="text-xs text-hf-text-primary mt-1">{resume.languages}</p></div>
            <div className="flex gap-4">
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Зарплата</p><p className="text-xs text-hf-green font-medium mt-1">{resume.desiredSalary}</p></div>
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Позиция</p><p className="text-xs text-hf-text-primary mt-1">{resume.desiredPosition}</p></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Resume Form ─── */
function ResumeForm({ initial, onSave, onCancel }: {
  initial?: Resume;
  onSave: (data: Omit<Resume, "id">) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    title: initial?.title ?? "",
    summary: initial?.summary ?? "",
    skills: initial?.skills ?? "",
    experience: initial?.experience ?? "",
    education: initial?.education ?? "",
    languages: initial?.languages ?? "",
    desiredSalary: initial?.desiredSalary ?? "",
    desiredPosition: initial?.desiredPosition ?? "",
    isDefault: initial?.isDefault ?? false,
  });

  return (
    <div className="bg-white border border-hf-red/30 rounded-[10px] p-5 shadow-card">
      <h3 className="text-sm font-semibold text-hf-text-primary mb-4">{initial ? "Редактировать резюме" : "Новое резюме"}</h3>
      <div className="space-y-3">
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Название резюме</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="Python разработчик" /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Краткое описание</label><textarea value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} rows={3} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="О себе..." /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Навыки (через запятую)</label><textarea value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} rows={2} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="Python, Django..." /></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label><textarea value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} rows={4} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="Должность, компания..." /></div>
          <div className="space-y-3">
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</label><input value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" /></div>
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</label><input value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" /></div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Ожидаемая зарплата</label><input value={form.desiredSalary} onChange={(e) => setForm({ ...form, desiredSalary: e.target.value })} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="300 000 - 500 000 ₽" /></div>
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Желаемая позиция</label><input value={form.desiredPosition} onChange={(e) => setForm({ ...form, desiredPosition: e.target.value })} className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="Senior Python Developer" /></div>
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} className="accent-hf-red" />
          <span className="text-sm text-hf-text-primary">Использовать по умолчанию</span>
        </label>
        <div className="flex gap-2 pt-2">
          <button onClick={() => onSave(form)} className="flex items-center gap-2 px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110"><Check size={14} />{initial ? "Сохранить" : "Создать"}</button>
          <button onClick={onCancel} className="px-4 py-2 bg-hf-highlight text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary"><X size={14} className="inline mr-1" />Отмена</button>
        </div>
      </div>
    </div>
  );
}

/* ─── File Upload Modal ─── */
function FileUploadModal({ onClose, onUploaded }: { onClose: () => void; onUploaded: () => void }) {
  const [step, setStep] = useState<"select" | "parsing" | "preview" | "done" | "error">("select");
  const [parsed, setParsed] = useState<any>(null);
  const [error, setError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();

  const uploadMutation = trpc.upload.uploadResume.useMutation({
    onSuccess: (data) => {
      setParsed(data);
      setStep("done");
      onUploaded();
    },
    onError: (err) => {
      setError(err.message);
      setStep("error");
    },
  });

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate
    const validTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
    const validExts = [".pdf", ".doc", ".docx"];
    const isValid = validTypes.includes(file.type) || validExts.some(ext => file.name.toLowerCase().endsWith(ext));

    if (!isValid) {
      setError("Поддерживаются только PDF и Word (.doc, .docx) файлы");
      setStep("error");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Файл слишком большой (макс. 5MB)");
      setStep("error");
      return;
    }

    setStep("parsing");
    setError("");

    // Read file as base64
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      uploadMutation.mutate({
        userId: user?.id ?? 1,
        fileBase64: base64,
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
      });
    };
    reader.onerror = () => {
      setError("Ошибка чтения файла");
      setStep("error");
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white border border-hf-border-subtle rounded-[14px] p-6 max-w-lg w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-hf-red/10 border border-hf-red/20 flex items-center justify-center">
              <Upload size={16} className="text-hf-red" />
            </div>
            <div>
              <h3 className="text-base font-bold text-hf-text-primary">Загрузить резюме</h3>
              <p className="text-xs text-hf-text-secondary">PDF или Word (.doc, .docx)</p>
            </div>
          </div>
          <button onClick={onClose} className="text-hf-text-muted hover:text-hf-text-primary transition-colors p-1"><X size={20} /></button>
        </div>

        {/* Step 1: Select file */}
        {step === "select" && (
          <div className="space-y-4">
            <div
              className="border-2 border-dashed border-hf-border-subtle rounded-xl p-8 text-center hover:border-hf-red/40 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload size={40} className="text-hf-text-muted mx-auto mb-3" />
              <p className="text-sm text-hf-text-primary font-medium">Нажмите или перетащите файл</p>
              <p className="text-xs text-hf-text-secondary mt-1">PDF, DOC, DOCX (до 5MB)</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
            {error && <p className="text-xs text-hf-red text-center">{error}</p>}
          </div>
        )}

        {/* Step 2: Parsing */}
        {step === "parsing" && (
          <div className="text-center py-8 space-y-4">
            <Loader size={40} className="text-hf-red mx-auto animate-spin" />
            <div>
              <p className="text-sm text-hf-text-primary font-medium">Читаем файл...</p>
              <p className="text-xs text-hf-text-secondary mt-1">Извлекаем текст, навыки, опыт</p>
            </div>
          </div>
        )}

        {/* Step 3: Done */}
        {step === "done" && parsed && (
          <div className="space-y-4">
            <div className="text-center">
              <Check size={48} className="text-hf-green mx-auto" />
              <p className="text-sm font-bold text-hf-green mt-2">Резюме загружено!</p>
            </div>
            <div className="bg-hf-highlight rounded-lg p-4">
              <p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Должность</p>
              <p className="text-sm text-hf-text-primary font-medium">{parsed.title}</p>
              <p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider mt-2">Навыки ({parsed.skills?.length || 0})</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {parsed.skills?.slice(0, 8).map((s: string, i: number) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 bg-white rounded border border-hf-border-subtle text-hf-text-secondary">{s}</span>
                ))}
                {parsed.skills?.length > 8 && <span className="text-[10px] text-hf-text-muted">+{parsed.skills.length - 8}</span>}
              </div>
              <p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider mt-2">Опыт</p>
              <p className="text-xs text-hf-text-primary">{parsed.experience} позиций</p>
            </div>
            <button onClick={onClose} className="w-full py-2.5 rounded-lg text-sm font-medium text-white bg-hf-red hover:brightness-110 transition-all">
              Готово
            </button>
          </div>
        )}

        {/* Error */}
        {step === "error" && (
          <div className="text-center py-6 space-y-4">
            <p className="text-sm text-hf-red">{error}</p>
            <button onClick={() => setStep("select")} className="px-6 py-2 bg-hf-highlight text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary">
              Попробовать снова
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Main Page ─── */
export default function Resumes() {
  const { user } = useAuth();
  const { data: dbResumes = [], refetch } = trpc.resume.list.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user }
  );
  const [resumesList, setResumesList] = useState<Resume[]>([]);
  const [editing, setEditing] = useState<Resume | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showUpload, setShowUpload] = useState(false);

  // Sync with DB
  useEffect(() => {
    if (dbResumes.length > 0) {
      setResumesList(dbResumes.map((r: any) => ({ ...r, id: String(r.id) })));
    }
  }, [dbResumes]);

  const handleCreate = (data: Omit<Resume, "id">) => {
    const newResume: Resume = { ...data, id: String(Date.now()), source: "manual" };
    if (data.isDefault) setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: false })).concat(newResume));
    else setResumesList((prev) => [...prev, newResume]);
    setShowCreate(false);
  };

  const handleUpdate = (data: Omit<Resume, "id">) => {
    if (!editing) return;
    if (data.isDefault) setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : { ...r, isDefault: false })));
    else setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : r)));
    setEditing(null);
  };

  const handleDelete = (id: string) => setResumesList((prev) => prev.filter((r) => r.id !== id));
  const handleSetDefault = (id: string) => setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: r.id === id })));

  return (
    <div className="space-y-4 max-w-3xl">
      {/* Header */}
      <div className="flex items-center justify-between bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Мои резюме</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">До 5 резюме для разных типов вакансий</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowUpload(true)} className="flex items-center gap-2 px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all">
            <Upload size={16} />Загрузить
          </button>
          <button onClick={() => { setShowCreate(true); setEditing(null); }} className="flex items-center gap-2 px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all" disabled={resumesList.length >= 5}>
            <Plus size={16} />{resumesList.length >= 5 ? "Лимит" : "Добавить"}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p>
          <p className="text-2xl font-bold text-hf-text-primary mt-1">{resumesList.length} <span className="text-sm text-hf-text-muted">/ 5</span></p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">По умолчанию</p>
          <p className="text-2xl font-bold text-hf-red mt-1">{resumesList.filter((r) => r.isDefault).length}</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Из файла</p>
          <p className="text-2xl font-bold text-hf-blue mt-1">{resumesList.filter((r) => r.source === "file_upload").length}</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Навыков (ср.)</p>
          <p className="text-2xl font-bold text-hf-cyan mt-1">{Math.round(resumesList.reduce((acc, r) => acc + r.skills.split(",").length, 0) / (resumesList.length || 1))}</p>
        </div>
      </div>

      {showCreate && <ResumeForm onSave={handleCreate} onCancel={() => setShowCreate(false)} />}
      {editing && <ResumeForm initial={editing} onSave={handleUpdate} onCancel={() => setEditing(null)} />}
      {showUpload && <FileUploadModal onClose={() => setShowUpload(false)} onUploaded={() => { refetch(); }} />}

      <div className="space-y-3">
        {resumesList.map((resume) => (
          <ResumeCard key={resume.id} resume={resume} onEdit={setEditing} onDelete={handleDelete} onSetDefault={handleSetDefault} />
        ))}
      </div>
    </div>
  );
}

/**
 * Upload Router — загрузка и парсинг файлов резюме (PDF / DOCX)
 */

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { resumes } from "@db/schema";
import { parseResumeFile } from "./resume-parser";
import { writeFile, mkdir, unlink } from "fs/promises";
import { join } from "path";
import { eq, desc } from "drizzle-orm";

const UPLOAD_DIR = join(process.cwd(), "uploads");

// Ensure upload dir exists
async function ensureDir() {
  try {
    await mkdir(UPLOAD_DIR, { recursive: true });
  } catch { /* already exists */ }
}

export const uploadRouter = createRouter({

  // ─── Загрузка и парсинг файла резюме ───
  uploadResume: publicQuery
    .input(
      z.object({
        userId: z.number(),
        // Base64 encoded file
        fileBase64: z.string().min(1),
        fileName: z.string().min(1),
        mimeType: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      await ensureDir();
      const db = getDb();

      // Decode base64
      const buffer = Buffer.from(input.fileBase64, "base64");

      // Validate file size (max 5MB)
      if (buffer.length > 5 * 1024 * 1024) {
        throw new Error("Файл слишком большой (макс. 5MB)");
      }

      // Validate mime type
      const allowedTypes = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ];
      if (!allowedTypes.includes(input.mimeType) && !input.fileName.endsWith(".pdf") && !input.fileName.endsWith(".docx") && !input.fileName.endsWith(".doc")) {
        throw new Error("Поддерживаются только PDF и Word (.doc, .docx) файлы");
      }

      // Save file temporarily
      const safeName = `${Date.now()}_${input.fileName.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
      const filePath = join(UPLOAD_DIR, safeName);
      await writeFile(filePath, buffer);

      try {
        // Parse resume
        const detectedMime = input.fileName.endsWith(".pdf") ? "application/pdf" :
                             input.fileName.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" :
                             input.mimeType;
        const parsed = await parseResumeFile(buffer, detectedMime);

        // Save to database
        const result = await db.insert(resumes).values({
          userId: input.userId,
          title: parsed.title || input.fileName.replace(/\.[^.]+$/, ""),
          summary: parsed.summary || null,
          skills: parsed.skills.join(", "),
          experience: parsed.experience.map(e => `${e.position}, ${e.company} (${e.period})`).join("\n"),
          education: parsed.education.map(e => `${e.institution}, ${e.degree} ${e.year}`).join("\n"),
          languages: parsed.languages.join(", ") || null,
          desiredSalary: null,
          desiredPosition: parsed.title || null,
          source: "file_upload",
        }).returning({ id: resumes.id });

        return {
          id: result[0].id,
          title: parsed.title,
          skills: parsed.skills,
          experience: parsed.experience.length,
          rawText: parsed.rawText.substring(0, 500), // preview
        };
      } finally {
        // Clean up temp file
        try { await unlink(filePath); } catch { /* ignore */ }
      }
    }),

  // ─── List uploaded resumes ───
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(resumes)
        .where(eq(resumes.userId, input.userId))
        .orderBy(desc(resumes.createdAt));
    }),

  // ─── Delete resume ───
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(resumes).where(eq(resumes.id, input.id));
      return { ok: true };
    }),
});

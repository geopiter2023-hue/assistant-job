/**
 * Resume Parser — парсинг резюме из PDF и DOCX файлов
 * Загрузка файла → извлечение текста → структурирование данных
 */

import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");
import mammoth from "mammoth";

export interface ParsedResume {
  title: string;
  summary: string;
  skills: string[];
  experience: Array<{
    position: string;
    company: string;
    period: string;
    description: string;
  }>;
  education: Array<{
    institution: string;
    degree: string;
    year: string;
  }>;
  languages: string[];
  contacts: {
    email?: string;
    phone?: string;
    location?: string;
  };
  rawText: string;
}

// ─── Определить тип файла и распарсить ───
export async function parseResumeFile(buffer: Buffer, mimeType: string): Promise<ParsedResume> {
  let text = "";

  if (mimeType === "application/pdf" || mimeType === "application/octet-stream") {
    text = await parsePdf(buffer);
  } else if (
    mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    mimeType === "application/msword"
  ) {
    text = await parseDocx(buffer);
  } else {
    // Пробуем как текст
    text = buffer.toString("utf-8");
  }

  return structureResume(text);
}

// ─── Парсинг PDF ───
async function parsePdf(buffer: Buffer): Promise<string> {
  const data = await pdfParse(buffer);
  return data.text || "";
}

// ─── Парсинг DOCX ───
async function parseDocx(buffer: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer });
  return result.value || "";
}

// ─── Структурирование резюме из текста ───
function structureResume(text: string): ParsedResume {
  const lines = text
    .split(/\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const fullText = lines.join("\n");

  return {
    title: extractTitle(fullText, lines),
    summary: extractSummary(fullText, lines),
    skills: extractSkills(fullText),
    experience: extractExperience(fullText, lines),
    education: extractEducation(fullText),
    languages: extractLanguages(fullText),
    contacts: extractContacts(fullText),
    rawText: fullText,
  };
}

// ─── Extractors ───

function extractTitle(text: string, lines: string[]): string {
  // Первая непустая строка обычно — должность или ФИО
  if (lines.length > 0 && lines[0].length < 80) {
    return lines[0];
  }
  // Ищем "Резюме" или должность
  const match = text.match(/(?:резюме|resume)[\s:—-]*(.+?)(?:\n|$)/i);
  if (match) return match[1].trim();
  return "Резюме";
}

function extractSummary(text: string, lines: string[]): string {
  // Ищем блок "О себе" / "Summary" / первый абзац после заголовка
  const sections = ["о себе", "summary", "обо мне", "профиль", "личные качества"];
  for (const section of sections) {
    const regex = new RegExp(`${section}[\s:]*\n+([\s\S]{20,500}?)(?=\n+(?:опыт|experience|навыки|skills|образование|education|$))`, "i");
    const match = text.match(regex);
    if (match) return match[1].trim().replace(/\n+/g, " ");
  }
  // Fallback: первые 3-5 строк как summary
  return lines.slice(1, 5).join(" ").substring(0, 300);
}

function extractSkills(text: string): string[] {
  const skills: string[] = [];

  // Ищем секцию "Навыки" / "Skills"
  const sectionRegex = /(?:навыки|ключевые навыки|skills|стек)[\s:]*\n+([\s\S]{10,2000}?)(?=\n+(?:опыт|experience|образование|education|проекты|о себе|$))/i;
  const match = text.match(sectionRegex);

  if (match) {
    const skillsText = match[1];
    // Разбиваем по запятым, точкам с запятой, переносам
    const items = skillsText
      .split(/[,;•·\n]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 1 && s.length < 50);
    skills.push(...items);
  }

  // Если не нашли секцию — ищем популярные навыки в тексте
  if (skills.length === 0) {
    const commonSkills = [
      "Python", "JavaScript", "TypeScript", "Java", "Go", "Rust", "C++", "C#", "PHP", "Ruby",
      "React", "Vue", "Angular", "Node.js", "Django", "Flask", "FastAPI", "Spring",
      "Docker", "Kubernetes", "AWS", "GCP", "Azure", "Linux",
      "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch", "ClickHouse",
      "Git", "CI/CD", "Jenkins", "GitLab", "GitHub Actions",
      "REST API", "GraphQL", "gRPC", "WebSocket",
      "Nginx", "Apache", "Terraform", "Ansible",
      "Machine Learning", "Data Science", "TensorFlow", "PyTorch",
      "Agile", "Scrum", "Kanban", "Jira", "Confluence",
      "Team Lead", "Management", "Mentoring",
      "HTML", "CSS", "Sass", "Less", "Webpack", "Vite",
      "SQL", "NoSQL", "ORM", "Hibernate", "SQLAlchemy",
    ];

    for (const skill of commonSkills) {
      if (text.toLowerCase().includes(skill.toLowerCase()) && !skills.includes(skill)) {
        skills.push(skill);
      }
    }
  }

  return skills.slice(0, 30); // max 30 skills
}

function extractExperience(text: string, lines: string[]): ParsedResume["experience"] {
  const experiences: ParsedResume["experience"] = [];

  const sectionRegex = /(?:опыт работы|профессиональный опыт|experience)[\s:]*\n+/i;
  const sectionMatch = text.match(sectionRegex);

  if (!sectionMatch) return experiences;

  const expStart = text.indexOf(sectionMatch[0]) + sectionMatch[0].length;
  const expSection = text.substring(expStart, expStart + 3000);

  // Разбиваем на записи по датам/должностям
  // Формат: Должность, Компания (период)
  const entryRegex = /([А-ЯA-Z][^\n(]{2,60})[\s,]*([^(\n]{2,60})?[\s(]*((?:\d{2}\.\d{2}\.\d{4}|\d{4})[\s—-]+(?:(?:\d{2}\.\d{2}\.\d{4}|\d{4})|н\.в\.|по настоящее время|present))[\s)]*/gi;

  let match;
  while ((match = entryRegex.exec(expSection)) !== null) {
    const position = match[1]?.trim() || "";
    const company = match[2]?.trim() || "";
    const period = match[3]?.trim() || "";

    if (position.length > 3 && position.length < 60) {
      experiences.push({
        position,
        company: company || "—",
        period,
        description: "", // Можно добавить AI-извлечение описания
      });
    }
  }

  // Если не распарсилось — пробуем по строкам
  if (experiences.length === 0) {
    let currentExp: Partial<ParsedResume["experience"][0]> = {};
    for (const line of lines) {
      if (/\d{4}/.test(line) && (line.includes("—") || line.includes("-") || line.includes("по "))) {
        if (currentExp.position) {
          experiences.push(currentExp as ParsedResume["experience"][0]);
        }
        currentExp = { period: line.trim() };
      } else if (!currentExp.position && line.length > 5 && line.length < 60) {
        currentExp.position = line;
      } else if (currentExp.position && !currentExp.company && line.length > 2) {
        currentExp.company = line;
      }
    }
    if (currentExp.position) {
      experiences.push(currentExp as ParsedResume["experience"][0]);
    }
  }

  return experiences.slice(0, 10);
}

function extractEducation(text: string): ParsedResume["education"] {
  const educations: ParsedResume["education"] = [];

  const sectionRegex = /(?:образование|education)[\s:]*\n+/i;
  const sectionMatch = text.match(sectionRegex);

  if (!sectionMatch) return educations;

  const eduStart = text.indexOf(sectionMatch[0]) + sectionMatch[0].length;
  const eduSection = text.substring(eduStart, eduStart + 1500);

  // Ищем: Университет, специальность, год
  const lines2 = eduSection.split("\n").map((l) => l.trim()).filter(Boolean);

  for (let i = 0; i < lines2.length - 1; i++) {
    const line = lines2[i];
    const yearMatch = line.match(/(19|20)\d{2}[\s—-]+((?:19|20)\d{2}|н\.в\.)?/);

    if (yearMatch || line.length > 10) {
      educations.push({
        institution: line.substring(0, 80),
        degree: lines2[i + 1]?.substring(0, 60) || "",
        year: yearMatch ? yearMatch[0] : "",
      });
      i++;
    }
  }

  return educations.slice(0, 5);
}

function extractLanguages(text: string): string[] {
  const langs: string[] = [];
  const sectionRegex = /(?:языки|languages)[\s:]*\n+([\s\S]{5,500}?)(?=\n+(?:навыки|опыт|образование|проекты|$))/i;
  void sectionRegex;
  const match = text.match(sectionRegex);

  if (match) {
    const items = match[1]
      .split(/[,;•·\n]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 2 && s.length < 40);
    langs.push(...items);
  }

  // Fallback: ищем в тексте
  const commonLangs = ["Русский", "Английский", "English", "Немецкий", "Deutsch", "Французский", "Français", "Испанский", "Китайский", "Японский"];
  for (const lang of commonLangs) {
    if (text.toLowerCase().includes(lang.toLowerCase()) && !langs.some((l) => l.toLowerCase().includes(lang.toLowerCase()))) {
      langs.push(lang);
    }
  }

  return langs;
}

function extractContacts(text: string): ParsedResume["contacts"] {
  const email = text.match(/[\w.-]+@[\w.-]+\.\w{2,}/)?.[0];
  const phone = text.match(/[+]7\s?[\s(]?\d{3}[)\s]?\s?\d{3}[\s-]?\d{2}[\s-]?\d{2}/)?.[0] ||
                text.match(/8\s?[\s(]?\d{3}[)\s]?\s?\d{3}[\s-]?\d{2}[\s-]?\d{2}/)?.[0];

  return { email, phone };
}

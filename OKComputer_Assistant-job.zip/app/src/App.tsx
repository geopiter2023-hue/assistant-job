import { Routes, Route, Navigate } from "react-router";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Vacancies from "./pages/Vacancies";
import Applies from "./pages/Applies";
import Tasks from "./pages/Tasks";
import Settings from "./pages/Settings";
import Subscription from "./pages/Subscription";
import Resumes from "./pages/Resumes";
import AiPipeline from "./pages/AiPipeline";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Onboarding from "./pages/Onboarding";

function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const done = localStorage.getItem("aj_onboarding_done") === "1";
  if (!done) return <Navigate to="/onboarding" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Layout>
      <Routes>
        {/* Первая страница — onboarding с выбором площадок */}
        <Route path="/onboarding" element={<Onboarding />} />
        {/* Основные страницы (требуют onboarding) */}
        <Route path="/" element={<OnboardingGuard><Dashboard /></OnboardingGuard>} />
        <Route path="/applies" element={<OnboardingGuard><Applies /></OnboardingGuard>} />
        <Route path="/settings" element={<OnboardingGuard><Settings /></OnboardingGuard>} />
        <Route path="/profile" element={<OnboardingGuard><Profile /></OnboardingGuard>} />
        {/* Остальные роуты */}
        <Route path="/vacancies" element={<OnboardingGuard><Vacancies /></OnboardingGuard>} />
        <Route path="/ai-pipeline" element={<OnboardingGuard><AiPipeline /></OnboardingGuard>} />
        <Route path="/tasks" element={<OnboardingGuard><Tasks /></OnboardingGuard>} />
        <Route path="/resumes" element={<OnboardingGuard><Resumes /></OnboardingGuard>} />
        <Route path="/subscription" element={<OnboardingGuard><Subscription /></OnboardingGuard>} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  );
}

/**
 * Auto Router — полностью автоматический отклик
 * 
 * Пользователь нажимает ОДНУ кнопку:
 * 1. Поиск вакансий на HH.ru
 * 2. AI-анализ каждой (требования, обязанности, навыки)
 * 3. Фильтрация по matchScore (только >70%)
 * 4. Адаптация резюме под каждую
 * 5. Генерация сопроводительного письма
 * 6. Сохранение черновика
 * 7. Результат пользователю
 */

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { vacancyAnalyses, applyDrafts, resumes } from "@db/schema";
import { analyzeVacancy, adaptResume, generateCoverLetter } from "./ai-service";
import { searchVacancies } from "./scraper";
import { eq } from "drizzle-orm";

export const autoRouter = createRouter({

  // ─── ОДНА КНОПКА: найти → проанализировать → подготовить отклики ───
  autoApply: publicQuery
    .input(
      z.object({
        userId: z.number(),
        query: z.string().min(1),
        platforms: z.array(z.string()).default(["hh"]),
        resumeId: z.number().default(1),
        candidateName: z.string().default("Кандидат"),
        minMatchScore: z.number().default(60), // минимальный % совпадения
        maxVacancies: z.number().default(10),  // сколько вакансий обработать
        area: z.number().optional(),
        salary: z.number().optional(),
        experience: z.string().optional(),
        remote: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = getDb();
        const results: Array<{
          vacancy: {
            id: string;
            title: string;
            company: string;
            salary: string;
            location: string;
            url: string;
          };
          analysis: {
            matchScore: number;
            keySkills: string[];
            aiSummary: string;
          };
          status: "processed" | "low_match" | "error";
          draftId?: number;
        }> = [];

        // Шаг 1: Поиск вакансий
        console.log(`[Auto] Step 1: Searching "${input.query}" on ${input.platforms.join(", ")}...`);
        const vacancies = await searchVacancies(input.query, input.platforms, {
          area: input.area,
          salary: input.salary,
          experience: input.experience,
          remote: input.remote,
        });

        console.log(`[Auto] Found ${vacancies.length} vacancies`);

        // Получаем резюме
        const resumeRows = await db
          .select()
          .from(resumes)
          .where(eq(resumes.id, input.resumeId))
          .limit(1);
        const resume = resumeRows[0];

        if (!resume) {
          return {
            query: input.query,
            totalFound: 0,
            processed: 0,
            lowMatch: 0,
            errors: 0,
            results: [],
            error: "Резюме не найдено. Загрузите резюме в разделе 'Резюме'.",
          };
        }

        // Шаг 2-6: Для каждой вакансии
        for (let i = 0; i < Math.min(vacancies.length, input.maxVacancies); i++) {
          const v = vacancies[i];
          try {
            // Шаг 2: AI-анализ
            const fullText = `
Вакансия: ${v.title}
Компания: ${v.company}
Описание: ${v.description}
Обязанности: ${v.responsibilities.join("\n")}
Требования: ${v.requirements.join("\n")}
Условия: ${v.conditions.join("\n")}
Навыки: ${v.keySkills.join(", ")}
`;
            const aiResult = await analyzeVacancy(fullText);

            // Шаг 3: Фильтрация по matchScore
            if (aiResult.matchScore < input.minMatchScore) {
              results.push({
                vacancy: {
                  id: v.id,
                  title: v.title,
                  company: v.company,
                  salary: v.salary,
                  location: v.location,
                  url: v.url,
                },
                analysis: {
                  matchScore: aiResult.matchScore,
                  keySkills: aiResult.keySkills,
                  aiSummary: aiResult.aiSummary,
                },
                status: "low_match",
              });
              continue;
            }

            // Сохраняем анализ в БД (platform — безопасная вставка)
            const platformValue = ["hh","zarplata","rabota","superjob","yandex_smena","karierist","rabotaru","avito","trudvsem","gorodrabot"].includes(v.platform)
              ? v.platform : "hh";

            const analysisResult = await db.insert(vacancyAnalyses).values({
              userId: input.userId,
              vacancyUrl: v.url,
              vacancyTitle: v.title,
              company: v.company,
              platform: platformValue as any,
              rawDescription: v.description,
              requirements: aiResult.requirements.join("\n"),
              responsibilities: aiResult.responsibilities.join("\n"),
              conditions: aiResult.conditions.join("\n"),
              keySkills: aiResult.keySkills.join(", "),
              matchScore: aiResult.matchScore,
              aiSummary: aiResult.aiSummary,
            }).returning({ id: vacancyAnalyses.id });

            const analysisId = analysisResult[0].id;

            // Шаг 4: Адаптация резюме
            const resumeText = `${resume.title}\n${resume.summary || ""}\nНавыки: ${resume.skills}\nОпыт: ${resume.experience}`;
            const adaptedResume = await adaptResume(resumeText, aiResult.requirements, aiResult.responsibilities);

            // Шаг 5: Генерация письма
            const coverLetter = await generateCoverLetter(
              v.title,
              v.company,
              input.candidateName,
              aiResult.keySkills
            );

            // Шаг 6: Сохранение черновика
            const draftResult = await db.insert(applyDrafts).values({
              userId: input.userId,
              vacancyAnalysisId: analysisId,
              resumeId: input.resumeId,
              editedResumeText: adaptedResume?.adaptedResume || "Резюме не адаптировано",
              coverLetter,
              aiReasoning: `Совпадение ${aiResult.matchScore}%. ${aiResult.aiSummary}`,
              status: "draft",
            }).returning({ id: applyDrafts.id });

            results.push({
              vacancy: {
                id: v.id,
                title: v.title,
                company: v.company,
                salary: v.salary,
                location: v.location,
                url: v.url,
              },
              analysis: {
                matchScore: aiResult.matchScore,
                keySkills: aiResult.keySkills,
                aiSummary: aiResult.aiSummary,
              },
              status: "processed",
              draftId: draftResult[0].id,
            });

          } catch (err) {
            console.error(`[Auto] Error processing vacancy ${v.id}:`, err);
            results.push({
              vacancy: {
                id: v.id,
                title: v.title,
                company: v.company,
                salary: v.salary,
                location: v.location,
                url: v.url,
              },
              analysis: { matchScore: 0, keySkills: [], aiSummary: "Ошибка обработки" },
              status: "error",
            });
          }
        }

        return {
          query: input.query,
          totalFound: vacancies.length,
          processed: results.filter(r => r.status === "processed").length,
          lowMatch: results.filter(r => r.status === "low_match").length,
          errors: results.filter(r => r.status === "error").length,
          results,
        };
      } catch (err: any) {
        console.error("[Auto] autoApply error:", err);
        // Не падаем — возвращаем ошибку клиенту
        return {
          query: input.query,
          totalFound: 0,
          processed: 0,
          lowMatch: 0,
          errors: 0,
          results: [],
          error: err?.message || "Ошибка сервера. Попробуйте позже.",
        };
      }
    }),
});

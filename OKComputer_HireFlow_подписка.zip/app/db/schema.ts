import {
  pgTable,
  pgEnum,
  serial,
  bigint,
  varchar,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
} from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("role", ["user", "admin"]);
export const statusEnum = pgEnum("bot_status", ["running", "completed", "failed", "scheduled", "paused"]);
export const applyStatusEnum = pgEnum("apply_status", ["success", "error", "pending"]);
export const planEnum = pgEnum("plan_type", ["free", "pro", "enterprise"]);
export const subStatusEnum = pgEnum("sub_status", ["active", "cancelled", "expired"]);

// ─── 10 российских площадок + "all" для сессий ───
export const platformEnum = pgEnum("job_platform", [
  "hh", "zarplata", "rabota", "superjob", "yandex_smena",
  "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot", "all",
]);

// ─── Users ───
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("union_id", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: roleEnum("role").default("user").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("last_sign_in_at", { withTimezone: true }).defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Resumes (1-5 per user) ───
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  summary: text("summary"),
  skills: text("skills").notNull(),
  experience: text("experience"),
  education: text("education"),
  languages: text("languages"),
  desiredSalary: varchar("desired_salary", { length: 100 }),
  desiredPosition: varchar("desired_position", { length: 255 }),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Resume = typeof resumes.$inferSelect;
export type InsertResume = typeof resumes.$inferInsert;

// ─── Vacancy Analyses (AI-generated) ───
export const vacancyAnalyses = pgTable("vacancy_analyses", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  vacancyUrl: varchar("vacancy_url", { length: 500 }).notNull(),
  vacancyTitle: varchar("vacancy_title", { length: 255 }),
  company: varchar("company", { length: 100 }),
  platform: platformEnum("platform"),
  rawDescription: text("raw_description"),
  requirements: text("requirements"),
  responsibilities: text("responsibilities"),
  conditions: text("conditions"),
  keySkills: text("key_skills"),
  salaryRange: varchar("salary_range", { length: 100 }),
  matchScore: integer("match_score"),
  aiSummary: text("ai_summary"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type VacancyAnalysis = typeof vacancyAnalyses.$inferSelect;
export type InsertVacancyAnalysis = typeof vacancyAnalyses.$inferInsert;

// ─── Apply Drafts (AI-edited resume + cover letter before sending) ───
export const applyDrafts = pgTable("apply_drafts", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  vacancyAnalysisId: bigint("vacancy_analysis_id", { mode: "number" }),
  resumeId: bigint("resume_id", { mode: "number" }),
  originalResumeSnapshot: jsonb("original_resume_snapshot"),
  editedResumeText: text("edited_resume_text"),
  coverLetter: text("cover_letter"),
  aiReasoning: text("ai_reasoning"),
  status: varchar("status", { length: 20 }).default("draft").notNull(), // draft, approved, sent
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull().$onUpdate(() => new Date()),
});

export type ApplyDraft = typeof applyDrafts.$inferSelect;
export type InsertApplyDraft = typeof applyDrafts.$inferInsert;

// ─── Profiles (user settings + credentials) ───
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  fullName: varchar("full_name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  region: varchar("region", { length: 100 }),
  salaryFrom: integer("salary_from"),
  salaryTo: integer("salary_to"),
  experience: varchar("experience", { length: 50 }),
  remoteOnly: boolean("remote_only").default(false),
  skipCompanies: text("skip_companies"),
  aiApiKey: varchar("ai_api_key", { length: 255 }),
  aiModel: varchar("ai_model", { length: 50 }).default("gpt-4o-mini"),
  coverLetterTemplate: text("cover_letter_template"),
  // 10 platform credentials
  hhLogin: varchar("hh_login", { length: 255 }),
  hhPassword: varchar("hh_password", { length: 255 }),
  zarplataLogin: varchar("zarplata_login", { length: 255 }),
  zarplataPassword: varchar("zarplata_password", { length: 255 }),
  rabotaLogin: varchar("rabota_login", { length: 255 }),
  rabotaPassword: varchar("rabota_password", { length: 255 }),
  superjobLogin: varchar("superjob_login", { length: 255 }),
  superjobPassword: varchar("superjob_password", { length: 255 }),
  yandexSmenaLogin: varchar("yandex_smena_login", { length: 255 }),
  yandexSmenaPassword: varchar("yandex_smena_password", { length: 255 }),
  karieristLogin: varchar("karierist_login", { length: 255 }),
  karieristPassword: varchar("karierist_password", { length: 255 }),
  rabotaruLogin: varchar("rabotaru_login", { length: 255 }),
  rabotaruPassword: varchar("rabotaru_password", { length: 255 }),
  avitoLogin: varchar("avito_login", { length: 255 }),
  avitoPassword: varchar("avito_password", { length: 255 }),
  trudvsemLogin: varchar("trudvsem_login", { length: 255 }),
  trudvsemPassword: varchar("trudvsem_password", { length: 255 }),
  gorodrabotLogin: varchar("gorodrabot_login", { length: 255 }),
  gorodrabotPassword: varchar("gorodrabot_password", { length: 255 }),
  telegramToken: varchar("telegram_token", { length: 255 }),
  telegramChatId: varchar("telegram_chat_id", { length: 100 }),
  settings: jsonb("settings"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

// ─── Bot Sessions ───
export const botSessions = pgTable("bot_sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  status: statusEnum("status").default("scheduled").notNull(),
  platform: platformEnum("platform").default("all").notNull(),
  query: varchar("query", { length: 255 }).notNull(),
  resultsFound: integer("results_found").default(0),
  appliesSent: integer("applies_sent").default(0),
  emulationMode: boolean("emulation_mode").default(true),
  useAiPipeline: boolean("use_ai_pipeline").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export type BotSession = typeof botSessions.$inferSelect;
export type InsertBotSession = typeof botSessions.$inferInsert;

// ─── Applies ───
export const applies = pgTable("applies", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  sessionId: bigint("session_id", { mode: "number" }),
  resumeId: bigint("resume_id", { mode: "number" }),
  draftId: bigint("draft_id", { mode: "number" }),
  status: applyStatusEnum("status").default("pending").notNull(),
  vacancy: varchar("vacancy", { length: 255 }).notNull(),
  company: varchar("company", { length: 100 }),
  platform: platformEnum("platform").notNull(),
  salary: varchar("salary", { length: 100 }),
  location: varchar("location", { length: 100 }),
  coverLetter: text("cover_letter"),
  editedResume: text("edited_resume"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Apply = typeof applies.$inferSelect;
export type InsertApply = typeof applies.$inferInsert;

// ─── Subscriptions ───
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull().unique(),
  plan: planEnum("plan").default("free").notNull(),
  status: subStatusEnum("status").default("active").notNull(),
  price: integer("price").default(0),
  period: varchar("period", { length: 20 }),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

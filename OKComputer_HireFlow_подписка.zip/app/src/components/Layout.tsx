import { useState, useCallback } from "react";
import { useLocation } from "react-router";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import type { BotStatus } from "@/lib/data";

const pageTitles: Record<string, string> = {
  "/": "⚡ Дашборд",
  "/vacancies": "💼 Вакансии",
  "/ai-pipeline": "✨ AI Отклики",
  "/applies": "📨 Отклики",
  "/tasks": "📋 Задачи",
  "/resumes": "📄 Резюме",
  "/settings": "⚙️ Настройки",
  "/subscription": "👑 Подписка",
};

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [botStatus, setBotStatus] = useState<BotStatus>("running");
  const location = useLocation();

  const title = pageTitles[location.pathname] || "Assistant Job";

  const handleMenuClick = useCallback(() => {
    setMobileMenuOpen(true);
  }, []);

  const handleMobileClose = useCallback(() => {
    setMobileMenuOpen(false);
  }, []);

  return (
    <div className="min-h-screen bg-hf-highlight">
      <Sidebar mobileOpen={mobileMenuOpen} onMobileClose={handleMobileClose} />

      {/* Main content area */}
      <div className="lg:ml-[240px] min-h-screen flex flex-col">
        <TopBar
          title={title}
          botStatus={botStatus}
          onStatusChange={setBotStatus}
          onMenuClick={handleMenuClick}
        />

        <main className="flex-1 p-4 sm:p-5 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";
import { platformConfig } from "@/lib/data";
import type { JobPlatform } from "@/lib/data";

interface PlatformBadgeProps {
  platform: JobPlatform;
  size?: "sm" | "md";
}

export default function PlatformBadge({ platform, size = "sm" }: PlatformBadgeProps) {
  const cfg = platformConfig[platform];
  if (!cfg) return null;

  return (
    <span
      className={cn(
        "inline-flex items-center rounded font-medium",
        size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-sm",
        cfg.bg,
        cfg.color
      )}
    >
      {cfg.label}
    </span>
  );
}

// Platform filter buttons
interface PlatformFiltersProps {
  active: JobPlatform | "all";
  onChange: (platform: JobPlatform | "all") => void;
}

export function PlatformFilters({ active, onChange }: PlatformFiltersProps) {
  const platforms = (["all", ...Object.keys(platformConfig)] as (JobPlatform | "all")[]);

  return (
    <div className="flex flex-wrap gap-2">
      <button
        onClick={() => onChange("all")}
        className={cn(
          "px-3 py-2 rounded-lg text-xs font-medium transition-all",
          active === "all"
            ? "bg-hf-blue text-white"
            : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary"
        )}
      >
        Все
      </button>
      {platforms.filter((p): p is Exclude<typeof platforms[number], "all"> => p !== "all").map((key) => {
        const cfg = platformConfig[key];
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className={cn(
              "px-3 py-2 rounded-lg text-xs font-medium transition-all",
              active === key
                ? "text-white"
                : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary"
            )}
            style={
              active === key
                ? { backgroundColor: key === "hh" ? "#3B82F6" : key === "zarplata" ? "#22C55E" : key === "rabota" ? "#F97316" : key === "superjob" ? "#EF4444" : key === "yandex_smena" ? "#8B5CF6" : key === "karierist" ? "#06B6D4" : key === "rabotaru" ? "#EC4899" : key === "avito" ? "#10B981" : key === "trudvsem" ? "#F59E0B" : "#6366F1" }
                : undefined
            }
          >
            {cfg.label}
          </button>
        );
      })}
    </div>
  );
}

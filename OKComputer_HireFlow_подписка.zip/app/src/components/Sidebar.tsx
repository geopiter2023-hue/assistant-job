import { NavLink, useLocation } from "react-router";
import {
  LayoutDashboard,
  Briefcase,
  Send,
  ClipboardList,
  Settings,
  Crown,
  Zap,
  X,
  FileText,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const menuItems = [
  { text: "Дашборд", icon: LayoutDashboard, path: "/" },
  { text: "Вакансии", icon: Briefcase, path: "/vacancies" },
  { text: "AI Отклики", icon: Sparkles, path: "/ai-pipeline" },
  { text: "Отклики", icon: Send, path: "/applies" },
  { text: "Задачи", icon: ClipboardList, path: "/tasks" },
  { text: "Резюме", icon: FileText, path: "/resumes" },
  { text: "Настройки", icon: Settings, path: "/settings" },
];

const subscriptionItem = { text: "Подписка", icon: Crown, path: "/subscription" };

interface SidebarProps {
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export default function Sidebar({ mobileOpen, onMobileClose }: SidebarProps) {
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <>
      {/* Mobile overlay backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-[45] lg:hidden"
          onClick={onMobileClose}
        />
      )}

      {/* Mobile sidebar slide-out panel */}
      <aside
        className={cn(
          "fixed top-0 left-0 h-full w-[260px] z-50 flex flex-col",
          "bg-white border-r border-hf-border-subtle shadow-lg",
          "transform transition-transform duration-300 ease-in-out",
          "lg:hidden",
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Mobile header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-hf-border-subtle">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-hf-red flex items-center justify-center flex-shrink-0">
              <Zap size={18} className="text-white" strokeWidth={2.5} />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-hf-text-primary tracking-tight">
                Assistant Job
              </span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-hf-red/10 text-hf-red border border-hf-red/20">
                v1
              </span>
            </div>
          </div>
          <button
            onClick={onMobileClose}
            className="p-1.5 rounded-md text-hf-text-secondary hover:text-hf-text-primary hover:bg-hf-highlight transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 pt-4">
          <ul className="space-y-1">
            {menuItems.map((item) => {
              const active = isActive(item.path);
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    onClick={onMobileClose}
                    className={cn(
                      "w-full flex items-center gap-3.5 px-3 py-3 rounded-lg text-sm font-medium transition-all duration-150",
                      active
                        ? "bg-hf-red/10 text-hf-red border-r-[3px] border-hf-red"
                        : "text-hf-text-secondary border-r-[3px] border-transparent hover:bg-hf-highlight hover:text-hf-text-primary"
                    )}
                  >
                    <Icon
                      size={20}
                      className={cn(
                        "flex-shrink-0",
                        active ? "text-hf-red" : "text-hf-text-secondary"
                      )}
                    />
                    <span>{item.text}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>

          {/* Subscription */}
          <div className="mt-4 pt-4 border-t border-hf-border-subtle">
            <NavLink
              to={subscriptionItem.path}
              onClick={onMobileClose}
              className={cn(
                "w-full flex items-center gap-3.5 px-3 py-3 rounded-lg text-sm font-medium transition-all duration-150",
                isActive(subscriptionItem.path)
                  ? "bg-hf-amber/10 text-hf-amber border-r-[3px] border-hf-amber"
                  : "text-hf-text-secondary border-r-[3px] border-transparent hover:bg-hf-highlight hover:text-hf-amber"
              )}
            >
              <Crown
                size={20}
                className={cn(
                  "flex-shrink-0",
                  isActive(subscriptionItem.path) ? "text-hf-amber" : "text-hf-text-secondary"
                )}
              />
              <span>{subscriptionItem.text}</span>
            </NavLink>
          </div>
        </nav>

        {/* Footer status */}
        <div className="px-5 py-4 border-t border-hf-border-subtle">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-hf-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-hf-green" />
            </span>
            <span className="text-sm text-hf-text-secondary">Бот активен</span>
          </div>
        </div>
      </aside>

      {/* Desktop sidebar — always visible */}
      <aside className="hidden lg:flex fixed left-0 top-0 h-full w-[240px] flex-col bg-white border-r border-hf-border-subtle z-30">
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-6">
          <div className="w-8 h-8 rounded-lg bg-hf-red flex items-center justify-center flex-shrink-0">
            <Zap size={18} className="text-white" strokeWidth={2.5} />
          </div>
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-hf-text-primary tracking-tight">
              Assistant Job
            </span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-hf-red/10 text-hf-red border border-hf-red/20">
              v1
            </span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 mt-1">
          <ul className="space-y-1">
            {menuItems.map((item) => {
              const active = isActive(item.path);
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    className={cn(
                      "w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150",
                      active
                        ? "bg-hf-red/10 text-hf-red border-r-[3px] border-hf-red"
                        : "text-hf-text-secondary border-r-[3px] border-transparent hover:bg-hf-highlight hover:text-hf-text-primary"
                    )}
                  >
                    <Icon
                      size={20}
                      className={cn(
                        "flex-shrink-0",
                        active ? "text-hf-red" : "text-hf-text-secondary"
                      )}
                    />
                    <span>{item.text}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>

          {/* Subscription */}
          <div className="mt-4 pt-4 border-t border-hf-border-subtle">
            <NavLink
              to={subscriptionItem.path}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-all duration-150",
                isActive(subscriptionItem.path)
                  ? "bg-hf-amber/10 text-hf-amber border-r-[3px] border-hf-amber"
                  : "text-hf-text-secondary border-r-[3px] border-transparent hover:bg-hf-highlight hover:text-hf-amber"
              )}
            >
              <Crown
                size={20}
                className={cn(
                  "flex-shrink-0",
                  isActive(subscriptionItem.path) ? "text-hf-amber" : "text-hf-text-secondary"
                )}
              />
              <span>{subscriptionItem.text}</span>
            </NavLink>
          </div>
        </nav>

        {/* Footer status */}
        <div className="px-6 py-4 border-t border-hf-border-subtle">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-hf-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-hf-green" />
            </span>
            <span className="text-sm text-hf-text-secondary">Бот активен</span>
          </div>
        </div>
      </aside>
    </>
  );
}

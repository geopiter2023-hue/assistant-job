import { useState } from "react";
import { Save, Eye, EyeOff, Bot } from "lucide-react";
import { cn } from "@/lib/utils";
import { defaultEmulationSettings, platformConfig } from "@/lib/data";
import type { EmulationSettings, JobPlatform } from "@/lib/data";

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  searchQuery: string;
  region: string;
  salaryFrom: string;
  salaryTo: string;
  experience: string;
  remote: boolean;
  coverLetter: string;
  delayMin: number;
  delayMax: number;
  maxApplies: number;
  skipCompanies: string;
  telegramToken: string;
  telegramChatId: string;
  emulation: EmulationSettings;
  platforms: Record<JobPlatform, { enabled: boolean; login: string; password: string }>;
}

const allPlatforms = Object.keys(platformConfig) as JobPlatform[];

const initialForm: FormState = {
  fullName: "Иван Петров",
  email: "ivan@example.com",
  phone: "+7 (999) 123-45-67",
  searchQuery: "Python разработчик",
  region: "Москва",
  salaryFrom: "200000",
  salaryTo: "500000",
  experience: "between1And3",
  remote: true,
  coverLetter: `Здравствуйте!\n\nМеня заинтересовала вакансия "{position}" в компании {company}.\n\nУ меня есть релевантный опыт разработки на Python и я хотел бы стать частью вашей команды. Готов обсудить детали и ответить на любые вопросы.\n\nС уважением,\n{candidate_name}`,
  delayMin: 5,
  delayMax: 15,
  maxApplies: 20,
  skipCompanies: "Аутсорсинг ООО, Консалтинг Групп",
  telegramToken: "",
  telegramChatId: "",
  emulation: { ...defaultEmulationSettings },
  platforms: Object.fromEntries(
    allPlatforms.map((p) => [p, { enabled: p === "hh" || p === "zarplata", login: "", password: "" }])
  ) as Record<JobPlatform, { enabled: boolean; login: string; password: string }>,
};

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h3 className="text-base font-semibold text-hf-red">{title}</h3>
      {subtitle && <p className="text-xs text-hf-text-secondary mt-0.5">{subtitle}</p>}
    </div>
  );
}

function Input({ label, type = "text", value, onChange, placeholder, multiline, rows = 3 }: {
  label: string; type?: string; value: string; onChange: (val: string) => void; placeholder?: string; multiline?: boolean; rows?: number;
}) {
  const baseClass = "w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors";
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      {multiline ? <textarea className={cn(baseClass, "resize-none")} rows={rows} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} /> : <input type={type} className={baseClass} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />}
    </div>
  );
}

function PasswordInput({ label, value, onChange }: { label: string; value: string; onChange: (val: string) => void }) {
  const [show, setShow] = useState(false);
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      <div className="relative">
        <input type={show ? "text" : "password"} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 pr-9 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors" value={value} onChange={(e) => onChange(e.target.value)} />
        <button type="button" onClick={() => setShow(!show)} className="absolute right-2 top-1/2 -translate-y-1/2 text-hf-text-muted hover:text-hf-text-primary transition-colors">{show ? <EyeOff size={14} /> : <Eye size={14} />}</button>
      </div>
    </div>
  );
}

function Toggle({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div onClick={onChange} className={cn("w-10 h-6 rounded-full transition-colors relative flex-shrink-0 mt-0.5", checked ? "bg-hf-red" : "bg-hf-border-subtle")}>
        <span className={cn("absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-[18px]" : "translate-x-0.5")} />
      </div>
      <div>
        <span className="text-sm text-hf-text-primary group-hover:text-hf-red transition-colors">{label}</span>
        {description && <p className="text-xs text-hf-text-secondary mt-0.5">{description}</p>}
      </div>
    </label>
  );
}

function SliderInput({ label, value, onChange, min, max, step, suffix }: { label: string; value: number; onChange: (val: number) => void; min: number; max: number; step: number; suffix?: string }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
        <span className="text-sm text-hf-red font-medium">{value}{suffix && <span className="text-hf-text-muted">{suffix}</span>}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-full h-1.5 bg-hf-border-subtle rounded-full appearance-none cursor-pointer" style={{ background: `linear-gradient(to right, #D6001C ${pct}%, #1E293B ${pct}%)` }} />
    </div>
  );
}

export default function Settings() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [saved, setSaved] = useState(false);

  const update = <K extends keyof Omit<FormState, "emulation" | "platforms">>(field: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  };

  const updateEmulation = <K extends keyof EmulationSettings>(field: K, value: EmulationSettings[K]) => {
    setForm((prev) => ({ ...prev, emulation: { ...prev.emulation, [field]: value } }));
    setSaved(false);
  };

  const updatePlatform = (platform: JobPlatform, key: "enabled" | "login" | "password", value: boolean | string) => {
    setForm((prev) => ({
      ...prev,
      platforms: { ...prev.platforms, [platform]: { ...prev.platforms[platform], [key]: value } },
    }));
    setSaved(false);
  };

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 3000); };

  return (
    <div className="max-w-4xl space-y-4">
      <div className="flex items-center justify-between bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Настройки Assistant Job</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">Все 10 площадок, параметры поиска, имитация человека</p>
        </div>
        <button onClick={handleSave} className={cn("flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all", saved ? "bg-hf-green text-white" : "bg-hf-red text-white hover:brightness-110")}>
          <Save size={14} />{saved ? "Сохранено!" : "Сохранить"}
        </button>
      </div>

      {/* ─── HUMAN EMULATION ─── */}
      <div className="bg-hf-elevated border border-hf-amber/30 rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-hf-amber to-[#F59E0B80] flex items-center justify-center">
            <Bot size={22} className="text-white" strokeWidth={2} />
          </div>
          <div>
            <h3 className="text-base font-semibold text-hf-amber">Режим имитации человека</h3>
            <p className="text-xs text-hf-text-secondary">Browser automation — имитация реальных действий пользователя без API</p>
          </div>
        </div>
        <Toggle label="Включить имитацию человека" description="Бот управляет реальным браузером, имитируя действия живого пользователя" checked={form.emulation.enabled} onChange={() => updateEmulation("enabled", !form.emulation.enabled)} />
        {form.emulation.enabled && (
          <div className="mt-5 space-y-5 pt-5 border-t border-hf-border-subtle">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Браузер</label>
                <select value={form.emulation.browserType} onChange={(e) => updateEmulation("browserType", e.target.value as "chromium" | "firefox" | "webkit")} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors">
                  <option value="chromium">Chromium (рекомендуется)</option>
                  <option value="firefox">Firefox</option>
                  <option value="webkit">WebKit (Safari)</option>
                </select>
              </div>
              <div className="flex items-center pt-5">
                <Toggle label="Headless режим (без окна)" description="Запускать браузер в фоновом режиме" checked={form.emulation.headless} onChange={() => updateEmulation("headless", !form.emulation.headless)} />
              </div>
            </div>
            <SectionTitle title="Защита от детектирования" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Toggle label="Stealth-режим" description="Скрывает автоматизацию от систем обнаружения" checked={form.emulation.useStealth} onChange={() => updateEmulation("useStealth", !form.emulation.useStealth)} />
              <Toggle label="Ротация User-Agent" description="Случайный выбор User-Agent при каждой сессии" checked={form.emulation.rotateUserAgent} onChange={() => updateEmulation("rotateUserAgent", !form.emulation.rotateUserAgent)} />
            </div>
            {form.emulation.rotateUserAgent && <Input label="Список User-Agent (по одному на строку)" multiline rows={3} value={form.emulation.userAgents} onChange={(v) => updateEmulation("userAgents", v)} />}
            <SectionTitle title="Задержки и скорость" />
            <div className="space-y-4">
              <SliderInput label="Задержка между действиями (мин)" value={form.emulation.randomDelayMin} onChange={(v) => updateEmulation("randomDelayMin", v)} min={1000} max={30000} step={500} suffix=" мс" />
              <SliderInput label="Задержка между действиями (макс)" value={form.emulation.randomDelayMax} onChange={(v) => updateEmulation("randomDelayMax", v)} min={3000} max={60000} step={500} suffix=" мс" />
              <SliderInput label="Скорость печати (мин)" value={form.emulation.typingSpeedMin} onChange={(v) => updateEmulation("typingSpeedMin", v)} min={10} max={300} step={10} suffix=" мс/символ" />
              <SliderInput label="Скорость печати (макс)" value={form.emulation.typingSpeedMax} onChange={(v) => updateEmulation("typingSpeedMax", v)} min={50} max={500} step={10} suffix=" мс/символ" />
            </div>
            <SectionTitle title="Поведение человека" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Toggle label="Случайный скролл страницы" checked={form.emulation.randomScroll} onChange={() => updateEmulation("randomScroll", !form.emulation.randomScroll)} />
              <Toggle label="Случайные движения мыши" checked={form.emulation.randomMouseMove} onChange={() => updateEmulation("randomMouseMove", !form.emulation.randomMouseMove)} />
              <Toggle label="Имитация чтения вакансии" checked={form.emulation.simulateReading} onChange={() => updateEmulation("simulateReading", !form.emulation.simulateReading)} />
              <Toggle label="Случайный порядок откликов" checked={form.emulation.randomizeOrder} onChange={() => updateEmulation("randomizeOrder", !form.emulation.randomizeOrder)} />
              <Toggle label="Случайные паузы между откликами" checked={form.emulation.addRandomPause} onChange={() => updateEmulation("addRandomPause", !form.emulation.addRandomPause)} />
            </div>
            {form.emulation.simulateReading && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                <SliderInput label="Время чтения (мин)" value={form.emulation.readingTimeMin} onChange={(v) => updateEmulation("readingTimeMin", v)} min={1000} max={10000} step={500} suffix=" мс" />
                <SliderInput label="Время чтения (макс)" value={form.emulation.readingTimeMax} onChange={(v) => updateEmulation("readingTimeMax", v)} min={3000} max={30000} step={500} suffix=" мс" />
              </div>
            )}
            <SectionTitle title="Прокси" />
            <Toggle label="Использовать прокси" checked={form.emulation.useProxy} onChange={() => updateEmulation("useProxy", !form.emulation.useProxy)} />
            {form.emulation.useProxy && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                <Input label="Хост" value={form.emulation.proxyHost} onChange={(v) => updateEmulation("proxyHost", v)} placeholder="127.0.0.1" />
                <Input label="Порт" value={form.emulation.proxyPort} onChange={(v) => updateEmulation("proxyPort", v)} placeholder="8080" />
                <Input label="Логин" value={form.emulation.proxyUsername} onChange={(v) => updateEmulation("proxyUsername", v)} />
                <PasswordInput label="Пароль" value={form.emulation.proxyPassword} onChange={(v) => updateEmulation("proxyPassword", v)} />
              </div>
            )}
            <SectionTitle title="CAPTCHA" />
            <Toggle label="Обрабатывать CAPTCHA автоматически" checked={form.emulation.handleCaptcha} onChange={() => updateEmulation("handleCaptcha", !form.emulation.handleCaptcha)} />
            {form.emulation.handleCaptcha && <div className="mt-3"><PasswordInput label="API-ключ сервиса распознавания" value={form.emulation.captchaApiKey} onChange={(v) => updateEmulation("captchaApiKey", v)} /></div>}
            <SectionTitle title="Ограничения сессии" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <SliderInput label="Макс. длительность сессии" value={form.emulation.sessionDurationLimit} onChange={(v) => updateEmulation("sessionDurationLimit", v)} min={10} max={120} step={5} suffix=" мин" />
              <SliderInput label="Макс. попыток при ошибке" value={form.emulation.maxRetries} onChange={(v) => updateEmulation("maxRetries", v)} min={1} max={10} step={1} suffix=" попыток" />
              <SliderInput label="Задержка между повторами" value={form.emulation.retryDelay} onChange={(v) => updateEmulation("retryDelay", v)} min={5} max={300} step={5} suffix=" сек" />
              <SliderInput label="Вероятность случайной паузы" value={form.emulation.pauseProbability} onChange={(v) => updateEmulation("pauseProbability", v)} min={0} max={50} step={5} suffix="%" />
            </div>
          </div>
        )}
      </div>

      {/* Profile */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Профиль" subtitle="Ваши контактные данные" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="ФИО" value={form.fullName} onChange={(v) => update("fullName", v)} />
          <Input label="Email" type="email" value={form.email} onChange={(v) => update("email", v)} />
          <Input label="Телефон" value={form.phone} onChange={(v) => update("phone", v)} />
        </div>
      </div>

      {/* Search */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Поиск вакансий" subtitle="Параметры поиска на всех площадках" />
        <div className="space-y-4">
          <Input label="Ключевой запрос" value={form.searchQuery} onChange={(v) => update("searchQuery", v)} />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Input label="Регион" value={form.region} onChange={(v) => update("region", v)} />
            <Input label="Зарплата от" type="number" value={form.salaryFrom} onChange={(v) => update("salaryFrom", v)} />
            <Input label="Зарплата до" type="number" value={form.salaryTo} onChange={(v) => update("salaryTo", v)} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label>
              <select value={form.experience} onChange={(e) => update("experience", e.target.value)} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors">
                <option value="noExperience">Нет опыта</option>
                <option value="between1And3">1–3 года</option>
                <option value="between3And6">3–6 лет</option>
                <option value="moreThan6">Более 6 лет</option>
              </select>
            </div>
            <div className="flex items-center pt-5">
              <Toggle label="Только удалённая работа" checked={form.remote} onChange={() => update("remote", !form.remote)} />
            </div>
          </div>
        </div>
      </div>

      {/* Cover Letter */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Сопроводительное письмо" subtitle="{company}, {position}, {candidate_name}" />
        <Input label="Шаблон" multiline rows={8} value={form.coverLetter} onChange={(v) => update("coverLetter", v)} />
      </div>

      {/* ─── 10 PLATFORMS + CREDENTIALS ─── */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Площадки для поиска" subtitle="Активируйте площадки и введите учётные данные для авторизации" />
        <div className="space-y-4">
          {allPlatforms.map((key) => {
            const cfg = platformConfig[key];
            const plat = form.platforms[key];
            return (
              <div key={key} className={cn("border rounded-[10px] p-4 transition-all", plat.enabled ? "border-hf-red/40 bg-hf-red/[0.03]" : "border-hf-border-subtle")}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Toggle label={cfg.label} checked={plat.enabled} onChange={() => updatePlatform(key, "enabled", !plat.enabled)} />
                    <span className={cn("text-xs px-2 py-0.5 rounded font-medium", cfg.bg, cfg.color)}>{cfg.domain}</span>
                  </div>
                </div>
                {plat.enabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 pl-[52px]">
                    <Input label={`Логин (${cfg.domain})`} value={plat.login} onChange={(v) => updatePlatform(key, "login", v)} />
                    <PasswordInput label={`Пароль (${cfg.domain})`} value={plat.password} onChange={(v) => updatePlatform(key, "password", v)} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bot Settings */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Поведение бота" subtitle="Скорость и ограничения" />
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Задержка между откликами</label>
              <div className="flex items-center gap-2">
                <input type="number" min={1} max={120} value={form.delayMin} onChange={(e) => update("delayMin", Number(e.target.value))} className="w-16 bg-hf-base border border-hf-border-subtle rounded-lg px-2 py-1.5 text-sm text-hf-text-primary text-center focus:outline-none focus:border-hf-red" />
                <span className="text-hf-text-muted">—</span>
                <input type="number" min={1} max={120} value={form.delayMax} onChange={(e) => update("delayMax", Number(e.target.value))} className="w-16 bg-hf-base border border-hf-border-subtle rounded-lg px-2 py-1.5 text-sm text-hf-text-primary text-center focus:outline-none focus:border-hf-red" />
                <span className="text-xs text-hf-text-muted">сек</span>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Макс. откликов за сессию</label>
              <input type="number" min={1} max={100} value={form.maxApplies} onChange={(e) => update("maxApplies", Number(e.target.value))} className="w-20 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-1.5 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red" />
            </div>
          </div>
          <Input label="Чёрный список компаний (через запятую)" value={form.skipCompanies} onChange={(v) => update("skipCompanies", v)} placeholder="Компании для пропуска..." />
        </div>
      </div>

      {/* Telegram */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Telegram уведомления" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <PasswordInput label="Bot Token" value={form.telegramToken} onChange={(v) => update("telegramToken", v)} />
          <Input label="Chat ID" value={form.telegramChatId} onChange={(v) => update("telegramChatId", v)} />
        </div>
      </div>
    </div>
  );
}

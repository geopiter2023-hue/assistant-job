import { useState } from "react";
import { Clock, CheckCircle, XCircle, Calendar, Plus, Trash2, Bot } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { tasksData } from "@/lib/data";
import type { BotTask } from "@/lib/data";
import PlatformBadge from "@/components/PlatformBadge";

function StatusIcon({ status }: { status: BotTask["status"] }) {
  switch (status) {
    case "running": return <Clock size={14} className="text-hf-cyan" />;
    case "completed": return <CheckCircle size={14} className="text-hf-green" />;
    case "failed": return <XCircle size={14} className="text-hf-red" />;
    case "scheduled": return <Calendar size={14} className="text-hf-amber" />;
  }
}

function StatusBadge({ status }: { status: BotTask["status"] }) {
  const config = {
    running: { label: "Выполняется", bg: "bg-[#06B6D420]", text: "text-hf-cyan" },
    completed: { label: "Завершена", bg: "bg-[#10B98120]", text: "text-hf-green" },
    failed: { label: "Ошибка", bg: "bg-[#EF444420]", text: "text-hf-red" },
    scheduled: { label: "Запланирована", bg: "bg-[#F59E0B20]", text: "text-hf-amber" },
  };
  const c = config[status];
  return <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium", c.bg, c.text)}><StatusIcon status={status} />{c.label}</span>;
}

export default function Tasks() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const { data: sessions = [] } = trpc.session.list.useQuery({ userId: user?.id ?? 0 }, { enabled: !!user, staleTime: 10000 });
  const createSession = trpc.session.create.useMutation({ onSuccess: () => utils.session.list.invalidate() });
  const deleteSession = trpc.session.delete.useMutation({ onSuccess: () => utils.session.list.invalidate() });
  const [showCreate, setShowCreate] = useState(false);
  const [newTaskQuery, setNewTaskQuery] = useState("");

  const tasks: BotTask[] = sessions.length > 0 ? sessions.map((s) => ({
    id: String(s.id), name: s.name, status: s.status as BotTask["status"],
    platform: s.platform as BotTask["platform"],
    query: s.query, resultsFound: s.resultsFound ?? 0, appliesSent: s.appliesSent ?? 0,
    createdAt: s.createdAt ? new Date(s.createdAt).toLocaleString("ru-RU") : "",
    completedAt: s.completedAt ? new Date(s.completedAt).toLocaleString("ru-RU") : undefined,
    emulationMode: s.emulationMode ?? true,
  })) : tasksData;

  const handleCreate = () => {
    if (!newTaskQuery.trim() || !user) return;
    createSession.mutate({ userId: user.id, name: `Сессия #${tasks.length + 1}`, query: newTaskQuery, platform: "all" });
    setNewTaskQuery(""); setShowCreate(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="text-sm text-hf-text-secondary space-y-1">
          <p>Всего задач: <span className="text-hf-text-primary font-medium">{tasks.length}</span>{tasks.filter((t) => t.status === "running").length > 0 && <span className="ml-3 text-hf-cyan">• Выполняется: {tasks.filter((t) => t.status === "running").length}</span>}</p>
          <p className="flex items-center gap-1.5 text-xs"><Bot size={12} className="text-hf-amber" /><span className="text-hf-amber">Режим имитации человека через браузер (без API)</span></p>
        </div>
        {user && <button onClick={() => setShowCreate(!showCreate)} className="flex items-center gap-2 px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all self-start"><Plus size={16} />Новая задача</button>}
      </div>

      {showCreate && (
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card space-y-3">
          <h3 className="text-sm font-medium text-hf-text-primary">Новая задача поиска</h3>
          <div className="flex flex-col sm:flex-row gap-3">
            <input type="text" placeholder="Ключевое слово поиска" value={newTaskQuery} onChange={(e) => setNewTaskQuery(e.target.value)} className="flex-1 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-blue transition-colors" onKeyDown={(e) => e.key === "Enter" && handleCreate()} />
            <div className="flex gap-2">
              <button onClick={handleCreate} className="px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all">Создать</button>
              <button onClick={() => setShowCreate(false)} className="px-4 py-2 bg-hf-base text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary transition-colors">Отмена</button>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 bg-hf-amber/10 rounded-lg border border-hf-amber/20"><Bot size={14} className="text-hf-amber flex-shrink-0" /><span className="text-xs text-hf-amber">Задача будет выполнена в режиме имитации человека через браузер</span></div>
        </div>
      )}

      <div className="hidden md:block bg-hf-elevated border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-hf-border-subtle">
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАДАЧА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАПРОС</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ПЛОЩАДКА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">НАЙДЕНО</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ОТКЛИКОВ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">СТАТУС</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">РЕЖИМ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[50px]"></th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((t) => (
              <tr key={t.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-[#1E2A4260] transition-colors">
                <td className="px-5 py-3.5 text-sm text-hf-text-primary font-medium">{t.name}</td>
                <td className="px-5 py-3.5 text-sm text-hf-text-secondary">{t.query}</td>
                <td className="px-5 py-3.5 text-center"><PlatformBadge platform={t.platform as import("@/lib/data").JobPlatform} /></td>
                <td className="px-5 py-3.5 text-sm text-hf-text-primary text-center">{t.resultsFound}</td>
                <td className="px-5 py-3.5 text-sm text-hf-text-primary text-center">{t.appliesSent}</td>
                <td className="px-5 py-3.5"><StatusBadge status={t.status} /></td>
                <td className="px-5 py-3.5 text-center"><span className="inline-flex items-center gap-1 text-xs text-hf-amber bg-hf-amber/10 px-2 py-0.5 rounded"><Bot size={10} />Браузер</span></td>
                <td className="px-5 py-3.5 text-center"><button onClick={() => deleteSession.mutate({ id: Number(t.id) })} className="text-hf-text-muted hover:text-hf-red transition-colors p-1"><Trash2 size={14} /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {tasks.map((t) => (
          <div key={t.id} className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap"><span className="text-sm text-hf-text-primary font-medium">{t.name}</span><StatusBadge status={t.status} /></div>
                <p className="text-xs text-hf-text-secondary mt-1">{t.query}</p>
              </div>
              <button onClick={() => deleteSession.mutate({ id: Number(t.id) })} className="text-hf-text-muted hover:text-hf-red transition-colors flex-shrink-0 p-1"><Trash2 size={14} /></button>
            </div>
            <div className="flex flex-wrap items-center gap-3 mt-3">
              <PlatformBadge platform={t.platform as import("@/lib/data").JobPlatform} />
              <span className="text-xs text-hf-text-secondary">{t.resultsFound} найдено</span>
              <span className="text-xs text-hf-text-secondary">{t.appliesSent} откликов</span>
            </div>
            <div className="flex items-center gap-2 mt-2"><span className="inline-flex items-center gap-1 text-xs text-hf-amber bg-hf-amber/10 px-2 py-0.5 rounded"><Bot size={10} />Имитация человека</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}

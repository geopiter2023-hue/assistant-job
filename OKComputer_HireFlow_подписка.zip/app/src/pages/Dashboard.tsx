import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { Check, X, Bot, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { kpiStats, weeklyActivity, recentApplications } from "@/lib/data";
import PlatformBadge from "@/components/PlatformBadge";

import type { BotStatus } from "@/lib/data";

/* ─── tooltip types ─── */
interface TooltipPayloadItem {
  value: number;
  dataKey: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="bg-hf-highlight border border-hf-border-subtle rounded-md px-3 py-2 shadow-lg">
      <p className="text-xs text-hf-text-secondary">{label}</p>
      <p className="text-sm font-medium text-hf-text-primary">
        {payload[0].value} откликов
      </p>
    </div>
  );
}

/* ─── KPI Cards ─── */
function KPICards({ botStatus, stats }: { botStatus: BotStatus; stats?: { total: number; success: number; error: number; conversionRate: string } }) {
  const s = stats ?? { total: kpiStats.totalApplies, success: kpiStats.successfulApplies, error: 0, conversionRate: kpiStats.conversionRate };

  const statusDotColor: Record<BotStatus, string> = {
    running: "bg-hf-green", idle: "bg-hf-text-muted", paused: "bg-hf-amber", error: "bg-hf-red",
  };
  const statusTextColor: Record<BotStatus, string> = {
    running: "text-hf-green", idle: "text-hf-text-muted", paused: "text-hf-amber", error: "text-hf-red",
  };
  const statusLabels: Record<BotStatus, string> = {
    running: "Работает", idle: "Ожидание", paused: "Пауза", error: "Ошибка",
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3 lg:gap-4">
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 lg:p-5 shadow-card hover:shadow-card-hover hover:border-[#3B82F640] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">ВСЕГО ОТКЛИКОВ</p>
        <p className="text-3xl lg:text-4xl font-bold text-hf-blue mt-1">{s.total}</p>
        <p className="text-xs text-hf-text-secondary mt-1">+12 за сегодня</p>
      </div>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 lg:p-5 shadow-card hover:shadow-card-hover hover:border-[#3B82F640] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">УСПЕШНЫХ</p>
        <p className="text-3xl lg:text-4xl font-bold text-hf-green mt-1">{s.success}</p>
        <p className="text-xs text-hf-text-secondary mt-1">{s.conversionRate} конверсия</p>
      </div>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 lg:p-5 shadow-card hover:shadow-card-hover hover:border-[#3B82F640] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">СЕГОДНЯ</p>
        <p className="text-3xl lg:text-4xl font-bold text-hf-cyan mt-1">{kpiStats.todayApplies}</p>
        <p className="text-xs text-hf-text-secondary mt-1">{kpiStats.todayPending}</p>
      </div>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 lg:p-5 shadow-card hover:shadow-card-hover hover:border-[#3B82F640] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">СТАТУС БОТА</p>
        <div className="flex items-center gap-2 mt-2">
          {botStatus === "running" ? (
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-hf-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-hf-green" />
            </span>
          ) : (
            <span className={cn("h-2.5 w-2.5 rounded-full", statusDotColor[botStatus])} />
          )}
          <span className={cn("text-sm font-medium", statusTextColor[botStatus])}>{statusLabels[botStatus]}</span>
        </div>
        <p className="text-xs text-hf-text-muted mt-1">Сессия {kpiStats.sessionId}</p>
      </div>
      <div className="bg-hf-elevated border border-hf-amber/30 rounded-[10px] p-4 lg:p-5 shadow-card hover:shadow-card-hover hover:border-hf-amber/60 transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">РЕЖИМ РАБОТЫ</p>
        <div className="flex items-center gap-2 mt-2">
          <Bot size={16} className="text-hf-amber flex-shrink-0" />
          <span className="text-sm font-medium text-hf-amber">Имитация человека</span>
        </div>
        <div className="flex items-center gap-1.5 mt-1">
          <Shield size={10} className="text-hf-green" />
          <span className="text-xs text-hf-green">Stealth ON</span>
        </div>
      </div>
    </div>
  );
}

function ActivityChart({ data }: { data: Array<{ day: string; count: number }> }) {
  return (
    <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 lg:p-6 shadow-card">
      <h2 className="text-base lg:text-lg font-bold text-hf-text-primary mb-4 lg:mb-6">📈 Активность за неделю</h2>
      <div className="h-[220px] sm:h-[260px] lg:h-[280px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="4 4" stroke="#1E293B" strokeOpacity={0.5} vertical={false} />
            <XAxis dataKey="day" tick={{ fill: "#64748B", fontSize: 12 }} axisLine={{ stroke: "#1E293B" }} tickLine={false} />
            <YAxis tick={{ fill: "#64748B", fontSize: 12 }} axisLine={{ stroke: "#1E293B" }} tickLine={false} domain={[0, 20]} ticks={[0, 5, 10, 15, 20]} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="count" stroke="#3B82F6" strokeWidth={2} fill="url(#activityGradient)"
              dot={{ r: 4, fill: "#3B82F6", stroke: "#151D2E", strokeWidth: 2 }}
              activeDot={{ r: 6, fill: "#3B82F6", stroke: "#151D2E", strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function RecentApplications() {
  return (
    <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
      <h2 className="text-base lg:text-lg font-bold text-hf-text-primary px-4 lg:px-6 pt-4 lg:pt-5 pb-3 lg:pb-4">📋 Последние отклики</h2>
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-hf-border-subtle">
              <th className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium text-center px-6 py-3 w-[100px]">СТАТУС</th>
              <th className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium text-left px-6 py-3">ВАКАНСИЯ</th>
              <th className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium text-left px-6 py-3 w-[140px]">КОМПАНИЯ</th>
              <th className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium text-center px-6 py-3 w-[100px]">ПЛАТФОРМА</th>
              <th className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium text-right px-6 py-3 w-[100px]">ВРЕМЯ</th>
            </tr>
          </thead>
          <tbody>
            {recentApplications.slice(0, 5).map((app) => (
              <tr key={app.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-[#1E2A4260] transition-colors duration-100">
                <td className="px-6 py-3.5 text-center">
                  <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium", app.status === "success" ? "bg-[#10B98120] text-hf-green" : "bg-[#EF444420] text-hf-red")}>
                    {app.status === "success" ? <Check size={12} strokeWidth={2.5} /> : <X size={12} strokeWidth={2.5} />}
                    {app.statusLabel}
                  </span>
                </td>
                <td className="px-6 py-3.5"><a href={app.vacancyUrl} className="text-sm text-hf-blue hover:underline">{app.vacancy}</a></td>
                <td className="px-6 py-3.5 text-sm text-hf-text-primary">{app.company}</td>
                <td className="px-6 py-3.5 text-center">
                  <PlatformBadge platform={app.platform as import("@/lib/data").JobPlatform} />
                </td>
                <td className="px-6 py-3.5 text-sm text-hf-text-muted text-right">{app.timeAgo}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="md:hidden divide-y divide-hf-border-subtle">
        {recentApplications.slice(0, 5).map((app) => (
          <div key={app.id} className="px-4 py-3.5 hover:bg-[#1E2A4260] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <a href={app.vacancyUrl} className="text-sm text-hf-blue hover:underline block truncate">{app.vacancy}</a>
                <p className="text-xs text-hf-text-secondary mt-0.5">{app.company}</p>
              </div>
              <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium flex-shrink-0", app.status === "success" ? "bg-[#10B98120] text-hf-green" : "bg-[#EF444420] text-hf-red")}>
                {app.status === "success" ? <Check size={10} /> : <X size={10} />}{app.statusLabel}
              </span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <PlatformBadge platform={app.platform as import("@/lib/data").JobPlatform} />
              <span className="text-xs text-hf-text-muted">{app.timeAgo}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [botStatus] = useState<BotStatus>(kpiStats.botStatus);
  const { user } = useAuth();

  // Use real stats from backend if logged in, fallback to demo data
  const { data: stats } = trpc.apply.stats.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user, staleTime: 30000 }
  );

  // Use weekly activity from backend if logged in
  const { data: weeklyData } = trpc.apply.weeklyActivity.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user, staleTime: 30000 }
  );

  const chartData = weeklyData && weeklyData.length > 0 ? weeklyData : weeklyActivity;

  return (
    <div className="space-y-4 lg:space-y-4">
      <div className="animate-fade-in-up" style={{ animationDelay: "0ms" }}>
        <KPICards botStatus={botStatus} stats={stats ?? undefined} />
      </div>
      <div className="animate-fade-in-up opacity-0" style={{ animationDelay: "100ms" }}>
        <ActivityChart data={chartData} />
      </div>
      <div className="animate-fade-in-up opacity-0" style={{ animationDelay: "200ms" }}>
        <RecentApplications />
      </div>
    </div>
  );
}

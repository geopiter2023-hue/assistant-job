import { useState } from "react";
import { Plus, Trash2, Pencil, Star, Check, X, Download, Globe, Loader } from "lucide-react";
import { cn } from "@/lib/utils";

interface Resume {
  id: string;
  title: string;
  summary: string;
  skills: string;
  experience: string;
  education: string;
  languages: string;
  desiredSalary: string;
  desiredPosition: string;
  isDefault: boolean;
  source?: "manual" | "hh";
}

const demoResumes: Resume[] = [
  {
    id: "1",
    title: "Python разработчик (Backend)",
    summary: "Опытный Python-разработчик с 5-летним стажем в разработке высоконагруженных backend-систем. Специализация: микросервисная архитектура, асинхронное программирование, DevOps-практики.",
    skills: "Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Redis, RabbitMQ, asyncio, Git, CI/CD",
    experience: "Senior Python Developer, Яндекс (2021-2024)\nMiddle Python Developer, Тинькофф (2019-2021)\nJunior Python Developer, Стартап X (2018-2019)",
    education: "МГУ им. Ломоносова, Факультет ВМК, Специалист (2014-2019)",
    languages: "Русский (родной), Английский (C1)",
    desiredSalary: "400 000 - 600 000 ₽",
    desiredPosition: "Senior Python Developer / Team Lead",
    isDefault: true,
    source: "manual",
  },
  {
    id: "2",
    title: "Fullstack разработчик (Python/React)",
    summary: "Fullstack-разработчик с опытом создания веб-приложений от прототипа до production. Комфортно себя чувствую и в backend, и в frontend.",
    skills: "Python, Django, FastAPI, JavaScript, TypeScript, React, Next.js, PostgreSQL, Docker, REST API, GraphQL",
    experience: "Fullstack Developer, Авито (2020-2024)\nFrontend Developer, VK (2018-2020)",
    education: "МФТИ, Факультет инноваций и высоких технологий (2014-2018)",
    languages: "Русский (родной), Английский (B2)",
    desiredSalary: "350 000 - 500 000 ₽",
    desiredPosition: "Fullstack Developer / Tech Lead",
    isDefault: false,
    source: "manual",
  },
];

// Demo HH resume list (what we'd get from parsing hh.ru/resume)
const hhResumeList = [
  { id: "hh_1", title: "Senior Python Developer", url: "https://hh.ru/resume/abc123", lastUpdated: "2 дня назад" },
  { id: "hh_2", title: "Backend Developer (Python/Django)", url: "https://hh.ru/resume/def456", lastUpdated: "1 неделю назад" },
  { id: "hh_3", title: "Python Tech Lead", url: "https://hh.ru/resume/ghi789", lastUpdated: "3 дня назад" },
];

// Parsed resume detail (what we'd get from parsing a single resume page)
const parsedResumeDetail: Resume = {
  id: "hh_parsed",
  title: "Senior Python Developer",
  summary: "Разработчик с 6-летним опытом в Python-экосистеме. Специализируюсь на проектировании микросервисных архитектур и высоконагруженных систем. Имею опыт управления командой из 5 разработчиков.",
  skills: "Python, Django, FastAPI, PostgreSQL, MongoDB, Docker, Kubernetes, Redis, Kafka, Celery, asyncio, gRPC, REST API, GraphQL, Git, CI/CD, Jenkins, GitLab CI, Nginx, Prometheus, Grafana",
  experience: `Senior Python Developer, Т-Банк (2022 — настоящее время)
• Проектирование архитектуры backend-сервисов (100k+ RPS)
• Управление командой из 5 разработчиков
• Внедрение микросервисной архитектуры

Middle Python Developer, Яндекс (2020 — 2022)
• Разработка сервисов на Python/FastAPI
• Интеграция с PostgreSQL, Redis, Kafka
• Написание юнит и интеграционных тестов

Junior Python Developer, СберТех (2019 — 2020)
• Поддержка существующих Django-приложений
• Разработка REST API endpoints`,
  education: "МГТУ им. Баумана, Факультет ИУ, Магистр (2017-2019)\nМГТУ им. Баумана, Факультет ИУ, Бакалавр (2013-2017)",
  languages: "Русский (родной), Английский (B2 — чтение технической документации, переписка)",
  desiredSalary: "500 000 — 700 000 ₽",
  desiredPosition: "Senior Python Developer / Team Lead Backend",
  isDefault: false,
  source: "hh",
};

function ResumeCard({ resume, onEdit, onDelete, onSetDefault }: {
  resume: Resume;
  onEdit: (r: Resume) => void;
  onDelete: (id: string) => void;
  onSetDefault: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={cn(
      "bg-hf-elevated border rounded-[10px] shadow-card transition-all",
      resume.isDefault ? "border-hf-blue/40 shadow-[0_0_12px_rgba(59,130,246,0.08)]" : "border-hf-border-subtle"
    )}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-semibold text-hf-text-primary">{resume.title}</h3>
              {resume.isDefault && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-hf-blue/20 text-hf-blue border border-hf-blue/30">
                  <Star size={10} /> По умолчанию
                </span>
              )}
              {resume.source === "hh" && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-[#3B82F620] text-hf-blue border border-[#3B82F630]">
                  <Globe size={10} /> HH.ru
                </span>
              )}
            </div>
            <p className="text-xs text-hf-text-secondary mt-1 line-clamp-2">{resume.summary}</p>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {!resume.isDefault && (
              <button onClick={() => onSetDefault(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-amber hover:bg-hf-amber/10 transition-colors" title="Сделать основным">
                <Star size={14} />
              </button>
            )}
            <button onClick={() => onEdit(resume)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-blue hover:bg-hf-blue/10 transition-colors" title="Редактировать">
              <Pencil size={14} />
            </button>
            <button onClick={() => onDelete(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 transition-colors" title="Удалить">
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {resume.skills.split(",").slice(0, 6).map((s) => (
            <span key={s.trim()} className="text-[11px] text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded border border-hf-border-subtle">{s.trim()}</span>
          ))}
          {resume.skills.split(",").length > 6 && <span className="text-[11px] text-hf-text-muted">+{resume.skills.split(",").length - 6}</span>}
        </div>

        <button onClick={() => setExpanded(!expanded)} className="text-xs text-hf-blue hover:underline mt-3 transition-colors">
          {expanded ? "Скрыть детали" : "Показать детали"}
        </button>

        {expanded && (
          <div className="mt-3 space-y-3 pt-3 border-t border-hf-border-subtle">
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</p><p className="text-xs text-hf-text-primary mt-1 whitespace-pre-line">{resume.experience}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</p><p className="text-xs text-hf-text-primary mt-1">{resume.education}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</p><p className="text-xs text-hf-text-primary mt-1">{resume.languages}</p></div>
            <div className="flex gap-4">
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Зарплата</p><p className="text-xs text-hf-green font-medium mt-1">{resume.desiredSalary}</p></div>
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Позиция</p><p className="text-xs text-hf-text-primary mt-1">{resume.desiredPosition}</p></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ResumeForm({ initial, onSave, onCancel }: {
  initial?: Resume;
  onSave: (data: Omit<Resume, "id">) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    title: initial?.title ?? "",
    summary: initial?.summary ?? "",
    skills: initial?.skills ?? "",
    experience: initial?.experience ?? "",
    education: initial?.education ?? "",
    languages: initial?.languages ?? "",
    desiredSalary: initial?.desiredSalary ?? "",
    desiredPosition: initial?.desiredPosition ?? "",
    isDefault: initial?.isDefault ?? false,
  });

  return (
    <div className="bg-hf-elevated border border-hf-blue/30 rounded-[10px] p-5 shadow-card">
      <h3 className="text-sm font-semibold text-hf-text-primary mb-4">{initial ? "✏️ Редактировать резюме" : "➕ Новое резюме"}</h3>
      <div className="space-y-3">
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Название резюме</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue" placeholder="Python разработчик" /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Краткое описание</label><textarea value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} rows={3} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue resize-none" placeholder="О себе..." /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Навыки (через запятую)</label><textarea value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} rows={2} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue resize-none" placeholder="Python, Django..." /></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label><textarea value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} rows={4} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue resize-none" placeholder="Должность, компания..." /></div>
          <div className="space-y-3">
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</label><input value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue" /></div>
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</label><input value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue" /></div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Ожидаемая зарплата</label><input value={form.desiredSalary} onChange={(e) => setForm({ ...form, desiredSalary: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue" placeholder="300 000 - 500 000 ₽" /></div>
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Желаемая позиция</label><input value={form.desiredPosition} onChange={(e) => setForm({ ...form, desiredPosition: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-blue" placeholder="Senior Python Developer" /></div>
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} className="accent-hf-blue" />
          <span className="text-sm text-hf-text-primary">Использовать по умолчанию</span>
        </label>
        <div className="flex gap-2 pt-2">
          <button onClick={() => onSave(form)} className="flex items-center gap-2 px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110"><Check size={14} />{initial ? "Сохранить" : "Создать"}</button>
          <button onClick={onCancel} className="px-4 py-2 bg-hf-base text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary"><X size={14} className="inline mr-1" />Отмена</button>
        </div>
      </div>
    </div>
  );
}

// ─── HH Import Modal ───
function HhImportModal({ onClose, onImport }: { onClose: () => void; onImport: (resume: Resume) => void }) {
  const [step, setStep] = useState<"login" | "list" | "parsing" | "preview">("login");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const handleLogin = () => {
    setStep("list");
  };

  const handleParse = (id: string) => {
    setSelectedId(id);
    setStep("parsing");
    setTimeout(() => {
      setStep("preview");
    }, 2500);
  };

  const handleImport = () => {
    onImport({ ...parsedResumeDetail, id: `hh_${Date.now()}` });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[14px] p-6 max-w-lg w-full shadow-2xl max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#3B82F620] border border-[#3B82F640] flex items-center justify-center">
              <Globe size={16} className="text-hf-blue" />
            </div>
            <div>
              <h3 className="text-base font-bold text-hf-text-primary">Импорт с HH.ru</h3>
              <p className="text-xs text-hf-text-secondary">Автоматический парсинг резюме</p>
            </div>
          </div>
          <button onClick={onClose} className="text-hf-text-muted hover:text-hf-text-primary transition-colors p-1"><X size={20} /></button>
        </div>

        {/* Progress */}
        <div className="flex items-center gap-2 mb-5">
          {[
            { key: "login", label: "Вход" },
            { key: "list", label: "Выбор" },
            { key: "parsing", label: "Парсинг" },
            { key: "preview", label: "Импорт" },
          ].map((s, i) => {
            const stepKeys = ["login", "list", "parsing", "preview"];
            const currentIdx = stepKeys.indexOf(step);
            const isActive = stepKeys.indexOf(s.key) <= currentIdx;
            return (
              <div key={s.key} className="flex items-center gap-2 flex-1">
                <div className={cn(
                  "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0",
                  isActive ? "bg-hf-blue text-white" : "bg-hf-border-subtle text-hf-text-muted"
                )}>{i + 1}</div>
                <span className={cn("text-[10px] hidden sm:inline", isActive ? "text-hf-text-primary" : "text-hf-text-muted")}>{s.label}</span>
                {i < 3 && <div className={cn("flex-1 h-0.5 rounded", isActive ? "bg-hf-blue" : "bg-hf-border-subtle")} />}
              </div>
            );
          })}
        </div>

        {/* Step 1: Login */}
        {step === "login" && (
          <div className="space-y-4">
            <div className="bg-hf-base rounded-lg p-4 border border-hf-border-subtle">
              <p className="text-xs text-hf-text-secondary mb-3">Бот войдёт в ваш аккаунт HH.ru и получит список резюме.</p>
              <div className="space-y-3">
                <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Email / Телефон</label><input defaultValue="ivan@example.com" className="w-full bg-hf-elevated border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1" /></div>
                <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Пароль</label><input type="password" defaultValue="••••••••" className="w-full bg-hf-elevated border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1" /></div>
              </div>
              <p className="text-[10px] text-hf-amber mt-2 flex items-center gap-1"><Globe size={10} />Данные берутся из настроек (HH.ru логин/пароль)</p>
            </div>
            <button onClick={handleLogin} className="w-full py-2.5 rounded-lg text-sm font-medium text-white bg-hf-blue hover:brightness-110 transition-all">Войти в HH.ru</button>
          </div>
        )}

        {/* Step 2: Resume List */}
        {step === "list" && (
          <div className="space-y-3">
            <p className="text-xs text-hf-text-secondary">Найдено <span className="text-hf-text-primary font-medium">{hhResumeList.length}</span> резюме в вашем аккаунте:</p>
            <div className="space-y-2">
              {hhResumeList.map((r) => (
                <div key={r.id} onClick={() => handleParse(r.id)} className={cn(
                  "flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-all",
                  selectedId === r.id ? "border-hf-blue bg-hf-blue/10" : "border-hf-border-subtle hover:border-hf-blue/40"
                )}>
                  <div>
                    <p className="text-sm text-hf-text-primary font-medium">{r.title}</p>
                    <p className="text-xs text-hf-text-secondary mt-0.5">{r.url}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-hf-text-muted">Обновлено</p>
                    <p className="text-xs text-hf-text-secondary">{r.lastUpdated}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Parsing */}
        {step === "parsing" && (
          <div className="text-center py-8 space-y-4">
            <div className="relative w-16 h-16 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-hf-border-subtle" />
              <div className="absolute inset-0 rounded-full border-4 border-hf-blue border-t-transparent animate-spin" />
              <Globe size={24} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-hf-blue" />
            </div>
            <div>
              <p className="text-sm text-hf-text-primary font-medium">Парсинг резюме...</p>
              <p className="text-xs text-hf-text-secondary mt-1">Бот открывает страницу резюме и извлекает данные</p>
            </div>
            <div className="space-y-1 text-left max-w-xs mx-auto">
              <div className="flex items-center gap-2 text-xs text-hf-text-secondary"><Loader size={10} className="animate-spin text-hf-blue" />Загрузка страницы...</div>
              <div className="flex items-center gap-2 text-xs text-hf-text-muted"><Check size={10} className="text-hf-green" />Авторизация</div>
              <div className="flex items-center gap-2 text-xs text-hf-text-muted"><Check size={10} className="text-hf-green" />Извлечение заголовка</div>
              <div className="flex items-center gap-2 text-xs text-hf-text-muted"><Check size={10} className="text-hf-green" />Извлечение навыков</div>
              <div className="flex items-center gap-2 text-xs text-hf-text-muted"><Check size={10} className="text-hf-green" />Извлечение опыта работы</div>
            </div>
          </div>
        )}

        {/* Step 4: Preview & Import */}
        {step === "preview" && (
          <div className="space-y-4">
            <div className="bg-hf-green/10 border border-hf-green/30 rounded-lg p-3 flex items-center gap-2">
              <Check size={16} className="text-hf-green flex-shrink-0" />
              <span className="text-xs text-hf-green">Резюме успешно распарсено! Найдено {parsedResumeDetail.skills.split(",").length} навыков, {parsedResumeDetail.experience.split("\n").filter(l => l.startsWith("•")).length} позиций.</span>
            </div>

            <div className="bg-hf-base rounded-lg p-4 border border-hf-border-subtle space-y-3 max-h-[40vh] overflow-y-auto">
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Название</p><p className="text-sm text-hf-text-primary mt-1 font-medium">{parsedResumeDetail.title}</p></div>
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Навыки</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {parsedResumeDetail.skills.split(",").slice(0, 8).map((s) => <span key={s.trim()} className="text-[10px] text-hf-text-secondary bg-hf-elevated px-2 py-0.5 rounded border border-hf-border-subtle">{s.trim()}</span>)}
                  {parsedResumeDetail.skills.split(",").length > 8 && <span className="text-[10px] text-hf-text-muted">+{parsedResumeDetail.skills.split(",").length - 8}</span>}
                </div>
              </div>
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт</p><p className="text-xs text-hf-text-primary mt-1 whitespace-pre-line">{parsedResumeDetail.experience}</p></div>
              <div className="flex gap-4">
                <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Зарплата</p><p className="text-xs text-hf-green font-medium mt-1">{parsedResumeDetail.desiredSalary}</p></div>
                <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Позиция</p><p className="text-xs text-hf-text-primary mt-1">{parsedResumeDetail.desiredPosition}</p></div>
              </div>
            </div>

            <div className="flex gap-2">
              <button onClick={handleImport} className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium text-white bg-gradient-to-r from-hf-blue to-hf-cyan hover:brightness-110 transition-all">
                <Download size={14} />Импортировать
              </button>
              <button onClick={() => setStep("list")} className="px-4 py-2.5 rounded-lg text-sm font-medium bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary transition-colors">
                Назад
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Resumes() {
  const [resumesList, setResumesList] = useState<Resume[]>(demoResumes);
  const [editing, setEditing] = useState<Resume | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showHhImport, setShowHhImport] = useState(false);

  const handleCreate = (data: Omit<Resume, "id">) => {
    const newResume: Resume = { ...data, id: String(Date.now()), source: "manual" };
    if (data.isDefault) setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: false })).concat(newResume));
    else setResumesList((prev) => [...prev, newResume]);
    setShowCreate(false);
  };

  const handleUpdate = (data: Omit<Resume, "id">) => {
    if (!editing) return;
    if (data.isDefault) setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : { ...r, isDefault: false })));
    else setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : r)));
    setEditing(null);
  };

  const handleDelete = (id: string) => setResumesList((prev) => prev.filter((r) => r.id !== id));
  const handleSetDefault = (id: string) => setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: r.id === id })));

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="flex items-center justify-between bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Мои резюме</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">До 5 резюме с разными навыками для разных типов вакансий</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setShowCreate(true); setEditing(null); }} className="flex items-center gap-2 px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all" disabled={resumesList.length >= 5}>
            <Plus size={16} />{resumesList.length >= 5 ? "Лимит" : "Добавить"}
          </button>
        </div>
      </div>

      {/* HH Import Banner */}
      <div className="bg-gradient-to-r from-[#3B82F610] to-[#3B82F605] border border-[#3B82F630] rounded-[10px] p-4 shadow-card">
        <div className="flex items-center justify-between gap-4 flex-col sm:flex-row">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#3B82F620] border border-[#3B82F640] flex items-center justify-center flex-shrink-0">
              <Globe size={20} className="text-hf-blue" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-hf-text-primary">Импорт с HH.ru</h3>
              <p className="text-xs text-hf-text-secondary mt-0.5">Автоматический парсинг резюме из вашего аккаунта HH.ru</p>
            </div>
          </div>
          <button onClick={() => setShowHhImport(true)} className="flex items-center gap-2 px-4 py-2 bg-hf-blue text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all flex-shrink-0">
            <Download size={14} />Импортировать
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p>
          <p className="text-2xl font-bold text-hf-text-primary mt-1">{resumesList.length} <span className="text-sm text-hf-text-muted">/ 5</span></p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">По умолчанию</p>
          <p className="text-2xl font-bold text-hf-blue mt-1">{resumesList.filter((r) => r.isDefault).length}</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">С HH.ru</p>
          <p className="text-2xl font-bold text-hf-green mt-1">{resumesList.filter((r) => r.source === "hh").length}</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Навыков (ср.)</p>
          <p className="text-2xl font-bold text-hf-cyan mt-1">{Math.round(resumesList.reduce((acc, r) => acc + r.skills.split(",").length, 0) / (resumesList.length || 1))}</p>
        </div>
      </div>

      {showCreate && <ResumeForm onSave={handleCreate} onCancel={() => setShowCreate(false)} />}
      {editing && <ResumeForm initial={editing} onSave={handleUpdate} onCancel={() => setEditing(null)} />}
      {showHhImport && <HhImportModal onClose={() => setShowHhImport(false)} onImport={(resume) => { setResumesList((prev) => [{ ...resume, isDefault: prev.length === 0 }, ...prev]); setShowHhImport(false); }} />}

      <div className="space-y-3">
        {resumesList.map((resume) => (
          <ResumeCard key={resume.id} resume={resume} onEdit={setEditing} onDelete={handleDelete} onSetDefault={handleSetDefault} />
        ))}
      </div>
    </div>
  );
}

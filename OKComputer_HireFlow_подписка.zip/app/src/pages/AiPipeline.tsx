import { useState } from "react";
import { Sparkles, FileText, Pencil, Send, Check, Loader, Eye, Download } from "lucide-react";
import { cn } from "@/lib/utils";

interface PipelineStep {
  id: number;
  title: string;
  description: string;
  icon: React.ElementType;
  status: "pending" | "running" | "completed" | "error";
}

const demoSteps: PipelineStep[] = [
  { id: 1, title: "Анализ вакансии", description: "AI читает требования и выделяет ключевые навыки", icon: Eye, status: "completed" },
  { id: 2, title: "Адаптация резюме", description: "AI редактирует резюме под требования вакансии", icon: Pencil, status: "completed" },
  { id: 3, title: "Сопроводительное письмо", description: "AI пишет персонализированное письмо", icon: FileText, status: "running" },
  { id: 4, title: "Отправка отклика", description: "Бот отправляет отклик с адаптированным резюме и письмом", icon: Send, status: "pending" },
];

function StepCard({ step, isActive }: { step: PipelineStep; isActive: boolean }) {
  const Icon = step.icon;
  const statusConfig = {
    pending: { bg: "bg-hf-border-subtle", text: "text-hf-text-muted", border: "border-hf-border-subtle", label: "Ожидание" },
    running: { bg: "bg-hf-amber/20", text: "text-hf-amber", border: "border-hf-amber/40", label: "В процессе..." },
    completed: { bg: "bg-hf-green/20", text: "text-hf-green", border: "border-hf-green/40", label: "Готово" },
    error: { bg: "bg-hf-red/20", text: "text-hf-red", border: "border-hf-red/40", label: "Ошибка" },
  };
  const cfg = statusConfig[step.status];

  return (
    <div className={cn(
      "relative flex gap-4 p-4 rounded-[10px] border transition-all",
      isActive ? cn(cfg.border, "bg-hf-elevated shadow-card") : "border-hf-border-subtle bg-hf-elevated/50"
    )}>
      <div className={cn("flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center", cfg.bg)}>
        {step.status === "running" ? <Loader size={18} className={cn("animate-spin", cfg.text)} /> : <Icon size={18} className={cfg.text} />}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <h4 className="text-sm font-semibold text-hf-text-primary">Шаг {step.id}: {step.title}</h4>
          <span className={cn("text-[10px] px-2 py-0.5 rounded-full font-medium border", cfg.bg, cfg.text, cfg.border)}>{cfg.label}</span>
        </div>
        <p className="text-xs text-hf-text-secondary mt-0.5">{step.description}</p>
      </div>
    </div>
  );
}

export default function AiPipeline() {
  const [activeStep, setActiveStep] = useState(2);
  const [vacancyUrl, setVacancyUrl] = useState("");
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [editedResume, setEditedResume] = useState<string | null>(null);
  const [coverLetter, setCoverLetter] = useState<string | null>(null);

  const handleAnalyze = () => {
    if (!vacancyUrl.trim()) return;
    setActiveStep(0);
    setTimeout(() => {
      setActiveStep(1);
      setAnalysisResult(`## Анализ вакансии

**Компания:** Яндекс
**Позиция:** Senior Python Developer
**Платформа:** HH.ru

### Требования:
- Python 3.9+, Django / FastAPI
- PostgreSQL, Redis, Kafka
- Docker, Kubernetes
- Опыт от 3 лет
- Английский B1+

### Ключевые навыки:
Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, REST API, asyncio, Git

### Совпадение с вашим резюме: 85%

### Рекомендации AI:
Ваше резюме "Python разработчик (Backend)" хорошо совпадает с требованиями. Рекомендуется добавить упоминание Kafka и подчеркнуть опыт с микросервисами.`);
      setTimeout(() => {
        setActiveStep(2);
        setEditedResume(`## Python разработчик (Backend) — адаптировано под Яндекс

**Опыт работы:**
Senior Python Developer, Яндекс (2021-2024)
Middle Python Developer, Тинькофф (2019-2021)
Junior Python Developer, Стартап X (2018-2019)

**Навыки (адаптировано под вакансию):**
Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Redis, Kafka, asyncio, REST API, Git, CI/CD, микросервисная архитектура

**Образование:**
МГУ им. Ломоносова, Факультет ВМК, Специалист (2014-2019)

**Языки:**
Русский (родной), Английский (C1)`);
        setTimeout(() => {
          setActiveStep(3);
          setCoverLetter(`Здравствуйте!

Меня заинтересовала вакансия "Senior Python Developer" в компании Яндекс.

У меня 5+ лет опыта разработки backend-систем на Python (Django, FastAPI). В Яндексе я работал с 2021 по 2024 год, где занимался проектированием микросервисной архитектуры и высоконагруженных систем. Имею глубокий опыт работы с PostgreSQL, Docker, Kubernetes, Redis и Kafka — все эти технологии указаны в ваших требованиях.

Я свободно владею английским языком (уровень C1), что позволяет мне читать документацию и общаться с международными командами без барьеров.

Буду рад обсудить детали вакансии и рассказать больше о своем опыте на собеседовании.

С уважением,
Иван Петров`);
          setTimeout(() => setActiveStep(4), 2000);
        }, 2000);
      }, 2000);
    }, 500);
  };

  return (
    <div className="space-y-4 max-w-4xl">
      {/* Header */}
      <div className="bg-gradient-to-r from-hf-blue/10 to-hf-cyan/10 border border-hf-blue/20 rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-hf-blue to-hf-cyan flex items-center justify-center">
            <Sparkles size={22} className="text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-hf-text-primary">AI Отклики</h2>
            <p className="text-xs text-hf-text-secondary">4 шага: Анализ → Резюме → Письмо → Отклик</p>
          </div>
        </div>
        <p className="text-sm text-hf-text-secondary leading-relaxed">
          ИИ читает вакансию, адаптирует ваше резюме под требования, пишет сопроводительное письмо и только потом отправляет отклик.
        </p>
      </div>

      {/* New Pipeline Form */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <h3 className="text-sm font-semibold text-hf-text-primary mb-3">🚀 Новый AI-отклик</h3>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            placeholder="Вставьте ссылку на вакансию (например: https://hh.ru/vacancy/123456)"
            value={vacancyUrl}
            onChange={(e) => setVacancyUrl(e.target.value)}
            className="flex-1 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-blue transition-colors"
          />
          <button
            onClick={handleAnalyze}
            disabled={!vacancyUrl.trim() || activeStep === 0}
            className={cn(
              "flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-medium transition-all",
              !vacancyUrl.trim() || activeStep === 0
                ? "bg-hf-border-subtle text-hf-text-muted cursor-not-allowed"
                : "bg-gradient-to-r from-hf-blue to-hf-cyan text-white hover:brightness-110"
            )}
          >
            {activeStep === 0 ? <Loader size={14} className="animate-spin" /> : <Sparkles size={14} />}
            {activeStep === 0 ? "Анализ..." : activeStep === 4 ? "Готово!" : "Старт AI"}
          </button>
        </div>
        <p className="text-xs text-hf-text-muted mt-2">Поддерживаются ссылки с HH.ru, Зарплата.ру, Работа.ру, SuperJob, Avito и других площадок</p>
      </div>

      {/* Pipeline Steps */}
      {activeStep > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-hf-text-primary">Прогресс обработки</h3>
          <div className="space-y-3">
            {demoSteps.map((step, i) => (
              <StepCard key={step.id} step={{ ...step, status: i + 1 < activeStep ? "completed" : i + 1 === activeStep ? "running" : "pending" }} isActive={i + 1 === activeStep} />
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {activeStep >= 2 && analysisResult && (
        <div className="bg-hf-elevated border border-hf-blue/30 rounded-[10px] p-5 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-hf-blue flex items-center gap-2"><Eye size={16} />Результат анализа вакансии</h3>
            <span className="text-xs text-hf-green font-medium">85% совпадение</span>
          </div>
          <div className="bg-hf-base rounded-lg p-4 text-xs text-hf-text-secondary leading-relaxed whitespace-pre-line border border-hf-border-subtle">
            {analysisResult}
          </div>
        </div>
      )}

      {activeStep >= 3 && editedResume && (
        <div className="bg-hf-elevated border border-hf-amber/30 rounded-[10px] p-5 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-hf-amber flex items-center gap-2"><Pencil size={16} />Адаптированное резюме</h3>
            <div className="flex gap-2">
              <button className="flex items-center gap-1 text-xs text-hf-text-secondary hover:text-hf-text-primary transition-colors"><Download size={12} />Скачать</button>
            </div>
          </div>
          <div className="bg-hf-base rounded-lg p-4 text-xs text-hf-text-secondary leading-relaxed whitespace-pre-line border border-hf-border-subtle">
            {editedResume}
          </div>
          <div className="mt-3 flex gap-2">
            <button className="px-3 py-1.5 rounded-md text-xs font-medium bg-hf-green/20 text-hf-green border border-hf-green/30 hover:bg-hf-green/30 transition-colors"><Check size={12} className="inline mr-1" />Одобрить</button>
            <button className="px-3 py-1.5 rounded-md text-xs font-medium bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary transition-colors"><Pencil size={12} className="inline mr-1" />Редактировать</button>
          </div>
        </div>
      )}

      {activeStep >= 4 && coverLetter && (
        <div className="bg-hf-elevated border border-hf-cyan/30 rounded-[10px] p-5 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-hf-cyan flex items-center gap-2"><FileText size={16} />Сопроводительное письмо</h3>
            <button className="flex items-center gap-1 text-xs text-hf-text-secondary hover:text-hf-text-primary transition-colors"><Pencil size={12} />Изменить</button>
          </div>
          <div className="bg-hf-base rounded-lg p-4 text-xs text-hf-text-secondary leading-relaxed whitespace-pre-line border border-hf-border-subtle">
            {coverLetter}
          </div>
          <div className="mt-3 flex gap-2">
            <button className="px-4 py-2 rounded-lg text-sm font-medium bg-gradient-to-r from-hf-blue to-hf-cyan text-white hover:brightness-110 transition-all flex items-center gap-2"><Send size={14} />Отправить отклик</button>
            <button className="px-3 py-2 rounded-lg text-xs font-medium bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary transition-colors">Отмена</button>
          </div>
        </div>
      )}
    </div>
  );
}

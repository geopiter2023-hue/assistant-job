import { Routes, Route } from "react-router";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Vacancies from "./pages/Vacancies";
import Applies from "./pages/Applies";
import Tasks from "./pages/Tasks";
import Settings from "./pages/Settings";
import Subscription from "./pages/Subscription";
import Resumes from "./pages/Resumes";
import AiPipeline from "./pages/AiPipeline";
import Login from "./pages/Login"
import NotFound from "./pages/NotFound"

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/vacancies" element={<Vacancies />} />
        <Route path="/ai-pipeline" element={<AiPipeline />} />
        <Route path="/applies" element={<Applies />} />
        <Route path="/tasks" element={<Tasks />} />
        <Route path="/resumes" element={<Resumes />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  );
}

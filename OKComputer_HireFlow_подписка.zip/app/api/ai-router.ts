import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { vacancyAnalyses, applyDrafts, resumes } from "@db/schema";
import { eq } from "drizzle-orm";

/**
 * AI Pipeline Router
 * 
 * Step 1: analyzeVacancy — AI reads vacancy description, extracts requirements
 * Step 2: editResume — AI adapts user's resume to match vacancy requirements  
 * Step 3: generateCoverLetter — AI writes personalized cover letter
 * Step 4: createDraft — combines edited resume + cover letter into a draft
 * Step 5: approveAndSend — user approves, bot sends the apply
 */

export const aiRouter = createRouter({
  // ─── Step 1: Analyze Vacancy ───
  analyzeVacancy: publicQuery
    .input(
      z.object({
        userId: z.number(),
        vacancyUrl: z.string(),
        vacancyTitle: z.string(),
        company: z.string().optional(),
        platform: z.enum(["hh", "zarplata", "rabota", "superjob", "yandex_smena", "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot"]),
        rawDescription: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Mock AI analysis (replace with real LLM call when API key is configured)
      const aiSummary = `Вакансия "${input.vacancyTitle}" требует опыта работы с Python, знания фреймворков (Django/FastAPI), опыта с базами данных (PostgreSQL), Docker. Желательно знание asyncio, Kubernetes.`;
      const requirements = "Python 3.8+, Django или FastAPI, PostgreSQL, Docker, Git, опыт от 2 лет";
      const responsibilities = "Разработка backend-сервисов, проектирование API, code review, написание тестов";
      const conditions = "Удаленная работа, гибкий график, ДМС, обучение за счет компании";
      const keySkills = "Python, Django, FastAPI, PostgreSQL, Docker, REST API, Git";
      const matchScore = 85;

      const result = await db.insert(vacancyAnalyses).values({
        userId: input.userId,
        vacancyUrl: input.vacancyUrl,
        vacancyTitle: input.vacancyTitle,
        company: input.company ?? null,
        platform: input.platform,
        rawDescription: input.rawDescription,
        requirements,
        responsibilities,
        conditions,
        keySkills,
        matchScore,
        aiSummary,
      }).returning({ id: vacancyAnalyses.id });

      return {
        id: result[0].id,
        requirements,
        responsibilities,
        conditions,
        keySkills,
        matchScore,
        aiSummary,
      };
    }),

  // ─── Step 2: Edit Resume for Vacancy ───
  editResume: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Get resume
      const resumeRows = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.resumeId))
        .limit(1);
      const resume = resumeRows[0];
      if (!resume) throw new Error("Resume not found");

      // Get analysis
      const analysisRows = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.analysisId))
        .limit(1);
      const analysis = analysisRows[0];
      if (!analysis) throw new Error("Analysis not found");

      // Mock AI resume editing
      const editedResumeText = `## ${resume.title}

**Опыт работы:** ${resume.experience}

**Навыки (адаптировано под вакансию "${analysis.vacancyTitle}"):**
${resume.skills}

**Дополнительно под вакансию:**
- Глубокое знание ${analysis.keySkills}
- Опыт работы с требованиями: ${analysis.requirements}

**Образование:** ${resume.education}

**Ожидаемая зарплата:** ${resume.desiredSalary}`;

      return {
        editedResumeText,
        originalSnapshot: {
          title: resume.title,
          skills: resume.skills,
          experience: resume.experience,
          summary: resume.summary,
        },
      };
    }),

  // ─── Step 3: Generate Cover Letter ───
  generateCoverLetter: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
        candidateName: z.string(),
        template: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const analysisRows = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.analysisId))
        .limit(1);
      const analysis = analysisRows[0];
      if (!analysis) throw new Error("Analysis not found");

      const resumeRows = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.resumeId))
        .limit(1);
      const resume = resumeRows[0];

      // Use template if provided, otherwise generate
      let coverLetter: string;
      if (input.template) {
        coverLetter = input.template
          .replace(/\{company\}/g, analysis.company ?? "Ваша компания")
          .replace(/\{position\}/g, analysis.vacancyTitle ?? "данную позицию")
          .replace(/\{candidate_name\}/g, input.candidateName)
          .replace(/\{skills\}/g, resume?.skills ?? "");
      } else {
        coverLetter = `Здравствуйте!

Меня заинтересовала вакансия "${analysis.vacancyTitle}" в компании ${analysis.company ?? "вашей компании"}.

У меня есть релевантный опыт работы с ${analysis.keySkills}. В моем резюме вы найдете подтверждение компетенций, соответствующих требованиям вакансии: ${analysis.requirements}.

Особенно привлекают условия: ${analysis.conditions}. Буду рад обсудить детали.

С уважением,
${input.candidateName}`;
      }

      return { coverLetter };
    }),

  // ─── Step 4: Create Draft (combine resume + cover letter) ───
  createDraft: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
        editedResumeText: z.string(),
        coverLetter: z.string(),
        aiReasoning: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const result = await db.insert(applyDrafts).values({
        userId: input.userId,
        vacancyAnalysisId: input.analysisId,
        resumeId: input.resumeId,
        editedResumeText: input.editedResumeText,
        coverLetter: input.coverLetter,
        aiReasoning: input.aiReasoning ?? null,
        status: "draft",
      }).returning({ id: applyDrafts.id });

      return { id: result[0].id };
    }),

  // ─── List Drafts ───
  listDrafts: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(applyDrafts)
        .where(eq(applyDrafts.userId, input.userId))
        .orderBy(applyDrafts.createdAt);
    }),

  // ─── Get Draft ───
  getDraft: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(applyDrafts)
        .where(eq(applyDrafts.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  // ─── Approve Draft ───
  approveDraft: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(applyDrafts)
        .set({ status: "approved" })
        .where(eq(applyDrafts.id, input.id));
      return { ok: true };
    }),

  // ─── Mark as Sent ───
  markSent: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(applyDrafts)
        .set({ status: "sent" })
        .where(eq(applyDrafts.id, input.id));
      return { ok: true };
    }),

  // ─── Import Resumes from HH.ru ───
  importFromHh: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async () => {
      // In production: use Puppeteer to login and parse hh.ru/resume
      // For demo: return mock data
      return [
        {
          id: "hh_1",
          title: "Senior Python Developer",
          url: "https://hh.ru/resume/abc123",
          lastUpdated: "2 дня назад",
          skills: "Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Redis, Kafka",
          salary: "500 000 — 700 000 ₽",
        },
        {
          id: "hh_2",
          title: "Backend Developer (Python/Django)",
          url: "https://hh.ru/resume/def456",
          lastUpdated: "1 неделю назад",
          skills: "Python, Django, Celery, PostgreSQL, Docker, REST API",
          salary: "300 000 — 450 000 ₽",
        },
        {
          id: "hh_3",
          title: "Python Tech Lead",
          url: "https://hh.ru/resume/ghi789",
          lastUpdated: "3 дня назад",
          skills: "Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Team Leadership, gRPC",
          salary: "600 000 — 900 000 ₽",
        },
      ];
    }),

  // ─── Parse Single HH Resume ───
  parseHhResume: publicQuery
    .input(z.object({ userId: z.number(), resumeId: z.string(), resumeUrl: z.string() }))
    .mutation(async () => {
      // In production: open resumeUrl with Puppeteer + stealth, parse DOM
      // For demo: return parsed data
      return {
        title: "Senior Python Developer",
        summary: "Разработчик с 6-летним опытом в Python-экосистеме. Специализируюсь на проектировании микросервисных архитектур и высоконагруженных систем.",
        skills: "Python, Django, FastAPI, PostgreSQL, MongoDB, Docker, Kubernetes, Redis, Kafka, Celery, asyncio, gRPC, REST API, GraphQL, Git, CI/CD, Jenkins, Nginx, Prometheus, Grafana",
        experience: `Senior Python Developer, Т-Банк (2022 — настоящее время)\n• Проектирование архитектуры backend-сервисов (100k+ RPS)\n• Управление командой из 5 разработчиков\n• Внедрение микросервисной архитектуры\n\nMiddle Python Developer, Яндекс (2020 — 2022)\n• Разработка сервисов на Python/FastAPI\n• Интеграция с PostgreSQL, Redis, Kafka\n• Написание юнит и интеграционных тестов`,
        education: "МГТУ им. Баумана, Факультет ИУ, Магистр (2017-2019)",
        languages: "Русский (родной), Английский (B2)",
        desiredSalary: "500 000 — 700 000 ₽",
        desiredPosition: "Senior Python Developer / Team Lead Backend",
      };
    }),

  // ─── Get Analysis ───
  getAnalysis: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),
});

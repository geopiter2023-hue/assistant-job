import { authRouter } from "./auth-router";
import { sessionRouter } from "./session-router";
import { applyRouter } from "./apply-router";
import { subscriptionRouter } from "./subscription-router";
import { profileRouter } from "./profile-router";
import { resumeRouter } from "./resume-router";
import { aiRouter } from "./ai-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  session: sessionRouter,
  apply: applyRouter,
  subscription: subscriptionRouter,
  profile: profileRouter,
  resume: resumeRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;

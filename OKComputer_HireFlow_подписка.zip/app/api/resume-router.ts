import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { resumes } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const resumeRouter = createRouter({
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(resumes)
        .where(eq(resumes.userId, input.userId))
        .orderBy(desc(resumes.createdAt));
    }),

  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        userId: z.number(),
        title: z.string().min(1),
        summary: z.string().optional(),
        skills: z.string().min(1),
        experience: z.string().optional(),
        education: z.string().optional(),
        languages: z.string().optional(),
        desiredSalary: z.string().optional(),
        desiredPosition: z.string().optional(),
        isDefault: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const { userId, ...data } = input;
      const db = getDb();

      // If setting as default, unset other defaults
      if (data.isDefault) {
        await db
          .update(resumes)
          .set({ isDefault: false })
          .where(eq(resumes.userId, userId));
      }

      const result = await db.insert(resumes).values({
        userId,
        ...data,
      }).returning({ id: resumes.id });
      return { id: result[0].id };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1),
        summary: z.string().optional(),
        skills: z.string().min(1),
        experience: z.string().optional(),
        education: z.string().optional(),
        languages: z.string().optional(),
        desiredSalary: z.string().optional(),
        desiredPosition: z.string().optional(),
        isDefault: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();

      // Get resume to find userId
      const existing = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, id))
        .limit(1);

      if (data.isDefault && existing[0]) {
        await db
          .update(resumes)
          .set({ isDefault: false })
          .where(eq(resumes.userId, existing[0].userId));
      }

      await db
        .update(resumes)
        .set(data)
        .where(eq(resumes.id, id));
      return { ok: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(resumes).where(eq(resumes.id, input.id));
      return { ok: true };
    }),

  setDefault: publicQuery
    .input(z.object({ id: z.number(), userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(resumes)
        .set({ isDefault: false })
        .where(eq(resumes.userId, input.userId));
      await db
        .update(resumes)
        .set({ isDefault: true })
        .where(eq(resumes.id, input.id));
      return { ok: true };
    }),
});

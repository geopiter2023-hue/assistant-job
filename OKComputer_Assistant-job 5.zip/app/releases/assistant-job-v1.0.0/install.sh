#!/bin/bash
echo "========================================"
echo "  Assistant Job — Установка"
echo "========================================"
echo ""

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "ОШИБКА: Node.js не установлен"
    echo "Установите Node.js 20+: curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "ОШИБКА: Требуется Node.js 20+. У вас: $(node -v)"
    exit 1
fi

echo "[1/4] Установка зависимостей..."
npm install --production 2>&1

echo ""
echo "[2/4] Настройка окружения..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✓ Создан .env — НАСТРОЙТЕ ЕГО перед запуском!"
else
    echo "✓ .env уже существует"
fi

echo ""
echo "[3/4] Проверка API..."
curl -s http://localhost:3000/api/version 2>/dev/null && echo "✓ API работает" || echo "⚠ API ещё не запущен"

echo ""
echo "[4/4] Запуск..."
npm start

echo ""
echo "========================================"
echo "  Готово! Сайт: http://localhost:3000"
echo "========================================"

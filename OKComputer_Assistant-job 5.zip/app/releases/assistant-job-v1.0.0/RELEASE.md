# Релиз Assistant Job

## Текущая версия: v1.0.0

## Что нужно загрузить на сервер

После сборки (`npm run build`) загрузите на сервер следующие файлы/папки:

### Обязательное (минимум для работы)
| Файл/Папка | Назначение |
|-----------|-----------|
| `dist/boot.js` | Сервер Node.js (Hono API + статика) |
| `dist/public/` | Frontend (index.html, CSS, JS) |
| `package.json` | Зависимости для `npm install --production` |
| `node_modules/` | Установленные зависимости (или установить на сервере) |
| `db/schema.ts` | Схема базы данных (для `npm run db:push`) |
| `drizzle.config.ts` | Конфиг Drizzle ORM |
| `.env` | Переменные окружения (настроить на сервере!) |

### Дополнительно (для разработки/дебага)
| Файл/Папка | Назначение |
|-----------|-----------|
| `api/` | Исходный код backend |
| `src/` | Исходный код frontend |
| `contracts/` | Shared types |
| `db/` | Полная папка с миграциями |
| `VERSIONS.md` | История версий |
| `RELEASE.md` | Этот файл |

## Пошаговый деплой

```bash
# 1. На локальной машине — собрать
npm run build

# 2. Архивировать
zip -r assistant-job-v1.0.0.zip dist/ package.json db/ drizzle.config.ts .env

# 3. Загрузить на сервер
scp assistant-job-v1.0.0.zip root@ВАШ_IP:/opt/

# 4. На сервере — распаковать
ssh root@ВАШ_IP
cd /opt
unzip -o assistant-job-v1.0.0.zip

# 5. Установить зависимости
npm install --production

# 6. Настроить .env
nano .env

# 7. Создать таблицы в БД
npm run db:push

# 8. Запустить
pm2 start dist/boot.js --name "assistant-job"
pm2 save
```

## Проверка после деплоя

```bash
# API работает?
curl http://ВАШ_IP/api/trpc/ping

# Версия?
curl http://ВАШ_IP/api/version

# Сайт открывается?
curl http://ВАШ_IP/
```

## Откат на предыдущую версию

```bash
# Если что-то сломалось — откат
pm2 stop assistant-job
cd /opt/backup  # предыдущая версия
pm2 start dist/boot.js --name "assistant-job"
```

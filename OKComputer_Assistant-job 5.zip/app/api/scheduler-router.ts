import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { jobSchedules, botSessions, applies, vacancyAnalyses, applyDrafts } from "@db/schema";
import { eq, desc } from "drizzle-orm";

/**
 * Scheduler Router
 * Manages cron-based job schedules for auto-monitoring vacancies
 * and auto-applying via browser automation.
 */

export const schedulerRouter = createRouter({
  // ─── List all schedules for user ───
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(jobSchedules)
        .where(eq(jobSchedules.userId, input.userId))
        .orderBy(desc(jobSchedules.createdAt));
    }),

  // ─── Get single schedule ───
  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(jobSchedules)
        .where(eq(jobSchedules.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  // ─── Create schedule ───
  create: publicQuery
    .input(
      z.object({
        userId: z.number(),
        name: z.string().min(1),
        cronExpression: z.string().default("*/30 * * * *"), // every 30 min
        intervalMinutes: z.number().min(5).max(1440).default(30),
        platforms: z.array(z.string()).default(["hh"]),
        keywords: z.string().min(1),
        resumeId: z.number().optional(),
        filters: z.object({
          salaryFrom: z.number().optional(),
          salaryTo: z.number().optional(),
          experience: z.string().optional(),
          remoteOnly: z.boolean().optional(),
          region: z.string().optional(),
        }).optional(),
        useAiPipeline: z.boolean().default(true),
        autoApply: z.boolean().default(false),
        maxAppliesPerRun: z.number().min(1).max(50).default(10),
        isActive: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Calculate nextRunAt based on interval
      const nextRun = new Date(Date.now() + input.intervalMinutes * 60000);

      const result = await db.insert(jobSchedules).values({
        userId: input.userId,
        name: input.name,
        cronExpression: input.cronExpression,
        intervalMinutes: input.intervalMinutes,
        platforms: input.platforms as any,
        keywords: input.keywords,
        resumeId: input.resumeId ?? null,
        filters: input.filters ?? {},
        useAiPipeline: input.useAiPipeline,
        autoApply: input.autoApply,
        maxAppliesPerRun: input.maxAppliesPerRun,
        isActive: input.isActive,
        nextRunAt: input.isActive ? nextRun : null,
      }).returning({ id: jobSchedules.id });

      return { id: result[0].id };
    }),

  // ─── Update schedule ───
  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        cronExpression: z.string().optional(),
        intervalMinutes: z.number().min(5).max(1440).optional(),
        platforms: z.array(z.string()).optional(),
        keywords: z.string().optional(),
        resumeId: z.number().optional(),
        filters: z.object({
          salaryFrom: z.number().optional(),
          salaryTo: z.number().optional(),
          experience: z.string().optional(),
          remoteOnly: z.boolean().optional(),
          region: z.string().optional(),
        }).optional(),
        useAiPipeline: z.boolean().optional(),
        autoApply: z.boolean().optional(),
        maxAppliesPerRun: z.number().min(1).max(50).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...updates } = input;

      await db
        .update(jobSchedules)
        .set({
          ...updates,
          updatedAt: new Date(),
        })
        .where(eq(jobSchedules.id, id));

      return { ok: true };
    }),

  // ─── Toggle active/inactive ───
  toggle: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const rows = await db
        .select()
        .from(jobSchedules)
        .where(eq(jobSchedules.id, input.id))
        .limit(1);
      const schedule = rows[0];
      if (!schedule) throw new Error("Schedule not found");

      const newActive = !schedule.isActive;
      const nextRun = newActive
        ? new Date(Date.now() + (schedule.intervalMinutes ?? 30) * 60000)
        : null;

      await db
        .update(jobSchedules)
        .set({
          isActive: newActive,
          nextRunAt: nextRun,
          updatedAt: new Date(),
        })
        .where(eq(jobSchedules.id, input.id));

      return { isActive: newActive, nextRunAt: nextRun };
    }),

  // ─── Delete schedule ───
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(jobSchedules).where(eq(jobSchedules.id, input.id));
      return { ok: true };
    }),

  // ─── Run schedule NOW (manual trigger) ───
  runNow: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const rows = await db
        .select()
        .from(jobSchedules)
        .where(eq(jobSchedules.id, input.id))
        .limit(1);
      const schedule = rows[0];
      if (!schedule) throw new Error("Schedule not found");

      // Create a bot session from this schedule
      const sessionResult = await db.insert(botSessions).values({
        userId: schedule.userId,
        name: `${schedule.name} (ручной запуск)`,
        status: "running",
        platform: "all",
        query: schedule.keywords,
        resultsFound: 0,
        appliesSent: 0,
        emulationMode: true,
        useAiPipeline: schedule.useAiPipeline ?? true,
      }).returning({ id: botSessions.id });

      const sessionId = sessionResult[0].id;

      // Simulate vacancy discovery + AI pipeline (mock for now)
      const foundVacancies = await simulateVacancySearch(db, schedule, sessionId);

      // Update session as completed
      await db
        .update(botSessions)
        .set({
          status: "completed",
          resultsFound: foundVacancies.found,
          appliesSent: foundVacancies.applied,
          completedAt: new Date(),
        })
        .where(eq(botSessions.id, sessionId));

      // Update schedule stats
      await db
        .update(jobSchedules)
        .set({
          lastRunAt: new Date(),
          totalRuns: (schedule.totalRuns ?? 0) + 1,
          totalApplies: (schedule.totalApplies ?? 0) + foundVacancies.applied,
          nextRunAt: new Date(Date.now() + (schedule.intervalMinutes ?? 30) * 60000),
          updatedAt: new Date(),
        })
        .where(eq(jobSchedules.id, input.id));

      return {
        ok: true,
        sessionId,
        found: foundVacancies.found,
        applied: foundVacancies.applied,
      };
    }),
});

// ─── Helper: simulate vacancy search + AI pipeline ───
async function simulateVacancySearch(
  db: any,
  schedule: any,
  sessionId: number
): Promise<{ found: number; applied: number }> {
  const keywords = schedule.keywords;
  const platforms: string[] = (schedule.platforms as string[]) ?? ["hh"];
  const maxApplies = schedule.maxAppliesPerRun ?? 10;
  const useAi = schedule.useAiPipeline ?? true;
  const autoApply = schedule.autoApply ?? false;

  // Mock: simulate finding vacancies across platforms
  const mockVacancies = generateMockVacancies(keywords, platforms);
  let applied = 0;

  for (const vacancy of mockVacancies) {
    if (applied >= maxApplies) break;

    // Step 1: AI analyze vacancy
    let analysisId: number | null = null;
    if (useAi) {
      const analysisResult = await db.insert(vacancyAnalyses).values({
        userId: schedule.userId,
        vacancyUrl: vacancy.url,
        vacancyTitle: vacancy.title,
        company: vacancy.company,
        platform: vacancy.platform,
        rawDescription: vacancy.description,
        requirements: vacancy.requirements,
        responsibilities: vacancy.responsibilities,
        conditions: vacancy.conditions,
        keySkills: vacancy.keySkills,
        salaryRange: vacancy.salary,
        matchScore: vacancy.matchScore,
        aiSummary: vacancy.aiSummary,
      }).returning({ id: vacancyAnalyses.id });
      analysisId = analysisResult[0].id;
    }

    // Step 2: Create draft (edited resume + cover letter)
    let draftId: number | null = null;
    if (useAi && analysisId) {
      const coverLetter = generateMockCoverLetter(vacancy.title, vacancy.company);
      const draftResult = await db.insert(applyDrafts).values({
        userId: schedule.userId,
        vacancyAnalysisId: analysisId,
        resumeId: schedule.resumeId,
        editedResumeText: `Адаптированное резюме под: ${vacancy.title}`,
        coverLetter,
        aiReasoning: `Навыки совпадают на ${vacancy.matchScore}%. Рекомендуется откликнуться.`,
        status: autoApply ? "approved" : "draft",
      }).returning({ id: applyDrafts.id });
      draftId = draftResult[0].id;

      // Auto-approve if autoApply is enabled
      if (autoApply && draftId) {
        await db
          .update(applyDrafts)
          .set({ status: "sent" })
          .where(eq(applyDrafts.id, draftId));
      }
    }

    // Step 3: Log the apply
    await db.insert(applies).values({
      userId: schedule.userId,
      sessionId,
      resumeId: schedule.resumeId,
      draftId,
      status: autoApply ? "success" : "pending",
      vacancy: vacancy.title,
      company: vacancy.company,
      platform: vacancy.platform,
      salary: vacancy.salary,
      location: vacancy.location,
      coverLetter: null,
      editedResume: null,
    });

    applied++;
  }

  return { found: mockVacancies.length, applied };
}

function generateMockVacancies(keywords: string, platforms: string[]) {
  return [
    {
      title: `Senior ${keywords}`,
      company: "Т-Банк",
      platform: platforms[0] ?? "hh",
      salary: "500 000 — 700 000 ₽",
      location: "Москва / удалённо",
      url: `https://${platforms[0] ?? "hh"}.ru/vacancy/1`,
      description: `Вакансия Senior ${keywords}. Требуется опыт от 3 лет.`,
      requirements: `Опыт с ${keywords} от 3 лет, PostgreSQL, Docker`,
      responsibilities: `Разработка, code review, архитектура`,
      conditions: `Удалёнка, ДМС, гибкий график`,
      keySkills: `${keywords}, PostgreSQL, Docker, Git`,
      matchScore: 92,
      aiSummary: `Отличное совпадение по ключевым навыкам.`,
    },
    {
      title: `${keywords} Developer`,
      company: "Яндекс",
      platform: platforms[1] ?? platforms[0] ?? "hh",
      salary: "400 000 — 600 000 ₽",
      location: "Москва",
      url: `https://${platforms[0] ?? "hh"}.ru/vacancy/2`,
      description: `Middle+ ${keywords} Developer в команду Яндекс.Маркет`,
      requirements: `Опыт с ${keywords} от 2 лет, микросервисы`,
      responsibilities: `Backend-разработка, интеграции`,
      conditions: `Офис/гибрид, страховка`,
      keySkills: `${keywords}, Microservices, Kafka`,
      matchScore: 87,
      aiSummary: `Хорошее совпадение, рекомендуется.`,
    },
    {
      title: `Lead ${keywords}`,
      company: "СБЕР",
      platform: platforms[0] ?? "hh",
      salary: "600 000 — 900 000 ₽",
      location: "Удалённо",
      url: `https://${platforms[0] ?? "hh"}.ru/vacancy/3`,
      description: `Tech Lead ${keywords} в платёжное направление`,
      requirements: `Опыт от 5 лет, управление командой`,
      responsibilities: `Лидерство, архитектура, менторство`,
      conditions: `Полная удалёнка, премии`,
      keySkills: `${keywords}, Leadership, System Design`,
      matchScore: 78,
      aiSummary: `Требуется опыт leadership — неполное совпадение.`,
    },
  ];
}

function generateMockCoverLetter(position: string, company: string): string {
  return `Здравствуйте!

Меня заинтересовала вакансия "${position}" в компании ${company}.

Мой опыт и навыки полностью соответствуют требованиям вакансии. Буду рад обсудить детали на собеседовании.

С уважением,
Кандидат`;
}

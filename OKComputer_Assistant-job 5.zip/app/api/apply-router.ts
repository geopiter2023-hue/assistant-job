import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { applies } from "@db/schema";
import { eq, desc, sql, and, gte } from "drizzle-orm";

export const applyRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        userId: z.number(),
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(applies)
        .where(eq(applies.userId, input.userId))
        .orderBy(desc(applies.createdAt))
        .limit(input.limit)
        .offset(input.offset);
    }),

  stats: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const totalResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(applies)
        .where(eq(applies.userId, input.userId));
      const successResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(applies)
        .where(and(eq(applies.userId, input.userId), eq(applies.status, "success")));
      const errorResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(applies)
        .where(and(eq(applies.userId, input.userId), eq(applies.status, "error")));

      const total = totalResult[0]?.count ?? 0;
      const success = successResult[0]?.count ?? 0;
      const error = errorResult[0]?.count ?? 0;

      return {
        total,
        success,
        error,
        conversionRate: total > 0 ? ((success / total) * 100).toFixed(1) : "0",
      };
    }),

  weeklyActivity: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
      const results = [];
      for (let i = 0; i < 7; i++) {
        const dayStart = new Date();
        dayStart.setDate(dayStart.getDate() - (6 - i));
        dayStart.setHours(0, 0, 0, 0);

        const countResult = await db
          .select({ count: sql<number>`count(*)` })
          .from(applies)
          .where(
            and(
              eq(applies.userId, input.userId),
              gte(applies.createdAt, dayStart)
            )
          );
        results.push({
          day: days[i],
          count: countResult[0]?.count ?? 0,
        });
      }
      return results;
    }),
});

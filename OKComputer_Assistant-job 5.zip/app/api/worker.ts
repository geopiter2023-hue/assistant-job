import { getDb } from "./queries/connection";
import { jobSchedules, botSessions, applies, vacancyAnalyses, applyDrafts } from "@db/schema";
import { eq, and, lte, isNotNull } from "drizzle-orm";

/**
 * Background Worker
 * Periodically checks for due schedules and executes them:
 * 1. Search vacancies across platforms
 * 2. AI analysis + resume adaptation
 * 3. Cover letter generation
 * 4. Browser automation apply (mock for now)
 */

let isRunning = false;
let intervalId: ReturnType<typeof setInterval> | null = null;

export function startWorker(checkIntervalMs = 60000) {
  if (intervalId) return; // already running

  console.log("[Worker] Starting background scheduler worker...");
  console.log(`[Worker] Check interval: ${checkIntervalMs}ms`);

  intervalId = setInterval(async () => {
    if (isRunning) return;
    isRunning = true;

    try {
      await processDueSchedules();
    } catch (err) {
      console.error("[Worker] Error processing schedules:", err);
    } finally {
      isRunning = false;
    }
  }, checkIntervalMs);
}

export function stopWorker() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
    console.log("[Worker] Stopped");
  }
}

export function getWorkerStatus() {
  return { isRunning, intervalId: intervalId !== null };
}

async function processDueSchedules() {
  const db = getDb();
  const now = new Date();

  // Find all active schedules where nextRunAt <= now
  const dueSchedules = await db
    .select()
    .from(jobSchedules)
    .where(
      and(
        eq(jobSchedules.isActive, true),
        isNotNull(jobSchedules.nextRunAt),
        lte(jobSchedules.nextRunAt, now)
      )
    );

  if (dueSchedules.length === 0) return;

  console.log(`[Worker] Found ${dueSchedules.length} due schedule(s)`);

  for (const schedule of dueSchedules) {
    try {
      console.log(`[Worker] Executing schedule #${schedule.id}: "${schedule.name}"`);
      await executeSchedule(db, schedule);
    } catch (err) {
      console.error(`[Worker] Schedule #${schedule.id} failed:`, err);
    }
  }
}

async function executeSchedule(db: any, schedule: any) {
  const keywords = schedule.keywords;
  const platforms: string[] = (schedule.platforms as string[]) ?? ["hh"];
  const maxApplies = schedule.maxAppliesPerRun ?? 10;
  const useAi = schedule.useAiPipeline ?? true;
  const autoApply = schedule.autoApply ?? false;

  // Create a bot session for this run
  const sessionResult = await db.insert(botSessions).values({
    userId: schedule.userId,
    name: `${schedule.name} — ${new Date().toLocaleString("ru-RU")}`,
    status: "running",
    platform: "all",
    query: keywords,
    resultsFound: 0,
    appliesSent: 0,
    emulationMode: true,
    useAiPipeline: useAi,
  }).returning({ id: botSessions.id });

  const sessionId = sessionResult[0].id;

  // Search vacancies (mock — in production uses Puppeteer)
  const vacancies = searchVacanciesOnPlatforms(keywords, platforms);
  let applied = 0;

  // Filter by criteria
  const filteredVacancies = applyFilters(vacancies, schedule.filters);

  for (const vacancy of filteredVacancies) {
    if (applied >= maxApplies) break;

    try {
      // Step 1: AI analyze vacancy
      let analysisId: number | null = null;
      if (useAi) {
        const analysisResult = await db.insert(vacancyAnalyses).values({
          userId: schedule.userId,
          vacancyUrl: vacancy.url,
          vacancyTitle: vacancy.title,
          company: vacancy.company,
          platform: vacancy.platform,
          rawDescription: vacancy.description,
          requirements: vacancy.requirements,
          responsibilities: vacancy.responsibilities,
          conditions: vacancy.conditions,
          keySkills: vacancy.keySkills,
          salaryRange: vacancy.salary,
          matchScore: vacancy.matchScore,
          aiSummary: vacancy.aiSummary,
        }).returning({ id: vacancyAnalyses.id });
        analysisId = analysisResult[0].id;
      }

      // Step 2: Generate cover letter + adapted resume
      let draftId: number | null = null;
      if (useAi && analysisId) {
        const coverLetter = generateCoverLetter(vacancy.title, vacancy.company, vacancy.keySkills);
        const draftResult = await db.insert(applyDrafts).values({
          userId: schedule.userId,
          vacancyAnalysisId: analysisId,
          resumeId: schedule.resumeId,
          editedResumeText: `Адаптированное резюме под вакансию "${vacancy.title}"\n\nКлючевые навыки: ${vacancy.keySkills}\nСовпадение: ${vacancy.matchScore}%`,
          coverLetter,
          aiReasoning: `Совпадение навыков: ${vacancy.matchScore}%. ${vacancy.aiSummary}`,
          status: autoApply ? "sent" : "draft",
        }).returning({ id: applyDrafts.id });
        draftId = draftResult[0].id;
      }

      // Step 3: Log the apply
      await db.insert(applies).values({
        userId: schedule.userId,
        sessionId,
        resumeId: schedule.resumeId,
        draftId,
        status: autoApply ? "success" : "pending",
        vacancy: vacancy.title,
        company: vacancy.company,
        platform: vacancy.platform,
        salary: vacancy.salary,
        location: vacancy.location,
        coverLetter: null,
        editedResume: null,
      });

      applied++;

      // Small delay between applies (stealth mode)
      await delay(2000 + Math.random() * 3000);
    } catch (err) {
      console.error(`[Worker] Failed to process vacancy "${vacancy.title}":`, err);
    }
  }

  // Mark session completed
  await db
    .update(botSessions)
    .set({
      status: "completed",
      resultsFound: filteredVacancies.length,
      appliesSent: applied,
      completedAt: new Date(),
    })
    .where(eq(botSessions.id, sessionId));

  // Update schedule stats and next run
  const intervalMs = (schedule.intervalMinutes ?? 30) * 60000;
  await db
    .update(jobSchedules)
    .set({
      lastRunAt: new Date(),
      totalRuns: (schedule.totalRuns ?? 0) + 1,
      totalApplies: (schedule.totalApplies ?? 0) + applied,
      nextRunAt: new Date(Date.now() + intervalMs),
      updatedAt: new Date(),
    })
    .where(eq(jobSchedules.id, schedule.id));

  console.log(`[Worker] Schedule #${schedule.id} done: ${filteredVacancies.length} found, ${applied} applied`);
}

// ─── Search vacancies (MOCK — replace with Puppeteer in production) ───
function searchVacanciesOnPlatforms(keywords: string, platforms: string[]) {
  const companies = ["Т-Банк", "Яндекс", "СБЕР", "VK", "Альфа-Банк", "Тинькофф", "Ozon", "Wildberries", "Ростелеком", "Газпром Нефть"];
  const locations = ["Москва", "Санкт-Петербург", "Удалённо", "Москва / удалённо", "Екатеринбург"];
  const result = [];

  const count = 3 + Math.floor(Math.random() * 5); // 3-7 vacancies

  for (let i = 0; i < count; i++) {
    const company = companies[Math.floor(Math.random() * companies.length)];
    const platform = platforms[Math.floor(Math.random() * platforms.length)];
    const location = locations[Math.floor(Math.random() * locations.length)];
    const matchScore = 60 + Math.floor(Math.random() * 35); // 60-95%
    const salaryMin = 300 + Math.floor(Math.random() * 40) * 10;
    const salaryMax = salaryMin + 100 + Math.floor(Math.random() * 30) * 10;

    result.push({
      title: `${keywords} ${["Developer", "Engineer", "", "Senior", "Middle+"][Math.floor(Math.random() * 5)]}`.trim(),
      company,
      platform,
      salary: `${salaryMin.toLocaleString("ru-RU")} — ${salaryMax.toLocaleString("ru-RU")} ₽`,
      location,
      url: `https://${platform}.ru/vacancy/${Date.now()}_${i}`,
      description: `Вакансия ${keywords}. Требуется опыт работы.`,
      requirements: `Опыт с ${keywords}, современные технологии`,
      responsibilities: `Разработка, поддержка, оптимизация`,
      conditions: `${["Удалённая работа", "Гибкий график", "ДМС", "Офис", "Гибрид"][Math.floor(Math.random() * 5)]}`,
      keySkills: `${keywords}, PostgreSQL, Docker, Git`,
      matchScore,
      aiSummary: `Совпадение навыков: ${matchScore}%. ${matchScore > 80 ? "Отличный вариант" : matchScore > 70 ? "Хорошее совпадение" : "Среднее совпадение"}.`,
    });
  }

  return result;
}

// ─── Apply filters from schedule settings ───
function applyFilters(vacancies: any[], filters: any) {
  if (!filters) return vacancies;

  return vacancies.filter((v) => {
    // Remote only filter
    if (filters.remoteOnly && !v.location.toLowerCase().includes("удал")) {
      return false;
    }

    // Region filter
    if (filters.region && !v.location.toLowerCase().includes(filters.region.toLowerCase())) {
      return false;
    }

    // Salary filter (extract numbers from salary string)
    if (filters.salaryFrom || filters.salaryTo) {
      const match = v.salary.match(/(\d[\d\s]*)/g);
      if (match) {
        const nums = match.map((n: string) => parseInt(n.replace(/\s/g, "")));
        const minSalary = Math.min(...nums);

        if (filters.salaryFrom && minSalary < filters.salaryFrom) return false;
        if (filters.salaryTo && minSalary > filters.salaryTo) return false;
      }
    }

    // Experience filter (would need more structured data in production)
    if (filters.experience) {
      // Placeholder: in production, parse experience from vacancy requirements
    }

    return true;
  });
}

function generateCoverLetter(position: string, company: string, skills: string): string {
  return `Здравствуйте!

Меня заинтересовала вакансия "${position}" в компании ${company}.

У меня есть релевантный опыт работы с ${skills}. Мои навыки полностью соответствуют требованиям вакансии.

Буду рад обсудить детали на собеседовании.

С уважением,
Кандидат`;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

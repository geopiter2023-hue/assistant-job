/**
 * Resume Parser — парсинг резюме из PDF и DOCX файлов
 * Загрузка файла → извлечение текста → структурирование данных
 */

import mammoth from "mammoth";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";

// pdfjs-dist для извлечения текста из PDF
async function extractPdfText(buffer: Buffer): Promise<string> {
  try {
    const data = new Uint8Array(buffer);
    const doc = await pdfjs.getDocument({ data }).promise;
    let fullText = "";
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      const content = await page.getTextContent();
      const strings = content.items.map((item: any) => item.str);
      fullText += strings.join(" ") + "\n";
    }
    return fullText;
  } catch (e) {
    console.error("[ResumeParser] pdfjs error:", (e as Error).message);
    return fallbackPdfExtract(buffer);
  }
}

export interface ParsedResume {
  title: string;
  summary: string;
  skills: string[];
  experience: Array<{
    position: string;
    company: string;
    period: string;
    description: string;
  }>;
  education: Array<{
    institution: string;
    degree: string;
    year: string;
  }>;
  languages: string[];
  contacts: {
    email?: string;
    phone?: string;
    location?: string;
  };
  rawText: string;
}

// ─── Определить тип файла и распарсить ───
export async function parseResumeFile(buffer: Buffer, mimeType: string): Promise<ParsedResume> {
  let text = "";

  if (mimeType === "application/pdf" || mimeType === "application/octet-stream") {
    text = await parsePdf(buffer);
  } else if (
    mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
    mimeType === "application/msword"
  ) {
    text = await parseDocx(buffer);
  } else {
    // Пробуем как текст
    text = buffer.toString("utf-8");
  }

  return structureResume(text);
}

// ─── Парсинг PDF через pdfjs-dist ───
async function parsePdf(buffer: Buffer): Promise<string> {
  return extractPdfText(buffer);
}

// Fallback PDF text extraction — читаем текстовые фрагменты из бинарного PDF
function fallbackPdfExtract(buffer: Buffer): string {
  const content = buffer.toString("latin1");
  const texts: string[] = [];

  // Извлекаем текст из PDF stream objects
  // PDF текст хранится между BT...ET (Begin/End Text) или как строки в скобках
  const streamRegex = /stream\s*([\s\S]*?)\s*endstream/g;
  let match;
  while ((match = streamRegex.exec(content)) !== null) {
    const stream = match[1];
    // Ищем текст в скобках: (текст)
    const textRegex = /\(([^)]{2,200})\)/g;
    let textMatch;
    while ((textMatch = textRegex.exec(stream)) !== null) {
      const t = textMatch[1];
      // Фильтруем бинарный мусор
      if (/[а-яА-Яa-zA-Z]{2,}/.test(t) && t.length > 2) {
        texts.push(decodePdfString(t));
      }
    }
  }

  // Если stream не дал результатов — пробуем найти текст напрямую
  if (texts.length === 0) {
    const directRegex = /\(([^)]{3,200})\)/g;
    let dm;
    while ((dm = directRegex.exec(content)) !== null) {
      const t = dm[1];
      if (/[а-яА-Яa-zA-Z]{2,}/.test(t) && t.length > 3 && !t.startsWith("<?")) {
        texts.push(decodePdfString(t));
      }
    }
  }

  // Убираем дубликаты и соединяем
  const result = [...new Set(texts)].join("\n");
  if (result.length > 20) return result;

  // Последний fallback — UTF-16 строки в PDF
  return extractUtf16FromPdf(buffer);
}

// Декодирование PDF escape-последовательностей
function decodePdfString(str: string): string {
  return str
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "")
    .replace(/\\t/g, " ")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\");
}

// Извлечение UTF-16 текста из PDF (HH.ru использует Unicode)
function extractUtf16FromPdf(buffer: Buffer): string {
  const parts: string[] = [];
  // Ищем BOM-метки UTF-16: FE FF
  let idx = 0;
  while ((idx = buffer.indexOf(Buffer.from([0xFE, 0xFF]), idx)) !== -1) {
    idx += 2;
    const end = buffer.indexOf(Buffer.from([0, 0]), idx); // null terminator
    const slice = buffer.slice(idx, end === -1 ? idx + 500 : end);
    try {
      const text = slice.toString("utf16le");
      if (/[\u0400-\u04FFa-zA-Z]/.test(text) && text.length > 2) {
        parts.push(text.replace(/\0/g, ""));
      }
    } catch { /* ignore */ }
    idx += 100;
  }

  if (parts.length > 0) return parts.join(" ");

  // Если ничего не сработало — пробуем прочитать как utf-8 напрямую
  try {
    const asUtf8 = buffer.toString("utf-8");
    const lines = asUtf8
      .split(/\n|\r/)
      .map(l => l.trim())
      .filter(l => l.length > 3 && l.length < 200 && /[а-яА-Яa-zA-Z]/.test(l));
    return lines.join("\n").substring(0, 10000);
  } catch {
    return "";
  }
}

// ─── Парсинг DOCX ───
async function parseDocx(buffer: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer });
  return result.value || "";
}

// ─── Структурирование резюме из текста ───
function structureResume(text: string): ParsedResume {
  const lines = text
    .split(/\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const fullText = lines.join("\n");

  return {
    title: extractTitle(fullText, lines),
    summary: extractSummary(fullText, lines),
    skills: extractSkills(fullText),
    experience: extractExperience(fullText, lines),
    education: extractEducation(fullText),
    languages: extractLanguages(fullText),
    contacts: extractContacts(fullText),
    rawText: fullText,
  };
}

// ─── Extractors ───

function extractTitle(text: string, lines: string[]): string {
  // HH.ru: ищем "Желаемая должность" или первая строка после ФИО
  const desiredMatch = text.match(/(?:желаемая\s+должность|desired\s+position)[\s\n—:-]*([^\n]{3,80})/i);
  if (desiredMatch) return desiredMatch[1].trim();

  // Ищем должность по шаблону (Директор, Руководитель, Менеджер, etc.)
  const positionMatch = text.match(/(?:директор|руководитель|менеджер|специалист|инженер|аналитик|разработчик|программист|дизайнер|менеджер|координатор|консультант|эксперт)[^\n,]{0,60}/i);
  if (positionMatch) return positionMatch[0].trim();

  // Первая непустая строка (обычно ФИО)
  if (lines.length > 0 && lines[0].length < 80 && !lines[0].includes("обновлено")) {
    return lines[0];
  }

  // Вторая строка если первая — дата
  if (lines.length > 1 && lines[0].includes("обновлено")) {
    return lines[1];
  }

  return "Резюме";
}

function extractSummary(text: string, lines: string[]): string {
  // Ищем блок "О себе" / "Summary" / первый абзац после заголовка
  const sections = ["о себе", "summary", "обо мне", "профиль", "личные качества"];
  for (const section of sections) {
    const regex = new RegExp(`${section}[\s:]*\n+([\s\S]{20,500}?)(?=\n+(?:опыт|experience|навыки|skills|образование|education|$))`, "i");
    const match = text.match(regex);
    if (match) return match[1].trim().replace(/\n+/g, " ");
  }
  // Fallback: первые 3-5 строк как summary
  return lines.slice(1, 5).join(" ").substring(0, 300);
}

function extractSkills(text: string): string[] {
  const skills: string[] = [];

  // Ищем секцию "Навыки" / "Skills"
  const sectionRegex = /(?:навыки|ключевые навыки|skills|стек)[\s:]*\n+([\s\S]{10,2000}?)(?=\n+(?:опыт|experience|образование|education|проекты|о себе|$))/i;
  const match = text.match(sectionRegex);

  if (match) {
    const skillsText = match[1];
    // Разбиваем по запятым, точкам с запятой, переносам
    const items = skillsText
      .split(/[,;•·\n]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 1 && s.length < 50);
    skills.push(...items);
  }

  // Если не нашли секцию — ищем популярные навыки в тексте
  if (skills.length === 0) {
    const commonSkills = [
      "Python", "JavaScript", "TypeScript", "Java", "Go", "Rust", "C++", "C#", "PHP", "Ruby",
      "React", "Vue", "Angular", "Node.js", "Django", "Flask", "FastAPI", "Spring",
      "Docker", "Kubernetes", "AWS", "GCP", "Azure", "Linux",
      "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch", "ClickHouse",
      "Git", "CI/CD", "Jenkins", "GitLab", "GitHub Actions",
      "REST API", "GraphQL", "gRPC", "WebSocket",
      "Nginx", "Apache", "Terraform", "Ansible",
      "Machine Learning", "Data Science", "TensorFlow", "PyTorch",
      "Agile", "Scrum", "Kanban", "Jira", "Confluence",
      "Team Lead", "Management", "Mentoring",
      "HTML", "CSS", "Sass", "Less", "Webpack", "Vite",
      "SQL", "NoSQL", "ORM", "Hibernate", "SQLAlchemy",
    ];

    for (const skill of commonSkills) {
      if (text.toLowerCase().includes(skill.toLowerCase()) && !skills.includes(skill)) {
        skills.push(skill);
      }
    }
  }

  return skills.slice(0, 30); // max 30 skills
}

function extractExperience(text: string, lines: string[]): ParsedResume["experience"] {
  const experiences: ParsedResume["experience"] = [];

  // HH.ru: "Опыт работы — 18 лет 1 месяц"
  const sectionRegex = /(?:опыт\s+работы|experience)[\s\n—:]*(?:\d+\s*(?:лет|год|месяц|year|month))?/i;
  const sectionMatch = text.match(sectionRegex);
  if (!sectionMatch) return experiences;

  const expStart = text.indexOf(sectionMatch[0]) + sectionMatch[0].length;
  const expSection = text.substring(expStart, expStart + 8000);
  const expLines = expSection.split("\n").map(l => l.trim()).filter(Boolean);

  // HH.ru формат (построчный):
  // Февраль 2024 — Декабрь 2025
  // 1 год 11 месяцев
  // Компания Москва www.site.ru
  // Отрасль
  // Должность
  // Описание...
  let current: Partial<ParsedResume["experience"][0]> = {};
  let collectingDesc = false;
  let descLines: string[] = [];

  for (const line of expLines) {
    // Стоп-слово: Образование, Навыки, Языки и т.д.
    if (/^(образование|education|высшее|среднее|навыки|skills|языки|languages|проекты|о себе|доп\.?\s*информация|знание\s*языков|профессиональные|курсы|сертификаты|портфолио)$/i.test(line)) {
      break;
    }

    // Период: "Февраль 2024 — Декабрь 2025" или "2024 — 2025"
    if (/\d{4}/.test(line) && (line.includes("—") || line.includes("по настоящее") || line.includes("н.в."))) {
      // Сохраняем предыдущую запись
      if (current.position) {
        if (descLines.length > 0) current.description = descLines.join("\n");
        experiences.push(current as ParsedResume["experience"][0]);
      }
      current = { period: line };
      collectingDesc = false;
      descLines = [];
      continue;
    }

    // Пропуск "1 год 11 месяцев" и подобное
    if (/^\d+\s+(год|лет|года|месяц|месяцев)\b/.test(line)) continue;
    if (/^по настоящее время\b/.test(line)) continue;

    // Компания: строка после периода, обычно с городом или сайтом
    if (current.period && !current.company && line.length > 2 && line.length < 80) {
      // Пропускаем строки с отраслью (обычно содержат •)
      if (!line.startsWith("•") && !line.startsWith("-") && !line.startsWith("—")) {
        current.company = line;
        continue;
      }
    }

    // Должность: после компании
    if (current.company && !current.position && line.length > 3 && line.length < 80) {
      current.position = line;
      collectingDesc = true;
      descLines = [];
      continue;
    }

    // Описание
    if (collectingDesc) {
      // Стоп по новому периоду или пустой строке
      if (/^(\d{4}|январь|февраль|март|апрель|май|июнь|июль|август|сентябрь|октябрь|ноябрь|декабрь)\b/.test(line) && line.includes("—")) {
        // Это новый период — сохраняем
        if (current.position) {
          if (descLines.length > 0) current.description = descLines.join("\n");
          experiences.push(current as ParsedResume["experience"][0]);
        }
        current = { period: line };
        collectingDesc = false;
        descLines = [];
        continue;
      }
      if (line.length > 5) {
        descLines.push(line);
      }
    }
  }

  // Последняя запись
  if (current.position) {
    if (descLines.length > 0) current.description = descLines.join("\n");
    experiences.push(current as ParsedResume["experience"][0]);
  }

  return experiences.slice(0, 15);
}

function extractEducation(text: string): ParsedResume["education"] {
  const educations: ParsedResume["education"] = [];

  const sectionRegex = /(?:образование|education)[\s:]*\n+/i;
  const sectionMatch = text.match(sectionRegex);

  if (!sectionMatch) return educations;

  const eduStart = text.indexOf(sectionMatch[0]) + sectionMatch[0].length;
  const eduSection = text.substring(eduStart, eduStart + 1500);

  // Ищем: Университет, специальность, год
  const lines2 = eduSection.split("\n").map((l) => l.trim()).filter(Boolean);

  for (let i = 0; i < lines2.length - 1; i++) {
    const line = lines2[i];
    const yearMatch = line.match(/(19|20)\d{2}[\s—-]+((?:19|20)\d{2}|н\.в\.)?/);

    if (yearMatch || line.length > 10) {
      educations.push({
        institution: line.substring(0, 80),
        degree: lines2[i + 1]?.substring(0, 60) || "",
        year: yearMatch ? yearMatch[0] : "",
      });
      i++;
    }
  }

  return educations.slice(0, 5);
}

function extractLanguages(text: string): string[] {
  const langs: string[] = [];
  const sectionRegex = /(?:языки|languages)[\s:]*\n+([\s\S]{5,500}?)(?=\n+(?:навыки|опыт|образование|проекты|$))/i;
  void sectionRegex;
  const match = text.match(sectionRegex);

  if (match) {
    const items = match[1]
      .split(/[,;•·\n]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 2 && s.length < 40);
    langs.push(...items);
  }

  // Fallback: ищем в тексте
  const commonLangs = ["Русский", "Английский", "English", "Немецкий", "Deutsch", "Французский", "Français", "Испанский", "Китайский", "Японский"];
  for (const lang of commonLangs) {
    if (text.toLowerCase().includes(lang.toLowerCase()) && !langs.some((l) => l.toLowerCase().includes(lang.toLowerCase()))) {
      langs.push(lang);
    }
  }

  return langs;
}

function extractContacts(text: string): ParsedResume["contacts"] {
  const email = text.match(/[\w.-]+@[\w.-]+\.\w{2,}/)?.[0];
  const phone = text.match(/[+]7\s?[\s(]?\d{3}[)\s]?\s?\d{3}[\s-]?\d{2}[\s-]?\d{2}/)?.[0] ||
                text.match(/8\s?[\s(]?\d{3}[)\s]?\s?\d{3}[\s-]?\d{2}[\s-]?\d{2}/)?.[0];

  return { email, phone };
}

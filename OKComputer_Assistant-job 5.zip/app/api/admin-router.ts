/**
 * Admin Router — админ-панель для управления системой
 * URL: /ushakov
 * Защищено авторизацией по логину/паролю
 */

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, applies, subscriptions, supportTickets, apiKeys, adminUsers, botSessions, profiles } from "@db/schema";
import { eq, desc, sql, and, gte } from "drizzle-orm";

// Простой хеш (bcrypt лучше, но пока SHA-256 для простоты)
function hashPassword(password: string): string {
  const crypto = require("crypto");
  return crypto.createHash("sha256").update(password + "aj_salt_2025").digest("hex");
}

function generateToken(): string {
  const crypto = require("crypto");
  return crypto.randomBytes(32).toString("hex");
}

// In-memory сессии (в production — Redis)
const adminSessions: Map<string, { adminId: number; expires: number }> = new Map();

function isSessionValid(token: string): boolean {
  const session = adminSessions.get(token);
  if (!session) return false;
  if (Date.now() > session.expires) {
    adminSessions.delete(token);
    return false;
  }
  return true;
}

function getAdminId(token: string): number | null {
  const session = adminSessions.get(token);
  return session?.adminId ?? null;
}

// ─── Seed: создать дефолтного админа если нет ───
async function seedDefaultAdmin() {
  try {
    const db = getDb();
    const existing = await db.select().from(adminUsers).limit(1);
    if (existing.length === 0) {
      await db.insert(adminUsers).values({
        username: "ushakov",
        passwordHash: hashPassword("admin2025"),
        name: "Администратор",
        role: "superadmin",
        isActive: true,
      });
      console.log("[Admin] Default admin created: username=ushakov, password=admin2025");
    }
  } catch (e) {
    // Table may not exist yet
  }
}
// Run seed on first request
let seeded = false;

export const adminRouter = createRouter({
  // ─── Seed endpoint (вызывать один раз после деплоя) ───
  seed: publicQuery
    .mutation(async () => {
      await seedDefaultAdmin();
      seeded = true;
      return { success: true, message: "Admin seeded. Login: ushakov / admin2025" };
    }),
  // ─── Авторизация ───
  login: publicQuery
    .input(z.object({
      username: z.string().min(1),
      password: z.string().min(1),
    }))
    .mutation(async ({ input }) => {
      // Auto-seed on first login attempt
      if (!seeded) {
        await seedDefaultAdmin();
        seeded = true;
      }

      const db = getDb();
      const hash = hashPassword(input.password);
      const result = await db
        .select()
        .from(adminUsers)
        .where(and(
          eq(adminUsers.username, input.username),
          eq(adminUsers.passwordHash, hash),
          eq(adminUsers.isActive, true)
        ))
        .limit(1);

      if (result.length === 0) {
        return { success: false, message: "Неверный логин или пароль" };
      }

      const admin = result[0];
      const token = generateToken();
      adminSessions.set(token, { adminId: admin.id, expires: Date.now() + 24 * 60 * 60 * 1000 }); // 24h

      // Update last login
      await db.update(adminUsers)
        .set({ lastLoginAt: new Date() })
        .where(eq(adminUsers.id, admin.id));

      return {
        success: true,
        token,
        admin: {
          id: admin.id,
          name: admin.name || admin.username,
          role: admin.role,
        },
      };
    }),

  verify: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) {
        return { valid: false };
      }
      const db = getDb();
      const adminId = getAdminId(input.token);
      if (!adminId) return { valid: false };

      const result = await db.select().from(adminUsers).where(eq(adminUsers.id, adminId)).limit(1);
      if (result.length === 0) return { valid: false };

      return {
        valid: true,
        admin: {
          id: result[0].id,
          name: result[0].name || result[0].username,
          role: result[0].role,
        },
      };
    }),

  logout: publicQuery
    .input(z.object({ token: z.string() }))
    .mutation(({ input }) => {
      adminSessions.delete(input.token);
      return { success: true };
    }),

  // ─── Статистика дашборда ───
  stats: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();

      const [usersCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
      const [appliesCount] = await db.select({ count: sql<number>`count(*)` }).from(applies);
      const [appliesSuccess] = await db.select({ count: sql<number>`count(*)` }).from(applies).where(eq(applies.status, "success"));
      const [ticketsOpen] = await db.select({ count: sql<number>`count(*)` }).from(supportTickets).where(eq(supportTickets.status, "open"));
      const [subsActive] = await db.select({ count: sql<number>`count(*)` }).from(subscriptions).where(eq(subscriptions.status, "active"));
      const [sessionsTotal] = await db.select({ count: sql<number>`count(*)` }).from(botSessions);

      // Weekly activity
      const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
      const weeklyActivity = [];
      for (let i = 0; i < 7; i++) {
        const dayStart = new Date();
        dayStart.setDate(dayStart.getDate() - (6 - i));
        dayStart.setHours(0, 0, 0, 0);
        const [count] = await db
          .select({ count: sql<number>`count(*)` })
          .from(applies)
          .where(gte(applies.createdAt, dayStart));
        weeklyActivity.push({ day: days[i], count: count?.count ?? 0 });
      }

      // Recent applies (last 10)
      const recentApplies = await db
        .select()
        .from(applies)
        .orderBy(desc(applies.createdAt))
        .limit(10);

      // Recent users
      const recentUsers = await db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          createdAt: users.createdAt,
        })
        .from(users)
        .orderBy(desc(users.createdAt))
        .limit(10);

      return {
        usersTotal: usersCount?.count ?? 0,
        appliesTotal: appliesCount?.count ?? 0,
        appliesSuccess: appliesSuccess?.count ?? 0,
        ticketsOpen: ticketsOpen?.count ?? 0,
        subscriptionsActive: subsActive?.count ?? 0,
        sessionsTotal: sessionsTotal?.count ?? 0,
        weeklyActivity,
        recentApplies,
        recentUsers,
      };
    }),

  // ─── Пользователи ───
  usersList: publicQuery
    .input(z.object({ token: z.string(), limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const list = await db
        .select()
        .from(users)
        .orderBy(desc(users.createdAt))
        .limit(input.limit)
        .offset(input.offset);
      const [count] = await db.select({ count: sql<number>`count(*)` }).from(users);
      return { users: list, total: count?.count ?? 0 };
    }),

  // ─── Тикеты поддержки ───
  ticketsList: publicQuery
    .input(z.object({ token: z.string(), status: z.string().optional() }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      let query = db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
      const list = await query;
      if (input.status) {
        return { tickets: list.filter(t => t.status === input.status) };
      }
      return { tickets: list };
    }),

  ticketUpdate: publicQuery
    .input(z.object({
      token: z.string(),
      ticketId: z.number(),
      status: z.string(),
      adminReply: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const updateData: any = { status: input.status, updatedAt: new Date() };
      if (input.adminReply) updateData.adminReply = input.adminReply;
      if (input.status === "resolved") updateData.resolvedAt = new Date();
      await db.update(supportTickets).set(updateData).where(eq(supportTickets.id, input.ticketId));
      return { success: true };
    }),

  // ─── API Ключи ───
  apiKeysList: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const list = await db.select().from(apiKeys).orderBy(desc(apiKeys.createdAt));
      return { keys: list };
    }),

  apiKeyCreate: publicQuery
    .input(z.object({
      token: z.string(),
      name: z.string().min(1),
      type: z.string(),
      userId: z.number().optional(),
      expiresDays: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const key = generateToken();
      const expiresAt = input.expiresDays
        ? new Date(Date.now() + input.expiresDays * 24 * 60 * 60 * 1000)
        : null;

      await db.insert(apiKeys).values({
        key,
        name: input.name,
        type: input.type,
        userId: input.userId,
        expiresAt,
        createdBy: getAdminId(input.token)!,
      });
      return { success: true, key };
    }),

  apiKeyToggle: publicQuery
    .input(z.object({ token: z.string(), keyId: z.number() }))
    .mutation(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const [existing] = await db.select().from(apiKeys).where(eq(apiKeys.id, input.keyId)).limit(1);
      if (!existing) return { error: "Key not found" };
      await db.update(apiKeys).set({ isActive: !existing.isActive }).where(eq(apiKeys.id, input.keyId));
      return { success: true };
    }),

  // ─── Настройки системы ───
  settings: publicQuery
    .input(z.object({ token: z.string() }))
    .query(async ({ input }) => {
      if (!isSessionValid(input.token)) return { error: "Unauthorized" };
      const db = getDb();
      const [usersCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
      const [appliesCount] = await db.select({ count: sql<number>`count(*)` }).from(applies);
      const [ticketsCount] = await db.select({ count: sql<number>`count(*)` }).from(supportTickets);
      const [keysCount] = await db.select({ count: sql<number>`count(*)` }).from(apiKeys);

      return {
        totalUsers: usersCount?.count ?? 0,
        totalApplies: appliesCount?.count ?? 0,
        totalTickets: ticketsCount?.count ?? 0,
        totalApiKeys: keysCount?.count ?? 0,
      };
    }),
});

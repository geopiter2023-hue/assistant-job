/**
 * Scraper Service — парсинг вакансий с российских job-площадок
 * Использует fetch + cheerio для извлечения данных
 */

import * as cheerio from "cheerio";
import { analyzeVacancy } from "./ai-service";

export interface ScrapedVacancy {
  id: string;
  title: string;
  company: string;
  salary: string;
  location: string;
  experience: string;
  employment: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  conditions: string[];
  keySkills: string[];
  url: string;
  platform: string;
  publishedAt: string;
}

// ─── HH.ru scraper ───
export async function searchHhRu(query: string, options: {
  area?: number; // 1 = Москва
  salary?: number;
  experience?: string;
  remote?: boolean;
  page?: number;
} = {}): Promise<ScrapedVacancy[]> {
  try {
    const params = new URLSearchParams({
      text: query,
      page: String(options.page || 0),
      per_page: "20",
      ...(options.area ? { area: String(options.area) } : {}),
      ...(options.salary ? { salary: String(options.salary) } : {}),
      ...(options.experience ? { experience: options.experience } : {}),
      ...(options.remote ? { schedule: "remote" } : {}),
    });

    const url = `https://api.hh.ru/vacancies?${params.toString()}`;

    // Проверяем наличие HTTP-прокси в .env
    const proxyUrl = process.env.HTTP_PROXY || process.env.HTTPS_PROXY;

    let fetchOptions: any = {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json",
        "Accept-Language": "ru-RU,ru;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
      },
    };

    if (proxyUrl) {
      try {
        const { HttpsProxyAgent } = await import("https-proxy-agent");
        fetchOptions.agent = new HttpsProxyAgent(proxyUrl);
      } catch {
        console.warn("[Scraper] https-proxy-agent not installed, using direct fetch");
      }
    }

    const response = await fetch(url, fetchOptions);

    if (response.status === 403) {
      console.error("[Scraper] HH.ru blocked the request (IP not from Russia). Need Russian proxy.");
      throw new Error("HH.ru блокирует запросы с этого сервера. Установите систему на сервере в России или настройте HTTP-прокси (HTTP_PROXY в .env)");
    }

    if (!response.ok) {
      console.error(`[Scraper] HH.ru API error: ${response.status}`);
      throw new Error(`HH.ru API вернул ошибку: HTTP ${response.status}`);
    }

    const data = await response.json() as any;
    const vacancies: ScrapedVacancy[] = [];

    for (const item of (data.items as any[])?.slice(0, 10) || []) {
      try {
        // Fetch full vacancy details
        const detailRes = await fetch(item.url as string, {
          headers: {
            "User-Agent": "AssistantJob/1.0 (contact@assistantjob.ru)",
            "Accept": "application/json",
          },
        });

        if (!detailRes.ok) continue;

        const detail = await detailRes.json() as any;

        // Extract skills
        const skills = (detail.key_skills as any[])?.map((s: any) => s.name as string) || [];

        // Parse description HTML
        const $ = cheerio.load((detail.description as string) || "");
        const text = $.text();

        // Extract sections
        const html = (detail.description as string) || "";
        const responsibilities = extractList(html, ["Обязанности", "Чем предстоит", "Что делать"]);
        const requirements = extractList(html, ["Требования", "Мы ищем", "Ожидаем"]);
        const conditions = extractList(html, ["Условия", "Мы предлагаем", "Будет плюсом"]);

        vacancies.push({
          id: `hh_${item.id as string}`,
          title: (detail.name as string) || (item.name as string),
          company: (detail.employer?.name as string) || "Неизвестно",
          salary: formatSalary(detail.salary),
          location: (detail.area?.name as string) || "",
          experience: (detail.experience?.name as string) || "",
          employment: (detail.employment?.name as string) || "",
          description: text.substring(0, 1000),
          requirements,
          responsibilities,
          conditions,
          keySkills: skills,
          url: (detail.alternate_url as string) || (item.alternate_url as string),
          platform: "hh",
          publishedAt: (detail.published_at as string) || new Date().toISOString(),
        });
      } catch (err) {
        console.error(`[Scraper] Error fetching vacancy ${item.id}:`, err);
      }
    }

    return vacancies; // Только реальные вакансии, без мока
  } catch (err) {
    console.error("[Scraper] HH.ru search error:", err);
    return []; // Нет мок-данных — только реальные вакансии с HH
  }
}

// ─── Generic search across multiple platforms ───
export async function searchVacancies(
  query: string,
  platforms: string[] = ["hh"],
  options: any = {}
): Promise<ScrapedVacancy[]> {
  const allVacancies: ScrapedVacancy[] = [];

  for (const platform of platforms) {
    try {
      let results: ScrapedVacancy[] = [];

      switch (platform) {
        case "hh":
          results = await searchHhRu(query, options);
          break;
        // Добавить другие площадки по аналогии
        default:
          console.log(`[Scraper] Platform ${platform} not implemented yet`);
          results = [];
      }

      allVacancies.push(...results);
    } catch (err) {
      console.error(`[Scraper] Platform ${platform} error:`, err);
      // Не добавляем мок-данные — только реальные вакансии
    }
  }

  return allVacancies;
}

// ─── AI Analysis wrapper ───
export async function analyzeVacancyWithAI(vacancy: ScrapedVacancy) {
  const fullText = `
Вакансия: ${vacancy.title}
Компания: ${vacancy.company}
Опыт: ${vacancy.experience}
Занятость: ${vacancy.employment}

Описание:
${vacancy.description}

Обязанности:
${vacancy.responsibilities.join("\n")}

Требования:
${vacancy.requirements.join("\n")}

Условия:
${vacancy.conditions.join("\n")}

Навыки: ${vacancy.keySkills.join(", ")}
`;

  return analyzeVacancy(fullText);
}

// ─── Helpers ───
function formatSalary(salary: any): string {
  if (!salary) return "Зарплата не указана";
  const from = salary.from ? `${salary.from.toLocaleString("ru-RU")} ₽` : "";
  const to = salary.to ? `${salary.to.toLocaleString("ru-RU")} ₽` : "";
  // currency: salary.currency === "RUR" ? "₽" : salary.currency || ""

  if (from && to) return `${from} — ${to}`;
  if (from) return `от ${from}`;
  if (to) return `до ${to}`;
  return "Зарплата по договорённости";
}

function extractList(html: string, keywords: string[]): string[] {
  const $ = cheerio.load(html);
  const results: string[] = [];

  // Try to find list items after keywords
  for (const keyword of keywords) {
    $("*").each((_, el) => {
      const text = $(el).text().trim();
      if (text.toLowerCase().includes(keyword.toLowerCase())) {
        const $parent = $(el).parent();
        $parent.find("li, p, div").each((_, child) => {
          const itemText = $(child).text().trim();
          if (itemText.length > 10 && itemText.length < 300 && !results.includes(itemText)) {
            results.push(itemText);
          }
        });
      }
    });
  }

  // Fallback: extract all list items
  if (results.length === 0) {
    $("li, ul li").each((_, el) => {
      const text = $(el).text().trim();
      if (text.length > 10 && text.length < 300) {
        results.push(text);
      }
    });
  }

  return results.length > 0 ? results.slice(0, 10) : ["Информация в описании вакансии"];
}

// Нет мок-данных — только реальные вакансии с job-площадок

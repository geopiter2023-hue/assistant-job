import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { resumes } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { importResumesFromHh } from "./hh-parser";

export const resumeRouter = createRouter({
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(resumes)
        .where(eq(resumes.userId, input.userId))
        .orderBy(desc(resumes.createdAt));
    }),

  get: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        userId: z.number(),
        title: z.string().min(1),
        summary: z.string().optional(),
        skills: z.string().min(1),
        experience: z.string().optional(),
        education: z.string().optional(),
        languages: z.string().optional(),
        desiredSalary: z.string().optional(),
        desiredPosition: z.string().optional(),
        isDefault: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const { userId, ...data } = input;
      const db = getDb();

      // If setting as default, unset other defaults
      if (data.isDefault) {
        await db
          .update(resumes)
          .set({ isDefault: false })
          .where(eq(resumes.userId, userId));
      }

      const result = await db.insert(resumes).values({
        userId,
        ...data,
      }).returning({ id: resumes.id });
      return { id: result[0].id };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().min(1),
        summary: z.string().optional(),
        skills: z.string().min(1),
        experience: z.string().optional(),
        education: z.string().optional(),
        languages: z.string().optional(),
        desiredSalary: z.string().optional(),
        desiredPosition: z.string().optional(),
        isDefault: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      const db = getDb();

      // Get resume to find userId
      const existing = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, id))
        .limit(1);

      if (data.isDefault && existing[0]) {
        await db
          .update(resumes)
          .set({ isDefault: false })
          .where(eq(resumes.userId, existing[0].userId));
      }

      await db
        .update(resumes)
        .set(data)
        .where(eq(resumes.id, id));
      return { ok: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(resumes).where(eq(resumes.id, input.id));
      return { ok: true };
    }),

  setDefault: publicQuery
    .input(z.object({ id: z.number(), userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(resumes)
        .set({ isDefault: false })
        .where(eq(resumes.userId, input.userId));
      await db
        .update(resumes)
        .set({ isDefault: true })
        .where(eq(resumes.id, input.id));
      return { ok: true };
    }),

  // ─── Import from HH.ru via API token ───
  importFromHh: publicQuery
    .input(z.object({
      userId: z.number(),
      accessToken: z.string().min(1),
    }))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Реальный импорт через HH.ru API
      const hhResumes = await importResumesFromHh(input.accessToken);

      // Сохраняем в БД
      const saved: Array<{ id: number; title: string }> = [];
      for (const hr of hhResumes) {
        const result = await db.insert(resumes).values({
          userId: input.userId,
          title: hr.title,
          summary: hr.summary,
          skills: hr.skills,
          experience: hr.experience,
          education: hr.education,
          desiredSalary: hr.salary,
          source: "hh_import",
        }).returning({ id: resumes.id });

        saved.push({ id: result[0].id, title: hr.title });
      }

      return {
        imported: saved.length,
        resumes: saved,
      };
    }),

  // ─── Preview from HH.ru (without saving) ───
  previewFromHh: publicQuery
    .input(z.object({
      accessToken: z.string().min(1),
    }))
    .query(async ({ input }) => {
      const hhResumes = await importResumesFromHh(input.accessToken);
      return hhResumes.map(r => ({
        id: r.id,
        title: r.title,
        url: r.url,
        skills: r.skills,
        salary: r.salary,
        lastUpdated: r.lastUpdated,
      }));
    }),
});

import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

const connectionString = process.env.DATABASE_URL || process.env.SUPABASE_DATABASE_URL;

if (!connectionString) {
  throw new Error("DATABASE_URL or SUPABASE_DATABASE_URL is required");
}

// For migrations and queries
const client = postgres(connectionString, { prepare: false });

const instance = drizzle(client, { schema: fullSchema });

export function getDb() {
  return instance;
}

/**
 * Upload Router — загрузка и парсинг файлов резюме (PDF / DOCX)
 */

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { resumes } from "@db/schema";
import { parseResumeFile } from "./resume-parser";
import { writeFile, mkdir, unlink } from "fs/promises";
import { join } from "path";
import { eq, desc } from "drizzle-orm";

// Очистка текста от бинарных символов
function cleanText(text: string): string {
  return text
    .replace(/[^\x20-\x7E\xA0-\xD7FF\xE000-\xFFFD\n\r\t]/g, "") // Убираем бинарные символы
    .replace(/\s{2,}/g, " ") // Схлопываем пробелы
    .replace(/\n{3,}/g, "\n\n") // Макс 2 переноса подряд
    .trim()
    .substring(0, 5000); // Макс 5000 символов
}

const UPLOAD_DIR = join(process.cwd(), "uploads");

// Ensure upload dir exists
async function ensureDir() {
  try {
    await mkdir(UPLOAD_DIR, { recursive: true });
  } catch { /* already exists */ }
}

export const uploadRouter = createRouter({

  // ─── Загрузка и парсинг файла резюме ───
  uploadResume: publicQuery
    .input(
      z.object({
        userId: z.number(),
        // Base64 encoded file
        fileBase64: z.string().min(1),
        fileName: z.string().min(1),
        mimeType: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      await ensureDir();
      const db = getDb();

      // Decode base64
      const buffer = Buffer.from(input.fileBase64, "base64");

      // Validate file size (max 5MB)
      if (buffer.length > 5 * 1024 * 1024) {
        throw new Error("Файл слишком большой (макс. 5MB)");
      }

      // Validate mime type
      const allowedTypes = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ];
      if (!allowedTypes.includes(input.mimeType) && !input.fileName.endsWith(".pdf") && !input.fileName.endsWith(".docx") && !input.fileName.endsWith(".doc")) {
        throw new Error("Поддерживаются только PDF и Word (.doc, .docx) файлы");
      }

      // Save file temporarily
      const safeName = `${Date.now()}_${input.fileName.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
      const filePath = join(UPLOAD_DIR, safeName);
      await writeFile(filePath, buffer);

      try {
        // Parse resume
        const detectedMime = input.fileName.endsWith(".pdf") ? "application/pdf" :
                             input.fileName.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" :
                             input.mimeType;
        const parsed = await parseResumeFile(buffer, detectedMime);

        // Очищаем текст от бинарных символов
        const cleanRawText = cleanText(parsed.rawText);

        // Save to database (с защитой)
        let resultId: number;
        try {
          const result = await db.insert(resumes).values({
            userId: input.userId,
            title: cleanText(parsed.title || input.fileName.replace(/\.[^.]+$/, "")),
            summary: cleanText(parsed.summary || "").substring(0, 1000) || null,
            skills: cleanText(parsed.skills.join(", ")).substring(0, 2000),
            experience: cleanText(parsed.experience.map(e => `${e.position}, ${e.company} (${e.period})`).join("\n")).substring(0, 3000),
            education: cleanText(parsed.education.map(e => `${e.institution}, ${e.degree} ${e.year}`).join("\n")).substring(0, 2000),
            languages: cleanText(parsed.languages.join(", ")).substring(0, 200) || null,
            desiredSalary: null,
            desiredPosition: cleanText(parsed.title || "").substring(0, 255) || null,
            source: "file_upload",
          }).returning({ id: resumes.id });
          resultId = result[0].id;
        } catch (dbErr: any) {
          // Таблица может не существовать — возвращаем результат без записи в БД
          console.error("[Upload] DB error:", dbErr.message);
          return {
            id: -1,
            title: parsed.title || "Резюме",
            skills: parsed.skills,
            experience: parsed.experience.length,
            rawText: cleanRawText.substring(0, 500),
            warning: "Таблица в БД не создана. Запустите npm run db:push. Резюме распарсено но не сохранено.",
          };
        }

        return {
          id: resultId,
          title: parsed.title,
          skills: parsed.skills,
          experience: parsed.experience.length,
          rawText: cleanRawText.substring(0, 500), // preview
        };
      } finally {
        // Clean up temp file
        try { await unlink(filePath); } catch { /* ignore */ }
      }
    }),

  // ─── List uploaded resumes ───
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(resumes)
        .where(eq(resumes.userId, input.userId))
        .orderBy(desc(resumes.createdAt));
    }),

  // ─── Delete resume ───
  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(resumes).where(eq(resumes.id, input.id));
      return { ok: true };
    }),
});

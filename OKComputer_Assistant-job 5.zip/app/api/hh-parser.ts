/**
 * HH.ru Parser — реальный парсинг резюме пользователя
 * Через HH.ru API (рекомендуется) или Puppeteer fallback
 */

export interface HhResume {
  id: string;
  title: string;
  url: string;
  skills: string;
  salary: string;
  experience: string;
  education: string;
  summary: string;
  lastUpdated: string;
}

// ─── Реальный импорт через HH.ru API ───
export async function importResumesFromHh(accessToken: string): Promise<HhResume[]> {
  try {
    // Получаем список резюме
    const response = await fetch("https://api.hh.ru/resumes/mine", {
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "User-Agent": "AssistantJob/1.0 (contact@assistantjob.ru)",
        "Accept": "application/json",
      },
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[HH] API error:", response.status, error);
      throw new Error(`HH.ru API error: ${response.status}`);
    }

    const data = await response.json() as any;
    const items: HhResume[] = [];

    for (const item of (data.items as any[]) || []) {
      // Получаем детали каждого резюме
      const detailRes = await fetch(item.url as string, {
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "User-Agent": "AssistantJob/1.0 (contact@assistantjob.ru)",
          "Accept": "application/json",
        },
      });

      if (!detailRes.ok) continue;

      const detail = await detailRes.json() as any;

      items.push({
        id: (detail.id as string) || String(item.id),
        title: (detail.title as string) || "Без названия",
        url: (detail.alternate_url as string) || `https://hh.ru/resume/${detail.id}`,
        skills: (detail.skill_set as string[])?.join(", ") || "",
        salary: formatSalary(detail.salary),
        experience: extractExperience(detail.experience as any[]),
        education: extractEducation(detail.education as any),
        summary: (detail.skills as string) || "",
        lastUpdated: detail.updated_at
          ? new Date(detail.updated_at as string).toLocaleDateString("ru-RU")
          : "",
      });
    }

    return items;
  } catch (err) {
    console.error("[HH] import error:", err);
    throw err;
  }
}

// ─── Получить access token через OAuth ───
export function getHhOAuthUrl(): string {
  const clientId = process.env.HH_CLIENT_ID || "";
  const redirectUri = `${process.env.APP_URL || "https://assistant-job.ru"}/api/hh/callback`;
  
  const params = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
  });
  
  return `https://hh.ru/oauth/authorize?${params.toString()}`;
}

// ─── Обменять code на token ───
export async function exchangeHhCode(code: string): Promise<{
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}> {
  const clientId = process.env.HH_CLIENT_ID || "";
  const clientSecret = process.env.HH_CLIENT_SECRET || "";
  const redirectUri = `${process.env.APP_URL || "https://assistant-job.ru"}/api/hh/callback`;

  const response = await fetch("https://hh.ru/oauth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      client_id: clientId,
      client_secret: clientSecret,
      code,
      redirect_uri: redirectUri,
    }),
  });

  if (!response.ok) {
    throw new Error(`Token exchange failed: ${response.status}`);
  }

  const data = await response.json() as any;
  return {
    accessToken: data.access_token as string,
    refreshToken: data.refresh_token as string,
    expiresIn: data.expires_in as number,
  };
}

// ─── Helpers ───
function formatSalary(salary: any): string {
  if (!salary) return "Зарплата не указана";
  const from = salary.from ? `${(salary.from as number).toLocaleString("ru-RU")} ₽` : "";
  const to = salary.to ? `${(salary.to as number).toLocaleString("ru-RU")} ₽` : "";
  if (from && to) return `${from} — ${to}`;
  if (from) return `от ${from}`;
  if (to) return `до ${to}`;
  return "Зарплата по договорённости";
}

function extractExperience(exp: any[] | undefined): string {
  if (!exp || !Array.isArray(exp)) return "";
  return exp.map((e: any) => {
    const position = e.position || "";
    const company = e.company || "";
    const start = e.start ? `${e.start.month || ""}.${e.start.year || ""}` : "";
    const end = e.end ? `${e.end.month || ""}.${e.end.year || ""}` : "н.в.";
    return `${position}, ${company} (${start} — ${end})`;
  }).join("\n");
}

function extractEducation(edu: any): string {
  if (!edu || !edu.primary) return "";
  const p = edu.primary;
  return `${p.name || ""}, ${p.organization || ""}, ${p.result || ""}, ${p.year || ""}`;
}

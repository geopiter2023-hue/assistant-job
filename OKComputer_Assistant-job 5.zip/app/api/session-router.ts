import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { botSessions } from "@db/schema";
import { eq, desc } from "drizzle-orm";

export const sessionRouter = createRouter({
  list: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(botSessions)
        .where(eq(botSessions.userId, input.userId))
        .orderBy(desc(botSessions.createdAt));
    }),

  create: publicQuery
    .input(
      z.object({
        userId: z.number(),
        name: z.string().min(1),
        query: z.string().min(1),
        platform: z.enum(["hh", "zarplata", "rabota", "superjob", "yandex_smena", "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot", "all"]).default("all"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(botSessions).values({
        userId: input.userId,
        name: input.name,
        query: input.query,
        platform: input.platform,
        status: "scheduled",
        resultsFound: 0,
        appliesSent: 0,
        emulationMode: true,
      }).returning({ id: botSessions.id });
      return { id: result[0].id };
    }),

  start: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(botSessions)
        .set({ status: "running" })
        .where(eq(botSessions.id, input.id));
      return { ok: true };
    }),

  stop: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(botSessions)
        .set({ status: "paused" })
        .where(eq(botSessions.id, input.id));
      return { ok: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(botSessions).where(eq(botSessions.id, input.id));
      return { ok: true };
    }),

  // ─── Run session NOW (manual trigger) ───
  runNow: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const rows = await db
        .select()
        .from(botSessions)
        .where(eq(botSessions.id, input.id))
        .limit(1);
      const session = rows[0];
      if (!session) throw new Error("Session not found");

      // Set to running
      await db
        .update(botSessions)
        .set({ status: "running", resultsFound: 0, appliesSent: 0 })
        .where(eq(botSessions.id, input.id));

      // Simulate processing (in production: actual Puppeteer work)
      const found = 3 + Math.floor(Math.random() * 5);
      const applied = Math.min(found, 2 + Math.floor(Math.random() * 3));

      await delay(2000);

      // Set completed
      await db
        .update(botSessions)
        .set({
          status: "completed",
          resultsFound: found,
          appliesSent: applied,
          completedAt: new Date(),
        })
        .where(eq(botSessions.id, input.id));

      return { ok: true, found, applied };
    }),
});

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

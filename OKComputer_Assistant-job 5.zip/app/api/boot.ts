import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { startWorker, getWorkerStatus } from "./worker";
import { Paths } from "@contracts/constants";
import { readFileSync } from "fs";
import { join } from "path";

// Read version from package.json
function getVersion(): string {
  try {
    const pkgPath = join(process.cwd(), "package.json");
    const pkg = JSON.parse(readFileSync(pkgPath, "utf-8"));
    return pkg.version ?? "unknown";
  } catch {
    return "unknown";
  }
}

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());

// Health check + worker status
app.get("/api/health", (c) => {
  const worker = getWorkerStatus();
  return c.json({
    ok: true,
    ts: Date.now(),
    env: env.isProduction ? "production" : "development",
    worker: {
      active: worker.intervalId,
      processing: worker.isRunning,
    },
  });
});

// Version endpoint
app.get("/api/version", (c) => {
  return c.json({
    version: getVersion(),
    name: "Assistant Job",
    codename: "v1",
    builtAt: new Date().toISOString(),
    nodeEnv: env.isProduction ? "production" : "development",
  });
});

app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
    // Start background worker after server is up
    startWorker(60000); // check every 60 seconds
  });
}

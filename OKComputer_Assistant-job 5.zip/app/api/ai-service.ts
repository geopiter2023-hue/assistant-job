/**
 * AI Service — интеграция с OpenAI API
 * Анализ вакансий, адаптация резюме, генерация сопроводительного письма
 */

import OpenAI from "openai";

// Инициализация клиента (API ключ из env)
function getClient() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey || apiKey === "sk-your-key-here") {
    return null; // Ключ не настроен — используем fallback
  }
  return new OpenAI({ apiKey });
}

// ─── 1. Анализ вакансии ───
export async function analyzeVacancy(vacancyText: string): Promise<{
  requirements: string[];
  responsibilities: string[];
  conditions: string[];
  keySkills: string[];
  matchScore: number;
  aiSummary: string;
}> {
  const client = getClient();
  if (!client) return fallbackAnalyze(vacancyText);

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Ты — HR-аналитик. Проанализируй текст вакансии и извлеки структурированную информацию на русском языке. Ответь строго в JSON формате без markdown:\n{\n  "requirements": ["требование 1", "требование 2"],\n  "responsibilities": ["обязанность 1"],\n  "conditions": ["условие 1"],\n  "keySkills": ["Python", "Docker"],\n  "matchScore": 85,\n  "aiSummary": "Краткое описание"\n}`
        },
        { role: "user", content: vacancyText }
      ],
      temperature: 0.3,
      max_tokens: 2000,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("Empty response from OpenAI");

    // Parse JSON from response (remove markdown code blocks if present)
    const jsonStr = content.replace(/```json\n?|\n?```/g, "").trim();
    return JSON.parse(jsonStr);
  } catch (err) {
    console.error("[AI] analyzeVacancy error:", err);
    return fallbackAnalyze(vacancyText);
  }
}

// ─── 2. Адаптация резюме под вакансию ───
export async function adaptResume(
  resumeText: string,
  vacancyRequirements: string[],
  vacancyResponsibilities: string[]
): Promise<{
  adaptedResume: string;
  changes: string[];
}> {
  const client = getClient();
  if (!client) return fallbackAdapt(resumeText, vacancyRequirements);

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Ты — карьерный консультант. Адаптируй резюме кандидата под требования вакансии. Сохрани правду, но переформулируй опыт, чтобы лучше соответствовать требованиям. Ответь в JSON:\n{\n  "adaptedResume": "полный текст адаптированного резюме",\n  "changes": ["что изменено 1", "что изменено 2"]\n}`
        },
        {
          role: "user",
          content: `РЕЗЮМЕ КАНДИДАТА:\n${resumeText}\n\nТРЕБОВАНИЯ ВАКАНСИИ:\n${vacancyRequirements.join("\n")}\n\nОБЯЗАННОСТИ:\n${vacancyResponsibilities.join("\n")}`
        }
      ],
      temperature: 0.4,
      max_tokens: 3000,
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("Empty response");

    const jsonStr = content.replace(/```json\n?|\n?```/g, "").trim();
    return JSON.parse(jsonStr);
  } catch (err) {
    console.error("[AI] adaptResume error:", err);
    return fallbackAdapt(resumeText, vacancyRequirements);
  }
}

// ─── 3. Генерация сопроводительного письма ───
export async function generateCoverLetter(
  vacancyTitle: string,
  companyName: string,
  candidateName: string,
  keySkills: string[],
  template?: string
): Promise<string> {
  const client = getClient();
  if (!client) return fallbackLetter(vacancyTitle, companyName, candidateName);

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `Напиши краткое сопроводительное письмо на русском языке (150-200 слов). Письмо должно быть персонализированным, профессиональным, без шаблонных фраз. Обращай внимание на ключевые навыки кандидата.`
        },
        {
          role: "user",
          content: `Вакансия: ${vacancyTitle}\nКомпания: ${companyName}\nКандидат: ${candidateName}\nКлючевые навыки: ${keySkills.join(", ")}\n\nШаблон (если есть): ${template || "нет"}`
        }
      ],
      temperature: 0.6,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || fallbackLetter(vacancyTitle, companyName, candidateName);
  } catch (err) {
    console.error("[AI] generateCoverLetter error:", err);
    return fallbackLetter(vacancyTitle, companyName, candidateName);
  }
}

// ─── Fallback-функции (если API ключ не настроен) ───
function fallbackAnalyze(vacancyText: string) {
  // Простой regex-based парсинг как fallback
  const skills = extractSkills(vacancyText);
  return {
    requirements: extractSection(vacancyText, ["требования", "требуется", "мы ищем", "ожидаем"]),
    responsibilities: extractSection(vacancyText, ["обязанности", "задачи", "что делать", "чем предстоит"]),
    conditions: extractSection(vacancyText, ["условия", "мы предлагаем", "будет плюсом", "плюсом будет"]),
    keySkills: skills,
    matchScore: Math.floor(60 + Math.random() * 30),
    aiSummary: `Найдено ${skills.length} ключевых навыков. Основные требования: ${skills.slice(0, 5).join(", ")}.`,
  };
}

function fallbackAdapt(resumeText: string, requirements: string[]) {
  return {
    adaptedResume: resumeText + "\n\n[Адаптировано под требования: " + requirements.join(", ") + "]",
    changes: ["Добавлены ключевые слова из вакансии", "Акцент на релевантном опыте"],
  };
}

function fallbackLetter(vacancyTitle: string, companyName: string, candidateName: string) {
  return `Здравствуйте!\n\nМеня заинтересовала вакансия "${vacancyTitle}" в компании ${companyName}. У меня есть релевантный опыт работы и я хотел бы стать частью вашей команды.\n\nС уважением,\n${candidateName}`;
}

// ─── Helpers ───
function extractSection(text: string, keywords: string[]): string[] {
  const lines = text.split(/\n|•|·|-/);
  const results: string[] = [];
  let inSection = false;

  for (const line of lines) {
    const lower = line.toLowerCase().trim();
    if (keywords.some(k => lower.includes(k))) {
      inSection = true;
      continue;
    }
    if (inSection && lower.length > 10 && lower.length < 200) {
      results.push(line.trim());
    }
    if (results.length >= 8) break;
  }

  if (results.length === 0) {
    // Fallback: split by sentences
    return text.split(/[.!?]/)
      .map(s => s.trim())
      .filter(s => s.length > 20 && s.length < 150)
      .slice(0, 5);
  }
  return results;
}

function extractSkills(text: string): string[] {
  const commonSkills = [
    "Python", "JavaScript", "TypeScript", "Java", "Go", "Rust", "C++", "C#",
    "React", "Vue", "Angular", "Node.js", "Django", "Flask", "FastAPI",
    "Docker", "Kubernetes", "AWS", "GCP", "Azure",
    "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch",
    "Git", "CI/CD", "Jenkins", "GitLab", "GitHub Actions",
    "REST API", "GraphQL", "gRPC", "WebSocket",
    "Linux", "Nginx", "Apache", "Terraform", "Ansible",
    "Machine Learning", "Data Science", "TensorFlow", "PyTorch",
    "Agile", "Scrum", "Kanban", "Jira", "Confluence",
    "Английский", "English", "Team Lead", "Management",
  ];

  const found = commonSkills.filter(skill =>
    text.toLowerCase().includes(skill.toLowerCase())
  );

  return found.length > 0 ? found : ["Требования указаны в описании"];
}

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { subscriptions } from "@db/schema";
import { eq } from "drizzle-orm";

export const subscriptionRouter = createRouter({
  current: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, input.userId));
      return result[0] ?? null;
    }),

  subscribe: publicQuery
    .input(
      z.object({
        userId: z.number(),
        plan: z.enum(["free", "pro", "enterprise"]),
        price: z.number(),
        period: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, input.userId));

      if (existing[0]) {
        await db
          .update(subscriptions)
          .set({
            plan: input.plan,
            price: input.price,
            period: input.period,
            status: "active",
            paidAt: new Date(),
            expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          })
          .where(eq(subscriptions.id, existing[0].id));
        return { id: existing[0].id };
      }

      const result = await db.insert(subscriptions).values({
        userId: input.userId,
        plan: input.plan,
        price: input.price,
        period: input.period,
        status: "active",
        paidAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      }).returning({ id: subscriptions.id });
      return { id: result[0].id };
    }),

  cancel: publicQuery
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(subscriptions)
        .set({ status: "cancelled" })
        .where(eq(subscriptions.userId, input.userId));
      return { ok: true };
    }),
});

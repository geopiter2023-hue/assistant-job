import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { vacancyAnalyses, applyDrafts, resumes } from "@db/schema";
import { eq } from "drizzle-orm";
import { analyzeVacancy, adaptResume, generateCoverLetter } from "./ai-service";
import { searchVacancies } from "./scraper";

/**
 * AI Pipeline Router — реальные AI + парсинг вакансий
 * 
 * 1. searchVacancies — поиск реальных вакансий на HH.ru и др.
 * 2. analyzeVacancy — AI-анализ требований, обязанностей, навыков
 * 3. adaptResume — адаптация резюме под вакансию
 * 4. generateCoverLetter — генерация сопроводительного письма
 * 5. createDraft — сохранение черновика
 */

export const aiRouter = createRouter({

  // ─── 1. Поиск реальных вакансий ───
  searchVacancies: publicQuery
    .input(
      z.object({
        query: z.string().min(1),
        platforms: z.array(z.string()).default(["hh"]),
        area: z.number().optional(),
        salary: z.number().optional(),
        experience: z.string().optional(),
        remote: z.boolean().optional(),
        page: z.number().default(0),
      })
    )
    .mutation(async ({ input }) => {
      const vacancies = await searchVacancies(input.query, input.platforms, {
        area: input.area,
        salary: input.salary,
        experience: input.experience,
        remote: input.remote,
        page: input.page,
      });

      return vacancies;
    }),

  // ─── 2. AI-анализ вакансии ───
  analyzeVacancy: publicQuery
    .input(
      z.object({
        userId: z.number(),
        vacancyUrl: z.string(),
        vacancyTitle: z.string(),
        company: z.string().optional(),
        platform: z.enum(["hh", "zarplata", "rabota", "superjob", "yandex_smena", "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot"]),
        rawDescription: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Реальный AI-анализ через OpenAI (fallback если ключ не настроен)
      const aiResult = await analyzeVacancy(input.rawDescription);

      const result = await db.insert(vacancyAnalyses).values({
        userId: input.userId,
        vacancyUrl: input.vacancyUrl,
        vacancyTitle: input.vacancyTitle,
        company: input.company ?? null,
        platform: input.platform,
        rawDescription: input.rawDescription,
        requirements: aiResult.requirements.join("\n"),
        responsibilities: aiResult.responsibilities.join("\n"),
        conditions: aiResult.conditions.join("\n"),
        keySkills: aiResult.keySkills.join(", "),
        matchScore: aiResult.matchScore,
        aiSummary: aiResult.aiSummary,
      }).returning({ id: vacancyAnalyses.id });

      return {
        id: result[0].id,
        requirements: aiResult.requirements,
        responsibilities: aiResult.responsibilities,
        conditions: aiResult.conditions,
        keySkills: aiResult.keySkills,
        matchScore: aiResult.matchScore,
        aiSummary: aiResult.aiSummary,
      };
    }),

  // ─── 2b. AI-анализ с парсингом (полный pipeline) ───
  analyzeWithScraper: publicQuery
    .input(
      z.object({
        userId: z.number(),
        vacancyId: z.string(),
        vacancyUrl: z.string(),
        vacancyTitle: z.string(),
        company: z.string().optional(),
        platform: z.enum(["hh", "zarplata", "rabota", "superjob", "yandex_smena", "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot"]),
        rawDescription: z.string(),
        responsibilities: z.array(z.string()).optional(),
        requirements: z.array(z.string()).optional(),
        conditions: z.array(z.string()).optional(),
        keySkills: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Формируем полный текст для AI-анализа
      const fullText = `
Вакансия: ${input.vacancyTitle}
Компания: ${input.company || "Неизвестно"}

Описание:
${input.rawDescription}

Обязанности:
${(input.responsibilities || []).join("\n")}

Требования:
${(input.requirements || []).join("\n")}

Условия:
${(input.conditions || []).join("\n")}

Навыки: ${(input.keySkills || []).join(", ")}
`;

      // Реальный AI-анализ
      const aiResult = await analyzeVacancy(fullText);

      const result = await db.insert(vacancyAnalyses).values({
        userId: input.userId,
        vacancyUrl: input.vacancyUrl,
        vacancyTitle: input.vacancyTitle,
        company: input.company ?? null,
        platform: input.platform,
        rawDescription: input.rawDescription,
        requirements: aiResult.requirements.join("\n"),
        responsibilities: aiResult.responsibilities.join("\n"),
        conditions: aiResult.conditions.join("\n"),
        keySkills: aiResult.keySkills.join(", "),
        matchScore: aiResult.matchScore,
        aiSummary: aiResult.aiSummary,
      }).returning({ id: vacancyAnalyses.id });

      return {
        id: result[0].id,
        requirements: aiResult.requirements,
        responsibilities: aiResult.responsibilities,
        conditions: aiResult.conditions,
        keySkills: aiResult.keySkills,
        matchScore: aiResult.matchScore,
        aiSummary: aiResult.aiSummary,
      };
    }),

  // ─── 3. Адаптация резюме под вакансию ───
  adaptResume: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Получаем резюме
      const resumeRows = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.resumeId))
        .limit(1);
      const resume = resumeRows[0];
      if (!resume) throw new Error("Резюме не найдено");

      // Получаем анализ вакансии
      const analysisRows = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.analysisId))
        .limit(1);
      const analysis = analysisRows[0];
      if (!analysis) throw new Error("Анализ не найден");

      // Реальная AI-адаптация резюме
      const resumeText = `
${resume.title}
${resume.summary || ""}

Навыки: ${resume.skills}

Опыт: ${resume.experience}

Образование: ${resume.education || ""}
`;

      const requirements = analysis.requirements ? analysis.requirements.split("\n").filter(Boolean) : [];
      const responsibilities = analysis.responsibilities ? analysis.responsibilities.split("\n").filter(Boolean) : [];

      const adapted = await adaptResume(resumeText, requirements, responsibilities);

      return {
        editedResumeText: adapted.adaptedResume,
        changes: adapted.changes,
        originalSnapshot: {
          title: resume.title,
          skills: resume.skills,
          experience: resume.experience,
          summary: resume.summary,
        },
      };
    }),

  // ─── 4. Генерация сопроводительного письма ───
  generateCoverLetter: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
        candidateName: z.string(),
        template: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const analysisRows = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.analysisId))
        .limit(1);
      const analysis = analysisRows[0];
      if (!analysis) throw new Error("Анализ не найден");

      // Реальная AI-генерация письма
      const skills = analysis.keySkills ? analysis.keySkills.split(", ") : [];
      const coverLetter = await generateCoverLetter(
        analysis.vacancyTitle ?? "Вакансия",
        analysis.company ?? "Компания",
        input.candidateName,
        skills,
        input.template
      );

      return { coverLetter };
    }),

  // ─── 4b. Полный pipeline: анализ + резюме + письмо ───
  fullPipeline: publicQuery
    .input(
      z.object({
        userId: z.number(),
        vacancyUrl: z.string(),
        vacancyTitle: z.string(),
        company: z.string().optional(),
        platform: z.enum(["hh", "zarplata", "rabota", "superjob", "yandex_smena", "karierist", "rabotaru", "avito", "trudvsem", "gorodrabot"]),
        rawDescription: z.string(),
        responsibilities: z.array(z.string()).optional(),
        requirements: z.array(z.string()).optional(),
        conditions: z.array(z.string()).optional(),
        keySkills: z.array(z.string()).optional(),
        resumeId: z.number(),
        candidateName: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Шаг 1: AI-анализ вакансии
      const fullText = `
Вакансия: ${input.vacancyTitle}
Компания: ${input.company || "Неизвестно"}

Описание:
${input.rawDescription}

Обязанности:
${(input.responsibilities || []).join("\n")}

Требования:
${(input.requirements || []).join("\n")}
`;

      const aiAnalysis = await analyzeVacancy(fullText);

      // Сохраняем анализ
      const analysisResult = await db.insert(vacancyAnalyses).values({
        userId: input.userId,
        vacancyUrl: input.vacancyUrl,
        vacancyTitle: input.vacancyTitle,
        company: input.company ?? null,
        platform: input.platform,
        rawDescription: input.rawDescription,
        requirements: aiAnalysis.requirements.join("\n"),
        responsibilities: aiAnalysis.responsibilities.join("\n"),
        conditions: aiAnalysis.conditions.join("\n"),
        keySkills: aiAnalysis.keySkills.join(", "),
        matchScore: aiAnalysis.matchScore,
        aiSummary: aiAnalysis.aiSummary,
      }).returning({ id: vacancyAnalyses.id });

      const analysisId = analysisResult[0].id;

      // Шаг 2: Получаем резюме
      const resumeRows = await db
        .select()
        .from(resumes)
        .where(eq(resumes.id, input.resumeId))
        .limit(1);
      const resume = resumeRows[0];

      // Шаг 3: Адаптируем резюме
      let adaptedResume = null;
      if (resume) {
        const resumeText = `${resume.title}\n${resume.summary || ""}\nНавыки: ${resume.skills}\nОпыт: ${resume.experience}`;
        adaptedResume = await adaptResume(resumeText, aiAnalysis.requirements, aiAnalysis.responsibilities);
      }

      // Шаг 4: Генерируем письмо
      const coverLetter = await generateCoverLetter(
        input.vacancyTitle,
        input.company ?? "Компания",
        input.candidateName,
        aiAnalysis.keySkills
      );

      // Шаг 5: Сохраняем черновик
      const draftResult = await db.insert(applyDrafts).values({
        userId: input.userId,
        vacancyAnalysisId: analysisId,
        resumeId: input.resumeId,
        editedResumeText: adaptedResume?.adaptedResume || "Резюме не адаптировано",
        coverLetter,
        aiReasoning: `Совпадение навыков: ${aiAnalysis.matchScore}%. ${aiAnalysis.aiSummary}`,
        status: "draft",
      }).returning({ id: applyDrafts.id });

      return {
        analysisId,
        draftId: draftResult[0].id,
        matchScore: aiAnalysis.matchScore,
        requirements: aiAnalysis.requirements,
        responsibilities: aiAnalysis.responsibilities,
        keySkills: aiAnalysis.keySkills,
        aiSummary: aiAnalysis.aiSummary,
        coverLetter,
        adaptedResume: adaptedResume?.adaptedResume || null,
        changes: adaptedResume?.changes || [],
      };
    }),

  // ─── 5. Создание черновика ───
  createDraft: publicQuery
    .input(
      z.object({
        userId: z.number(),
        analysisId: z.number(),
        resumeId: z.number(),
        editedResumeText: z.string(),
        coverLetter: z.string(),
        aiReasoning: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const result = await db.insert(applyDrafts).values({
        userId: input.userId,
        vacancyAnalysisId: input.analysisId,
        resumeId: input.resumeId,
        editedResumeText: input.editedResumeText,
        coverLetter: input.coverLetter,
        aiReasoning: input.aiReasoning ?? null,
        status: "draft",
      }).returning({ id: applyDrafts.id });

      return { id: result[0].id };
    }),

  // ─── List Drafts ───
  listDrafts: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(applyDrafts)
        .where(eq(applyDrafts.userId, input.userId))
        .orderBy(applyDrafts.createdAt);
    }),

  // ─── Get Draft ───
  getDraft: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(applyDrafts)
        .where(eq(applyDrafts.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),

  // ─── Approve Draft ───
  approveDraft: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(applyDrafts)
        .set({ status: "approved" })
        .where(eq(applyDrafts.id, input.id));
      return { ok: true };
    }),

  // ─── Mark as Sent ───
  markSent: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(applyDrafts)
        .set({ status: "sent" })
        .where(eq(applyDrafts.id, input.id));
      return { ok: true };
    }),

  // ─── Import Resumes from HH.ru ───
  importFromHh: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async () => {
      return [
        { id: "hh_1", title: "Senior Python Developer", url: "https://hh.ru/resume/abc123", lastUpdated: "2 дня назад", skills: "Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Redis, Kafka", salary: "500 000 — 700 000 ₽" },
        { id: "hh_2", title: "Backend Developer (Python/Django)", url: "https://hh.ru/resume/def456", lastUpdated: "1 неделю назад", skills: "Python, Django, Celery, PostgreSQL, Docker, REST API", salary: "300 000 — 450 000 ₽" },
        { id: "hh_3", title: "Python Tech Lead", url: "https://hh.ru/resume/ghi789", lastUpdated: "3 дня назад", skills: "Python, Django, FastAPI, PostgreSQL, Docker, Kubernetes, Team Leadership, gRPC", salary: "600 000 — 900 000 ₽" },
      ];
    }),

  // ─── Parse Single HH Resume ───
  parseHhResume: publicQuery
    .input(z.object({ userId: z.number(), resumeId: z.string(), resumeUrl: z.string() }))
    .mutation(async () => {
      return {
        title: "Senior Python Developer",
        summary: "Разработчик с 6-летним опытом в Python-экосистеме. Специализируюсь на проектировании микросервисных архитектур и высоконагруженных систем.",
        skills: "Python, Django, FastAPI, PostgreSQL, MongoDB, Docker, Kubernetes, Redis, Kafka, Celery, asyncio, gRPC, REST API, GraphQL, Git, CI/CD, Jenkins, Nginx, Prometheus, Grafana",
        experience: "Senior Python Developer, Т-Банк (2022 — настоящее время)\n• Проектирование архитектуры backend-сервисов (100k+ RPS)\n• Управление командой из 5 разработчиков\n\nMiddle Python Developer, Яндекс (2020 — 2022)\n• Разработка сервисов на Python/FastAPI\n• Интеграция с PostgreSQL, Redis, Kafka",
        education: "МГТУ им. Баумана, Факультет ИУ, Магистр (2017-2019)",
        languages: "Русский (родной), Английский (B2)",
        desiredSalary: "500 000 — 700 000 ₽",
        desiredPosition: "Senior Python Developer / Team Lead Backend",
      };
    }),

  // ─── Get Analysis ───
  getAnalysis: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(vacancyAnalyses)
        .where(eq(vacancyAnalyses.id, input.id))
        .limit(1);
      return result[0] ?? null;
    }),
});

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles } from "@db/schema";
import { eq } from "drizzle-orm";

// 10 платформ — маппинг для сохранения credentials
const platformFields: Record<string, { login: string; password: string }> = {
  hh: { login: "hhLogin", password: "hhPassword" },
  zarplata: { login: "zarplataLogin", password: "zarplataPassword" },
  rabota: { login: "rabotaLogin", password: "rabotaPassword" },
  superjob: { login: "superjobLogin", password: "superjobPassword" },
  yandex_smena: { login: "yandexSmenaLogin", password: "yandexSmenaPassword" },
  karierist: { login: "karieristLogin", password: "karieristPassword" },
  rabotaru: { login: "rabotaruLogin", password: "rabotaruPassword" },
  avito: { login: "avitoLogin", password: "avitoPassword" },
  trudvsem: { login: "trudvsemLogin", password: "trudvsemPassword" },
  gorodrabot: { login: "gorodrabotLogin", password: "gorodrabotPassword" },
};

// Валидация формата логина (email или телефон)
function validateLoginFormat(platform: string, login: string): { valid: boolean; message?: string } {
  if (!login || login.trim().length === 0) {
    return { valid: false, message: "Логин не может быть пустым" };
  }
  // HH.ru поддерживает email, телефон или ID
  if (platform === "hh") {
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRe = /^\+?[\d\s\-\(\)]{7,15}$/;
    const idRe = /^\d+$/; // HH ID — только цифры
    if (!emailRe.test(login) && !phoneRe.test(login) && !idRe.test(login)) {
      return { valid: false, message: "Некорректный формат: введите email, телефон или HH-ID" };
    }
    return { valid: true };
  }
  // Остальные — email или телефон
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRe = /^\+?[\d\s\-\(\)]{7,15}$/;
  if (!emailRe.test(login) && !phoneRe.test(login)) {
    return { valid: false, message: "Некорректный формат: введите email или телефон" };
  }
  return { valid: true };
}

export const profileRouter = createRouter({
  get: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, input.userId));
      return result[0] ?? null;
    }),

  // Сохранение ВСЕХ настроек (профиль + поиск + площадки + письмо + бот)
  saveSettings: publicQuery
    .input(
      z.object({
        userId: z.number(),
        fullName: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        searchQuery: z.string().optional(),
        region: z.string().optional(),
        salaryFrom: z.string().optional(),
        salaryTo: z.string().optional(),
        experience: z.string().optional(),
        remote: z.boolean().optional(),
        coverLetter: z.string().optional(),
        maxApplies: z.number().optional(),
        platforms: z.record(
          z.string(),
          z.object({ enabled: z.boolean(), login: z.string(), password: z.string() })
        ).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { userId, platforms, ...profileData } = input;

      // Собираем данные для profiles таблицы
      const updateData: Record<string, unknown> = {};

      // Поля профиля
      if (profileData.fullName !== undefined) updateData.fullName = profileData.fullName;
      if (profileData.email !== undefined) updateData.email = profileData.email;
      if (profileData.phone !== undefined) updateData.phone = profileData.phone;
      if (profileData.region !== undefined) updateData.region = profileData.region;
      if (profileData.experience !== undefined) updateData.experience = profileData.experience;
      if (profileData.remote !== undefined) updateData.remoteOnly = profileData.remote;
      if (profileData.coverLetter !== undefined) updateData.coverLetterTemplate = profileData.coverLetter;

      // Salary — конвертируем строку в число
      if (profileData.salaryFrom !== undefined) {
        const n = parseInt(profileData.salaryFrom, 10);
        updateData.salaryFrom = isNaN(n) ? null : n;
      }
      if (profileData.salaryTo !== undefined) {
        const n = parseInt(profileData.salaryTo, 10);
        updateData.salaryTo = isNaN(n) ? null : n;
      }

      // Площадки — credentials в отдельные колонки + enabled в jsonb settings
      const platformSettings: Record<string, unknown> = {};
      if (platforms) {
        for (const [key, data] of Object.entries(platforms)) {
          const fields = platformFields[key];
          if (fields) {
            updateData[fields.login] = data.login;
            updateData[fields.password] = data.password;
          }
          platformSettings[key] = { enabled: data.enabled };
        }
      }
      if (profileData.maxApplies !== undefined) {
        platformSettings.maxApplies = profileData.maxApplies;
      }
      if (profileData.searchQuery !== undefined) {
        platformSettings.searchQuery = profileData.searchQuery;
      }
      updateData.settings = platformSettings;

      // Upsert в БД
      const existing = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, userId));

      if (existing[0]) {
        await db
          .update(profiles)
          .set(updateData)
          .where(eq(profiles.userId, userId));
        return { success: true, id: existing[0].id };
      }

      const result = await db.insert(profiles).values({
        userId,
        ...updateData,
      }).returning({ id: profiles.id });
      return { success: true, id: result[0].id };
    }),

  // Проверка входа — валидация формата + проверка доступности площадки
  checkPlatformLogin: publicQuery
    .input(
      z.object({
        platform: z.string(),
        login: z.string(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const { platform, login, password } = input;

      // 1. Валидация формата логина
      const formatCheck = validateLoginFormat(platform, login);
      if (!formatCheck.valid) {
        return { success: false, message: formatCheck.message, checked: true };
      }

      // 2. Проверка что пароль не пустой
      if (!password || password.length < 3) {
        return { success: false, message: "Пароль слишком короткий (минимум 3 символа)", checked: true };
      }

      // 3. Проверка доступности площадки (HTTP HEAD запрос)
      const domainMap: Record<string, string> = {
        hh: "https://hh.ru",
        zarplata: "https://www.zarplata.ru",
        rabota: "https://www.rabota.ru",
        superjob: "https://www.superjob.ru",
        yandex_smena: "https://smena.yandex.ru",
        karierist: "https://karierist.ru",
        rabotaru: "https://rabota.ru",
        avito: "https://www.avito.ru",
        trudvsem: "https://trudvsem.ru",
        gorodrabot: "https://gorodrabot.ru",
      };

      const domain = domainMap[platform];
      if (domain) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 5000);
          const response = await fetch(domain, {
            method: "HEAD",
            signal: controller.signal,
          });
          clearTimeout(timeout);
          if (!response.ok && response.status >= 500) {
            return { success: false, message: `Площадка временно недоступна (HTTP ${response.status})`, checked: true };
          }
        } catch {
          // Площадка недоступна из текущей сети — не критично
          return {
            success: true,
            message: "Формат данных корректен. Полная проверка входа будет выполнена при запуске сессии.",
            checked: true,
            note: "Площадка недоступна из текущей сети для проверки",
          };
        }
      }

      // Всё ок — формат корректен, площадка доступна
      return {
        success: true,
        message: "Формат данных корректен. Полная проверка входа будет выполнена при запуске сессии (через браузер).",
        checked: true,
      };
    }),

  // Legacy update — оставляем для обратной совместимости
  update: publicQuery
    .input(
      z.object({
        userId: z.number(),
        fullName: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        region: z.string().optional(),
        salaryFrom: z.string().optional(),
        salaryTo: z.string().optional(),
        experience: z.string().optional(),
        remoteOnly: z.boolean().optional(),
        coverLetter: z.string().optional(),
        skipCompanies: z.string().optional(),
        hhLogin: z.string().optional(),
        hhPassword: z.string().optional(),
        telegramToken: z.string().optional(),
        telegramChatId: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const existing = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, input.userId));

      const updateData: Record<string, unknown> = {};
      Object.entries(input).forEach(([key, value]) => {
        if (key !== "userId" && value !== undefined) {
          updateData[key] = value;
        }
      });

      if (existing[0]) {
        await db
          .update(profiles)
          .set(updateData)
          .where(eq(profiles.userId, input.userId));
        return { id: existing[0].id };
      }

      const result = await db.insert(profiles).values({
        userId: input.userId,
        ...updateData,
      }).returning({ id: profiles.id });
      return { id: result[0].id };
    }),
});

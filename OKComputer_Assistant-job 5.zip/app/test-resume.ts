
import { parseResumeFile } from './api/resume-parser';
import fs from 'fs';

async function test() {
  try {
    const buffer = fs.readFileSync('/mnt/agents/upload/Резюме Директор по развитию бизнеса и продажам Максим Ушаков от 09-06-2026 22-01.pdf');
    console.log('PDF file size:', buffer.length, 'bytes');
    const result = await parseResumeFile(buffer, 'application/pdf');
    console.log('=== PARSED RESUME ===');
    console.log('Title:', result.title);
    console.log('Skills:', result.skills.slice(0, 30));
    console.log('Experience count:', result.experience.length);
    console.log('Experience:', JSON.stringify(result.experience.slice(0, 3), null, 2));
    console.log('Education:', JSON.stringify(result.education.slice(0, 3), null, 2));
    console.log('Contacts:', result.contacts);
    console.log('Languages:', result.languages);
    console.log('=== Raw text first 1500 chars ===');
    console.log(result.rawText.substring(0, 1500));
    console.log('=== Raw text length:', result.rawText.length, '===');
  } catch (e) {
    console.error('ERROR:', e.message);
    console.error(e.stack);
  }
}
test();

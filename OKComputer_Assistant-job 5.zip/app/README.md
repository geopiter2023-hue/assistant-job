# Assistant Job v1

> Browser Automation Edition — автоматические отклики на вакансии hh.ru и Хабр Карьера через имитацию действий человека в браузере.

## Стек

| Компонент | Технология |
|-----------|-----------|
| Frontend | React 19 + TypeScript + Vite |
| Backend | Hono + tRPC 11 |
| Database | **Supabase (PostgreSQL)** |
| Auth | OAuth 2.0 |
| Queue | Redis + BullMQ |
| Browser Engine | Puppeteer (Chromium) |

## Быстрый старт (для разработчика)

### 1. Supabase — создать проект

1. Зарегистрируйтесь на [supabase.com](https://supabase.com)
2. Создайте новый проект
3. В Project Settings → Database скопируйте **Connection string** (URI)
4. Вставьте его в `.env`:

```env
SUPABASE_DATABASE_URL=postgresql://postgres:[PASSWORD]@db.[PROJECT-REF].supabase.co:5432/postgres
```

### 2. Установка зависимостей

```bash
# Клонировать репозиторий
git clone https://github.com/your-org/assistant-job.git
cd assistant-job

# Установить зависимости
npm install
```

### 3. Применить миграции

```bash
# Сгенерировать и применить миграции к Supabase
npm run db:generate
npm run db:migrate
```

Или для разработки:
```bash
# Прямая синхронизация (внимание: не использовать в production)
npm run db:push
```

### 4. Запуск

```bash
npm run dev
```

Откройте http://localhost:3000

## Production деплой

```bash
npm run build
npm start
```

## Docker Compose (self-hosted)

```yaml
version: '3.8'

services:
  app:
    build: .
    ports: ["3000:3000"]
    env_file: .env
    depends_on: [redis]

  worker:
    build: ./worker
    env_file: .env
    depends_on: [redis]
    deploy:
      replicas: 3

  redis:
    image: redis:7-alpine
    volumes: ["redis_data:/data"]

  nginx:
    image: nginx:alpine
    ports: ["80:80", "443:443"]
    volumes: ["./nginx.conf:/etc/nginx/nginx.conf"]

volumes:
  redis_data:
```

## Требования к серверу (1000 пользователей/день)

| Компонент | Спецификация | Стоимость |
|-----------|-------------|-----------|
| **Supabase** | Бесплатный тариф (до 500MB) / Pro ($25/мес) | $0-25/мес |
| **VPS (API + Frontend)** | 2 vCPU, 4GB RAM | $15-25/мес |
| **VPS (Workers x3)** | 4 vCPU, 8GB RAM x3 | $60-90/мес |
| **Redis** | Self-hosted или Upstash (бесплатно) | $0-10/мес |
| **ИТОГО** | | **~$75-150/мес** |

## Supabase — подготовка БД

В SQL Editor выполните:

```sql
-- Роли и enum типы создаются автоматически через Drizzle
-- Просто запустите npm run db:push после настройки .env
```

## Переменные окружения

| Переменная | Описание | Пример |
|-----------|---------|--------|
| `SUPABASE_DATABASE_URL` | Connection string из Supabase | `postgresql://postgres:...` |
| `APP_ID` | OAuth App ID | из Kimi Console |
| `APP_SECRET` | OAuth App Secret | из Kimi Console |
| `KIMI_AUTH_URL` | OAuth endpoint | `https://account.kimi.ai/api/oauth` |
| `OWNER_UNION_ID` | ID владельца (admin) | опционально |

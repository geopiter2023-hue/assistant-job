#!/bin/bash
# Скрипт создания релиз-архива Assistant Job
# Использование: bash scripts/release.sh [версия]

VERSION=${1:-$(node -p "require('./package.json').version")}
NAME="assistant-job-v${VERSION}"

echo "========================================"
echo "  Assistant Job — Релиз v${VERSION}"
echo "========================================"

# 1. Сборка
echo ""
echo "[1/4] Сборка проекта..."
npm run build 2>&1
if [ $? -ne 0 ]; then
    echo "ОШИБКА: Сборка не удалась"
    exit 1
fi
echo "✓ Сборка завершена"

# 2. Проверка TypeScript
echo ""
echo "[2/4] Проверка TypeScript..."
npm run check 2>&1
if [ $? -ne 0 ]; then
    echo "✗ ОШИБКА: TypeScript проверка не пройдена"
    exit 1
fi
echo "✓ TypeScript проверка пройдена"

# 3. Создание архива
echo ""
echo "[3/4] Создание архива ${NAME}.zip..."

# Временная папка
mkdir -p "releases/${NAME}"

# Копируем нужные файлы
cp -r dist "releases/${NAME}/"
cp package.json "releases/${NAME}/"
cp drizzle.config.ts "releases/${NAME}/"
cp .env.example "releases/${NAME}/.env"
cp -r db "releases/${NAME}/"
cp VERSIONS.md "releases/${NAME}/" 2>/dev/null
cp RELEASE.md "releases/${NAME}/" 2>/dev/null
# Создаём install-скрипт
cat > "releases/${NAME}/install.sh" << 'INSTALL_EOF'
#!/bin/bash
echo "========================================"
echo "  Assistant Job — Установка"
echo "========================================"
echo ""

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "ОШИБКА: Node.js не установлен"
    echo "Установите Node.js 20+: curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo "ОШИБКА: Требуется Node.js 20+. У вас: $(node -v)"
    exit 1
fi

echo "[1/4] Установка зависимостей..."
npm install --production 2>&1

echo ""
echo "[2/4] Настройка окружения..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✓ Создан .env — НАСТРОЙТЕ ЕГО перед запуском!"
else
    echo "✓ .env уже существует"
fi

echo ""
echo "[3/4] Проверка API..."
curl -s http://localhost:3000/api/version 2>/dev/null && echo "✓ API работает" || echo "⚠ API ещё не запущен"

echo ""
echo "[4/4] Запуск..."
npm start

echo ""
echo "========================================"
echo "  Готово! Сайт: http://localhost:3000"
echo "========================================"
INSTALL_EOF
chmod +x "releases/${NAME}/install.sh"

# Архивируем
cd releases
zip -r "${NAME}.zip" "${NAME}/" -x "*.DS_Store" 2>&1
cd ..

# Копируем в корень
cp "releases/${NAME}.zip" "./${NAME}.zip"

echo "✓ Архив создан: ${NAME}.zip"

# 4. Информация
echo ""
echo "[4/4] Информация о релизе:"
echo ""
echo "  Размер: $(du -h "${NAME}.zip" | cut -f1)"
echo "  Файл:   ${NAME}.zip"
echo "  MD5:    $(md5sum "${NAME}.zip" | cut -d' ' -f1)"
echo ""
echo "========================================"
echo "  Релиз v${VERSION} готов!"
echo "========================================"
echo ""
echo "Для загрузки на сервер:"
echo "  scp ${NAME}.zip root@ВАШ_IP:/opt/"
echo ""
echo "Для установки на сервере:"
echo "  ssh root@ВАШ_IP"
echo "  cd /opt && unzip -o ${NAME}.zip && cd ${NAME}"
echo "  bash install.sh"
echo ""

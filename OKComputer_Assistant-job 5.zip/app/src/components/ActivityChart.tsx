import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface ActivityData {
  day: string;
  count: number;
}

interface ActivityChartProps {
  data: ActivityData[];
}

interface TooltipPayloadItem {
  value: number;
  dataKey: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="bg-hf-highlight border border-hf-border-subtle rounded-md px-3 py-2 shadow-lg">
      <p className="text-xs text-hf-text-secondary">{label}</p>
      <p className="text-sm font-medium text-hf-text-primary">
        {payload[0].value} откликов
      </p>
    </div>
  );
}

export default function ActivityChart({ data }: ActivityChartProps) {
  return (
    <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-6 shadow-card">
      <h2 className="text-lg font-bold text-hf-text-primary mb-6">
        📈 Активность за неделю
      </h2>
      <div className="h-[280px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 5, right: 10, left: -10, bottom: 0 }}
          >
            <defs>
              <linearGradient id="activityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#D6001C" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#D6001C" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="4 4"
              stroke="#E5E7EB"
              strokeOpacity={0.5}
              vertical={false}
            />
            <XAxis
              dataKey="day"
              tick={{ fill: "#64748B", fontSize: 12 }}
              axisLine={{ stroke: "#E5E7EB" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: "#64748B", fontSize: 12 }}
              axisLine={{ stroke: "#E5E7EB" }}
              tickLine={false}
              domain={[0, 20]}
              ticks={[0, 5, 10, 15, 20]}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="count"
              stroke="#D6001C"
              strokeWidth={2}
              fill="url(#activityGradient)"
              dot={{
                r: 4,
                fill: "#D6001C",
                stroke: "#FFFFFF",
                strokeWidth: 2,
              }}
              activeDot={{
                r: 6,
                fill: "#D6001C",
                stroke: "#FFFFFF",
                strokeWidth: 2,
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

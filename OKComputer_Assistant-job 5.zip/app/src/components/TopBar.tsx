import { Play, Square, Menu } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import type { BotStatus } from "@/lib/data";

interface TopBarProps {
  title: string;
  botStatus: BotStatus;
  onStatusChange?: (status: BotStatus) => void;
  onMenuClick: () => void;
}

export default function TopBar({ title, botStatus, onStatusChange, onMenuClick }: TopBarProps) {
  const [loading, setLoading] = useState(false);

  const handleStart = () => {
    setLoading(true);
    setTimeout(() => {
      onStatusChange?.("running");
      setLoading(false);
    }, 500);
  };

  const handleStop = () => {
    setLoading(true);
    setTimeout(() => {
      onStatusChange?.("idle");
      setLoading(false);
    }, 500);
  };

  return (
    <header className="sticky top-0 z-40 h-16 flex items-center justify-between px-4 lg:px-6 bg-white border-b border-hf-border-subtle shadow-sm">
      <div className="flex items-center gap-3">
        {/* Mobile menu button */}
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 -ml-2 rounded-md text-hf-text-secondary hover:text-hf-text-primary hover:bg-hf-highlight transition-colors"
        >
          <Menu size={20} />
        </button>
        <h1 className="text-lg lg:text-xl font-bold text-hf-text-primary truncate">
          {title}
        </h1>
      </div>
      <div className="flex items-center gap-2 lg:gap-3">
        <button
          onClick={handleStart}
          disabled={botStatus === "running" || loading}
          className={cn(
            "flex items-center gap-1.5 lg:gap-2 px-3 lg:px-4 py-2 rounded-md text-sm font-medium text-white bg-hf-red transition-all duration-150",
            "hover:brightness-110 hover:scale-[1.02]",
            "disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          )}
        >
          <Play size={14} fill="currentColor" />
          <span className="hidden sm:inline">Запустить</span>
        </button>
        <button
          onClick={handleStop}
          disabled={botStatus !== "running" || loading}
          className={cn(
            "flex items-center gap-1.5 lg:gap-2 px-3 lg:px-4 py-2 rounded-md text-sm font-medium text-hf-red transition-all duration-150",
            "bg-hf-red/10 hover:bg-hf-red/20 hover:scale-[1.02]",
            "disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          )}
        >
          <Square size={14} />
          <span className="hidden sm:inline">Остановить</span>
        </button>
      </div>
    </header>
  );
}

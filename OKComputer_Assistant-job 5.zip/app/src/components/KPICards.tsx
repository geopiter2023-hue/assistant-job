import { cn } from "@/lib/utils";
import type { BotStatus } from "@/lib/data";

interface KPICardsProps {
  totalApplies: number;
  totalDelta: string;
  successfulApplies: number;
  conversionRate: string;
  todayApplies: number;
  todayPending: string;
  botStatus: BotStatus;
  botLabel: string;
  sessionId: string;
}

export default function KPICards({
  totalApplies,
  totalDelta,
  successfulApplies,
  conversionRate,
  todayApplies,
  todayPending,
  botStatus,
  botLabel,
  sessionId,
}: KPICardsProps) {
  const statusDotColor =
    botStatus === "running"
      ? "bg-hf-green"
      : botStatus === "error"
      ? "bg-hf-red"
      : botStatus === "paused"
      ? "bg-hf-amber"
      : "bg-hf-text-muted";

  const statusTextColor =
    botStatus === "running"
      ? "text-hf-green"
      : botStatus === "error"
      ? "text-hf-red"
      : botStatus === "paused"
      ? "text-hf-amber"
      : "text-hf-text-muted";

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {/* Card 1: Total Applies */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card hover:shadow-card-hover hover:border-[#D6001C40] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">
          ВСЕГО ОТКЛИКОВ
        </p>
        <p className="text-4xl font-bold text-hf-red mt-1">{totalApplies}</p>
        <p className="text-xs text-hf-text-secondary mt-1">{totalDelta}</p>
      </div>

      {/* Card 2: Successful */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card hover:shadow-card-hover hover:border-[#D6001C40] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">
          УСПЕШНЫХ
        </p>
        <p className="text-4xl font-bold text-hf-green mt-1">{successfulApplies}</p>
        <p className="text-xs text-hf-text-secondary mt-1">{conversionRate}</p>
      </div>

      {/* Card 3: Today */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card hover:shadow-card-hover hover:border-[#D6001C40] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">
          СЕГОДНЯ
        </p>
        <p className="text-4xl font-bold text-hf-cyan mt-1">{todayApplies}</p>
        <p className="text-xs text-hf-text-secondary mt-1">{todayPending}</p>
      </div>

      {/* Card 4: Bot Status */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card hover:shadow-card-hover hover:border-[#D6001C40] transition-all duration-200">
        <p className="text-xs uppercase tracking-[0.05em] text-hf-text-secondary font-medium">
          СТАТУС БОТА
        </p>
        <div className="flex items-center gap-2 mt-2">
          {botStatus === "running" ? (
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-pulse-dot absolute inline-flex h-full w-full rounded-full bg-hf-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-hf-green" />
            </span>
          ) : (
            <span className={cn("h-2.5 w-2.5 rounded-full", statusDotColor)} />
          )}
          <span className={cn("text-sm font-medium", statusTextColor)}>
            {botLabel}
          </span>
        </div>
        <p className="text-xs text-hf-text-muted mt-1">Сессия {sessionId}</p>
      </div>
    </div>
  );
}

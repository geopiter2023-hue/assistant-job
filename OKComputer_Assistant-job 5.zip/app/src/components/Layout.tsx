import { useState, useCallback } from "react";
import { useLocation } from "react-router";
import Sidebar from "./Sidebar";
import TopBar from "./TopBar";
import type { BotStatus } from "@/lib/data";

/*
 * ==========================================
 * УПРОЩЁННЫЕ ЗАГОЛОВКИ
 * ==========================================
 */

const pageTitles: Record<string, string> = {
  "/": "Поиск вакансий",
  "/vacancies": "Вакансии",
  "/ai-pipeline": "AI Отклики",
  "/applies": "Мои отклики",
  "/tasks": "Задачи",
  "/resumes": "Резюме",
  "/settings": "Настройки",
  "/subscription": "Подписка",
  "/profile": "Профиль",
};

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [botStatus, setBotStatus] = useState<BotStatus>("running");
  const location = useLocation();

  const title = pageTitles[location.pathname] || "Assistant Job";

  const handleMenuClick = useCallback(() => {
    setMobileMenuOpen(true);
  }, []);

  const handleMobileClose = useCallback(() => {
    setMobileMenuOpen(false);
  }, []);

  return (
    <div className="min-h-screen bg-hf-highlight">
      <Sidebar mobileOpen={mobileMenuOpen} onMobileClose={handleMobileClose} />

      {/* Main content area — desktop sidebar now 220px */}
      <div className="lg:ml-[220px] min-h-screen flex flex-col">
        <TopBar
          title={title}
          botStatus={botStatus}
          onStatusChange={setBotStatus}
          onMenuClick={handleMenuClick}
        />

        <main className="flex-1 p-4 sm:p-5 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

export type BotStatus = "running" | "idle" | "paused" | "error";

// Все 10 российских площадок
export type JobPlatform =
  | "hh"
  | "zarplata"
  | "rabota"
  | "superjob"
  | "yandex_smena"
  | "karierist"
  | "rabotaru"
  | "avito"
  | "trudvsem"
  | "gorodrabot";

export const platformConfig: Record<
  JobPlatform,
  { label: string; domain: string; color: string; bg: string }
> = {
  hh: { label: "HH.ru", domain: "hh.ru", color: "text-hf-red", bg: "bg-[#D6001C15]" },
  zarplata: { label: "Зарплата.ру", domain: "zarplata.ru", color: "text-[#2E7D32]", bg: "bg-[#2E7D3215]" },
  rabota: { label: "Работа.ру", domain: "rabota.ru", color: "text-[#E65100]", bg: "bg-[#E6510015]" },
  superjob: { label: "SuperJob", domain: "superjob.ru", color: "text-[#C62828]", bg: "bg-[#C6282815]" },
  yandex_smena: { label: "Яндекс Смена", domain: "yandex.smena", color: "text-[#5E35B1]", bg: "bg-[#5E35B115]" },
  karierist: { label: "Карьерист.ру", domain: "karierist.ru", color: "text-[#00838F]", bg: "bg-[#00838F15]" },
  rabotaru: { label: "Работа.ру", domain: "rabota.ru", color: "text-[#AD1457]", bg: "bg-[#AD145715]" },
  avito: { label: "Avito", domain: "avito.ru", color: "text-[#2E7D32]", bg: "bg-[#2E7D3215]" },
  trudvsem: { label: "Trudvsem.ru", domain: "trudvsem.ru", color: "text-[#F9A825]", bg: "bg-[#F9A82515]" },
  gorodrabot: { label: "ГородРабот.ру", domain: "gorodrabot.ru", color: "text-[#3949AB]", bg: "bg-[#3949AB15]" },
};

export const kpiStats = {
  totalApplies: 247,
  totalDelta: "+12 за сегодня",
  successfulApplies: 198,
  conversionRate: "80.2% конверсия",
  todayApplies: 12,
  todayPending: "3 в ожидании",
  botStatus: "running" as BotStatus,
  botLabel: "Работает",
  sessionId: "#42",
};

export const weeklyActivity = [
  { day: "Пн", count: 4 },
  { day: "Вт", count: 8 },
  { day: "Ср", count: 10 },
  { day: "Чт", count: 13 },
  { day: "Пт", count: 9 },
  { day: "Сб", count: 5 },
  { day: "Вс", count: 16 },
];

export interface Application {
  id: string;
  status: "success" | "error";
  statusLabel: string;
  vacancy: string;
  vacancyUrl: string;
  company: string;
  platform: JobPlatform;
  timeAgo: string;
  salary?: string;
  location?: string;
  coverLetter?: string;
}

export const recentApplications: Application[] = [
  { id: "1", status: "success", statusLabel: "Успешно", vacancy: "Senior Python Developer", vacancyUrl: "#", company: "Яндекс", platform: "hh", timeAgo: "2 мин назад", salary: "350 000 - 500 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "2", status: "success", statusLabel: "Успешно", vacancy: "Backend Engineer (Python)", vacancyUrl: "#", company: "Тинькофф", platform: "zarplata", timeAgo: "5 мин назад", salary: "300 000 - 450 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "3", status: "error", statusLabel: "Ошибка", vacancy: "Python разработчик", vacancyUrl: "#", company: "СберТех", platform: "superjob", timeAgo: "8 мин назад", salary: "200 000 - 350 000 ₽", location: "Санкт-Петербург", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "4", status: "success", statusLabel: "Успешно", vacancy: "Fullstack Python/React", vacancyUrl: "#", company: "Авито", platform: "avito", timeAgo: "12 мин назад", salary: "280 000 - 400 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "5", status: "success", statusLabel: "Успешно", vacancy: "Middle Python Developer", vacancyUrl: "#", company: "Ozon", platform: "rabota", timeAgo: "15 мин назад", salary: "180 000 - 280 000 ₽", location: "Удаленно", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "6", status: "success", statusLabel: "Успешно", vacancy: "Python Tech Lead", vacancyUrl: "#", company: "VK", platform: "hh", timeAgo: "22 мин назад", salary: "500 000 - 700 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "7", status: "error", statusLabel: "Ошибка", vacancy: "Data Engineer (Python)", vacancyUrl: "#", company: "МТС", platform: "yandex_smena", timeAgo: "35 мин назад", salary: "250 000 - 380 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "8", status: "success", statusLabel: "Успешно", vacancy: "Python разработчик", vacancyUrl: "#", company: "Kaspersky", platform: "karierist", timeAgo: "45 мин назад", salary: "220 000 - 350 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "9", status: "success", statusLabel: "Успешно", vacancy: "Senior Backend Developer", vacancyUrl: "#", company: "Самокат", platform: "trudvsem", timeAgo: "1 ч назад", salary: "350 000 - 500 000 ₽", location: "Санкт-Петербург", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
  { id: "10", status: "success", statusLabel: "Успешно", vacancy: "Python Developer", vacancyUrl: "#", company: "HeadHunter", platform: "gorodrabot", timeAgo: "2 ч назад", salary: "200 000 - 300 000 ₽", location: "Москва", coverLetter: "Здравствуйте! Меня заинтересовала вакансия..." },
];

export interface Vacancy {
  id: string;
  title: string;
  company: string;
  platform: JobPlatform;
  salary: string;
  location: string;
  experience: string;
  skills: string[];
  url: string;
  publishedAt: string;
  applied: boolean;
}

export const vacanciesData: Vacancy[] = [
  { id: "v1", title: "Senior Python Developer", company: "Яндекс", platform: "hh", salary: "350 000 - 500 000 ₽", location: "Москва", experience: "3-6 лет", skills: ["Python", "Django", "Docker", "PostgreSQL"], url: "#", publishedAt: "2 часа назад", applied: true },
  { id: "v2", title: "Backend Engineer (Python)", company: "Тинькофф", platform: "zarplata", salary: "300 000 - 450 000 ₽", location: "Москва", experience: "1-3 года", skills: ["Python", "FastAPI", "Kafka", "Redis"], url: "#", publishedAt: "3 часа назад", applied: true },
  { id: "v3", title: "Python разработчик", company: "СберТех", platform: "superjob", salary: "200 000 - 350 000 ₽", location: "Санкт-Петербург", experience: "1-3 года", skills: ["Python", "Flask", "SQLAlchemy"], url: "#", publishedAt: "4 часа назад", applied: true },
  { id: "v4", title: "Fullstack Python/React", company: "Авито", platform: "avito", salary: "280 000 - 400 000 ₽", location: "Москва", experience: "3-6 лет", skills: ["Python", "React", "TypeScript", "Django"], url: "#", publishedAt: "5 часов назад", applied: true },
  { id: "v5", title: "Middle Python Developer", company: "Ozon", platform: "rabota", salary: "180 000 - 280 000 ₽", location: "Удаленно", experience: "1-3 года", skills: ["Python", "FastAPI", "Kubernetes"], url: "#", publishedAt: "6 часов назад", applied: true },
  { id: "v6", title: "Python Tech Lead", company: "VK", platform: "hh", salary: "500 000 - 700 000 ₽", location: "Москва", experience: "более 6 лет", skills: ["Python", "System Design", "Team Leadership"], url: "#", publishedAt: "8 часов назад", applied: true },
  { id: "v7", title: "Data Engineer (Python)", company: "МТС", platform: "yandex_smena", salary: "250 000 - 380 000 ₽", location: "Москва", experience: "1-3 года", skills: ["Python", "Spark", "Airflow"], url: "#", publishedAt: "10 часов назад", applied: true },
  { id: "v8", title: "Python разработчик", company: "Kaspersky", platform: "karierist", salary: "220 000 - 350 000 ₽", location: "Москва", experience: "3-6 лет", skills: ["Python", "Django", "Security"], url: "#", publishedAt: "12 часов назад", applied: true },
  { id: "v9", title: "ML Engineer (Python)", company: "Яндекс", platform: "trudvsem", salary: "400 000 - 600 000 ₽", location: "Москва", experience: "3-6 лет", skills: ["Python", "PyTorch", "ML"], url: "#", publishedAt: "1 день назад", applied: false },
  { id: "v10", title: "DevOps Python Developer", company: "Т-Банк", platform: "gorodrabot", salary: "350 000 - 500 000 ₽", location: "Удаленно", experience: "3-6 лет", skills: ["Python", "Terraform", "AWS"], url: "#", publishedAt: "1 день назад", applied: false },
];

export interface BotTask {
  id: string;
  name: string;
  status: "running" | "completed" | "failed" | "scheduled";
  platform: JobPlatform | "all";
  query: string;
  resultsFound: number;
  appliesSent: number;
  createdAt: string;
  completedAt?: string;
  emulationMode: boolean;
}

export interface Schedule {
  id: number;
  name: string;
  isActive: boolean;
  cronExpression: string;
  intervalMinutes: number;
  platforms: string[];
  keywords: string;
  resumeId: number | null;
  filters: {
    salaryFrom?: number;
    salaryTo?: number;
    experience?: string;
    remoteOnly?: boolean;
    region?: string;
  };
  useAiPipeline: boolean;
  autoApply: boolean;
  maxAppliesPerRun: number;
  lastRunAt: string | null;
  nextRunAt: string | null;
  totalRuns: number;
  totalApplies: number;
  createdAt: string;
  updatedAt: string;
}

export const tasksData: BotTask[] = [
  { id: "t1", name: "Сессия #42", status: "running", platform: "all", query: "Python разработчик", resultsFound: 156, appliesSent: 12, createdAt: "Сегодня, 09:15", emulationMode: true },
  { id: "t2", name: "Сессия #41", status: "completed", platform: "hh", query: "Python разработчик", resultsFound: 89, appliesSent: 15, createdAt: "Вчера, 14:30", completedAt: "Вчера, 15:45", emulationMode: true },
  { id: "t3", name: "Сессия #40", status: "completed", platform: "superjob", query: "Python разработчик", resultsFound: 34, appliesSent: 8, createdAt: "Вчера, 10:00", completedAt: "Вчера, 10:30", emulationMode: true },
  { id: "t4", name: "Сессия #39", status: "failed", platform: "all", query: "Python разработчик", resultsFound: 0, appliesSent: 0, createdAt: "2 дня назад, 16:20", completedAt: "2 дня назад, 16:25", emulationMode: true },
  { id: "t5", name: "Сессия #38", status: "completed", platform: "avito", query: "Backend Python", resultsFound: 67, appliesSent: 12, createdAt: "3 дня назад, 09:00", completedAt: "3 дня назад, 10:15", emulationMode: true },
  { id: "t6", name: "Сессия #37", status: "scheduled", platform: "all", query: "Python разработчик", resultsFound: 0, appliesSent: 0, createdAt: "Завтра, 09:00", emulationMode: true },
];

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  period: string;
  description: string;
  features: string[];
  popular?: boolean;
  current?: boolean;
}

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: "free",
    name: "Стартовый",
    price: 0,
    period: "навсегда",
    description: "Для знакомства с системой",
    features: [
      "До 5 откликов в день",
      "1 площадка",
      "1 шаблон сопроводительного",
      "Базовая статистика",
    ],
  },
  {
    id: "pro",
    name: "Профессиональный",
    price: 990,
    period: "/ месяц",
    description: "Для активного поиска работы",
    features: [
      "До 50 откликов в день",
      "Все 10 площадок",
      "5 шаблонов сопроводительных",
      "Полная статистика и аналитика",
      "Автопоиск каждые 2 часа",
      "Чёрный список компаний",
      "Приоритетная поддержка",
    ],
    popular: true,
  },
  {
    id: "enterprise",
    name: "Бизнес",
    price: 2990,
    period: "/ месяц",
    description: "Для HR-отделов и агентств",
    features: [
      "Безлимитные отклики",
      "Все площадки + новые",
      "Безлимитные шаблоны",
      "Расширенная аналитика",
      "Автопоиск каждые 30 минут",
      "API доступ",
      "Telegram-уведомления",
      "Персональный менеджер",
    ],
    current: true,
  },
];

export const statusLabelMap: Record<BotStatus, string> = {
  running: "Работает",
  idle: "Ожидание",
  paused: "Пауза",
  error: "Ошибка",
};

export interface EmulationSettings {
  enabled: boolean;
  browserType: "chromium" | "firefox" | "webkit";
  headless: boolean;
  useProxy: boolean;
  proxyHost: string;
  proxyPort: string;
  proxyUsername: string;
  proxyPassword: string;
  randomDelayMin: number;
  randomDelayMax: number;
  typingSpeedMin: number;
  typingSpeedMax: number;
  randomScroll: boolean;
  randomMouseMove: boolean;
  simulateReading: boolean;
  readingTimeMin: number;
  readingTimeMax: number;
  rotateUserAgent: boolean;
  userAgents: string;
  useStealth: boolean;
  handleCaptcha: boolean;
  captchaApiKey: string;
  maxRetries: number;
  retryDelay: number;
  sessionDurationLimit: number;
  randomizeOrder: boolean;
  addRandomPause: boolean;
  pauseProbability: number;
}

export const defaultEmulationSettings: EmulationSettings = {
  enabled: true,
  browserType: "chromium",
  headless: true,
  useProxy: false,
  proxyHost: "",
  proxyPort: "",
  proxyUsername: "",
  proxyPassword: "",
  randomDelayMin: 5000,
  randomDelayMax: 15000,
  typingSpeedMin: 50,
  typingSpeedMax: 200,
  randomScroll: true,
  randomMouseMove: true,
  simulateReading: true,
  readingTimeMin: 3000,
  readingTimeMax: 8000,
  rotateUserAgent: true,
  userAgents:
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\nMozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36\nMozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
  useStealth: true,
  handleCaptcha: true,
  captchaApiKey: "",
  maxRetries: 3,
  retryDelay: 30,
  sessionDurationLimit: 60,
  randomizeOrder: true,
  addRandomPause: true,
  pauseProbability: 15,
};

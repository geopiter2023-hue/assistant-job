import { Routes, Route, Navigate } from "react-router";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Vacancies from "./pages/Vacancies";
import Applies from "./pages/Applies";
import Tasks from "./pages/Tasks";
import Settings from "./pages/Settings";
import Subscription from "./pages/Subscription";
import Resumes from "./pages/Resumes";
import AiPipeline from "./pages/AiPipeline";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Onboarding from "./pages/Onboarding";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import { trpc } from "./providers/trpc";

function OnboardingGuard({ children }: { children: React.ReactNode }) {
  const done = localStorage.getItem("aj_onboarding_done") === "1";
  if (!done) return <Navigate to="/onboarding" replace />;
  return <>{children}</>;
}

function AdminGuard({ children }: { children: React.ReactNode }) {
  const token = localStorage.getItem("aj_admin_token");
  const { data, isLoading } = trpc.admin.verify.useQuery(
    { token: token || "" },
    { enabled: !!token }
  );
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F3F4F6] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#D6001C] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!data?.valid) {
    return <Navigate to="/ushakov" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      {/* Админ-панель — отдельный layout без sidebar */}
      <Route path="/ushakov" element={<AdminLogin />} />
      <Route path="/ushakov/dashboard" element={<AdminGuard><AdminDashboard /></AdminGuard>} />
      <Route path="/ushakov/*" element={<AdminLogin />} />

      {/* Основное приложение с Layout */}
      <Route path="/*" element={
        <Layout>
          <Routes>
            {/* Onboarding — опционально, доступно по ссылке */}
            <Route path="/onboarding" element={<Onboarding />} />
            {/* Основные страницы — доступны сразу */}
            <Route path="/" element={<Dashboard />} />
            <Route path="/applies" element={<Applies />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/profile" element={<Profile />} />
            {/* Остальные роуты */}
            <Route path="/vacancies" element={<Vacancies />} />
            <Route path="/ai-pipeline" element={<AiPipeline />} />
            <Route path="/tasks" element={<Tasks />} />
            <Route path="/resumes" element={<Resumes />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      } />
    </Routes>
  );
}

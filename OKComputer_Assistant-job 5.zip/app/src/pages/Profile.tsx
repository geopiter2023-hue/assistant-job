import { useState } from "react";
import { User, Crown, Zap, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router";

export default function Profile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKey, setApiKey] = useState("");

  // Demo subscription data
  const plan = {
    name: "Профи",
    price: "999 ₽/мес",
    features: ["До 50 откликов/день", "5 резюме", "Все площадки", "AI-пайплайн"],
    nextBilling: "15 февраля 2025",
  };

  return (
    <div className="max-w-lg mx-auto space-y-4">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 rounded-full bg-hf-red/10 flex items-center justify-center mx-auto mb-3">
          <User size={32} className="text-hf-red" />
        </div>
        <h2 className="text-xl font-bold text-hf-text-primary">
          {user?.name || "Соискатель"}
        </h2>
        <p className="text-sm text-hf-text-secondary">{user?.email || "email@example.com"}</p>
      </div>

      {/* AI API Key — самое важное */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <Zap size={16} className="text-hf-amber" />
          <h3 className="text-sm font-semibold text-hf-text-primary">Ключ AI (OpenAI)</h3>
        </div>
        <p className="text-xs text-hf-text-secondary mb-3">
          Для автоматических откликов нужен ключ API от OpenAI или DeepSeek.
          Получить: platform.openai.com/api-keys
        </p>
        <div className="flex gap-2">
          <input
            type={showApiKey ? "text" : "password"}
            placeholder="sk-..."
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="flex-1 bg-hf-highlight border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red"
          />
          <button
            onClick={() => setShowApiKey(!showApiKey)}
            className="px-3 py-2 text-xs text-hf-text-secondary hover:text-hf-text-primary border border-hf-border-subtle rounded-lg"
          >
            {showApiKey ? "Скрыть" : "Показать"}
          </button>
        </div>
        <button
          onClick={() => alert("Ключ сохранён (демо)")}
          className="w-full mt-2 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all"
        >
          Сохранить ключ
        </button>
      </div>

      {/* Subscription */}
      <div className="bg-white border border-hf-amber/30 rounded-[10px] p-5 shadow-card">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Crown size={16} className="text-hf-amber" />
            <h3 className="text-sm font-semibold text-hf-text-primary">Тариф: {plan.name}</h3>
          </div>
          <span className="text-sm font-bold text-hf-amber">{plan.price}</span>
        </div>
        <ul className="space-y-1.5 mb-3">
          {plan.features.map((f, i) => (
            <li key={i} className="flex items-center gap-2 text-xs text-hf-text-secondary">
              <Zap size={10} className="text-hf-green" />{f}
            </li>
          ))}
        </ul>
        <p className="text-xs text-hf-text-muted">Следующее списание: {plan.nextBilling}</p>
        <button
          onClick={() => navigate("/subscription")}
          className="flex items-center gap-1 mt-3 text-xs text-hf-red hover:underline"
        >
          Сменить тариф <ArrowRight size={12} />
        </button>
      </div>
    </div>
  );
}

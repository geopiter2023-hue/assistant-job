import { useState } from "react";
import {
  Users, FileText, Ticket, Key, LogOut, Shield, BarChart3,
  ChevronDown, ChevronUp, Search, CheckCircle, XCircle, Clock,
  Loader, AlertCircle, Copy, Plus, Trash2, Eye, EyeOff,
  MessageSquare, Activity, TrendingUp, RefreshCw, Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";

type Tab = "overview" | "users" | "tickets" | "apikeys" | "settings";

function StatCard({ icon: Icon, label, value, color, sub }: {
  icon: any; label: string; value: number | string; color: string; sub?: string;
}) {
  return (
    <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
      <div className="flex items-start justify-between">
        <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", color)}>
          <Icon size={20} className="text-white" />
        </div>
        {sub && <span className="text-[10px] text-gray-400">{sub}</span>}
      </div>
      <p className="text-2xl font-bold text-gray-800 mt-3">{value}</p>
      <p className="text-xs text-gray-500 mt-0.5">{label}</p>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-5 py-3 border-b border-gray-100">
        <h3 className="text-sm font-semibold text-gray-700">{title}</h3>
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>("overview");
  const [searchUser, setSearchUser] = useState("");
  const [ticketStatus, setTicketStatus] = useState<string | undefined>(undefined);
  const [showCreateKey, setShowCreateKey] = useState(false);
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyType, setNewKeyType] = useState("openai");
  const [keyCreated, setKeyCreated] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const token = localStorage.getItem("aj_admin_token") || "";

  // Queries
  const { data: stats, isLoading: statsLoading } = trpc.admin.stats.useQuery({ token });
  const { data: usersData } = trpc.admin.usersList.useQuery({ token, limit: 50, offset: 0 });
  const { data: ticketsData } = trpc.admin.ticketsList.useQuery({ token, status: ticketStatus });
  const { data: keysData } = trpc.admin.apiKeysList.useQuery({ token });

  // Mutations
  const logoutMutation = trpc.admin.logout.useMutation({
    onSuccess: () => {
      localStorage.removeItem("aj_admin_token");
      window.location.reload();
    },
  });

  const ticketUpdate = trpc.admin.ticketUpdate.useMutation({
    onSuccess: () => {
      window.location.reload();
    },
  });

  const createKey = trpc.admin.apiKeyCreate.useMutation({
    onSuccess: (data) => {
      if (data.success && data.key) {
        setKeyCreated(data.key);
        setShowCreateKey(false);
        setNewKeyName("");
      }
    },
  });

  const toggleKey = trpc.admin.apiKeyToggle.useMutation({
    onSuccess: () => window.location.reload(),
  });

  const handleLogout = () => logoutMutation.mutate({ token });

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tabs: { key: Tab; label: string; icon: any }[] = [
    { key: "overview", label: "Обзор", icon: BarChart3 },
    { key: "users", label: "Пользователи", icon: Users },
    { key: "tickets", label: "Поддержка", icon: Ticket },
    { key: "apikeys", label: "API Ключи", icon: Key },
    { key: "settings", label: "Настройки", icon: Settings },
  ];

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-[#F3F4F6] flex items-center justify-center">
        <div className="text-center">
          <Loader size={32} className="animate-spin text-[#D6001C] mx-auto mb-2" />
          <p className="text-sm text-gray-500">Загрузка...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F3F4F6]">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-[#D6001C] rounded-lg flex items-center justify-center">
                <Shield size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-gray-800">Assistant Job</h1>
                <p className="text-[10px] text-gray-400">Админ-панель /ushakov</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-red-500 transition-colors px-3 py-1.5 rounded-lg hover:bg-red-50"
            >
              <LogOut size={14} /> Выйти
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {/* Tabs */}
        <div className="flex gap-1 mb-6 overflow-x-auto pb-1">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all whitespace-nowrap",
                tab === t.key
                  ? "bg-[#D6001C] text-white shadow-md shadow-red-200"
                  : "bg-white text-gray-600 hover:text-[#D6001C] border border-gray-200"
              )}
            >
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        {tab === "overview" && stats && !stats.error && (
          <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              <StatCard icon={Users} label="Пользователей" value={stats.usersTotal} color="bg-blue-500" />
              <StatCard icon={FileText} label="Всего откликов" value={stats.appliesTotal} color="bg-green-500" />
              <StatCard icon={CheckCircle} label="Успешных" value={stats.appliesSuccess} color="bg-emerald-500" />
              <StatCard icon={Ticket} label="Тикетов открыто" value={stats.ticketsOpen} color="bg-amber-500" />
              <StatCard icon={Users} label="Подписок активно" value={stats.subscriptionsActive} color="bg-purple-500" />
              <StatCard icon={Activity} label="Сессий бота" value={stats.sessionsTotal} color="bg-cyan-500" />
            </div>

            {/* Weekly activity chart */}
            <Section title="Активность за неделю (отклики)">
              <div className="flex items-end gap-2 h-40">
                {stats.weeklyActivity?.map((d: any, i: number) => {
                  const max = Math.max(...stats.weeklyActivity.map((x: any) => x.count), 1);
                  const pct = (d.count / max) * 100;
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <span className="text-[10px] text-gray-500">{d.count}</span>
                      <div
                        className="w-full bg-[#D6001C] rounded-t-md transition-all min-h-[4px]"
                        style={{ height: `${Math.max(pct, 4)}%` }}
                      />
                      <span className="text-[10px] text-gray-400">{d.day}</span>
                    </div>
                  );
                })}
              </div>
            </Section>

            {/* Recent applies */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Section title="Последние отклики">
                <div className="space-y-2">
                  {stats.recentApplies?.length === 0 && (
                    <p className="text-xs text-gray-400 text-center py-4">Нет откликов</p>
                  )}
                  {stats.recentApplies?.slice(0, 8).map((a: any) => (
                    <div key={a.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">{a.vacancy}</p>
                        <p className="text-[10px] text-gray-400">{a.company || "—"} · {a.platform}</p>
                      </div>
                      <span className={cn(
                        "text-[10px] px-2 py-0.5 rounded-full flex-shrink-0",
                        a.status === "success" ? "bg-green-100 text-green-600" :
                        a.status === "error" ? "bg-red-100 text-red-600" :
                        "bg-amber-100 text-amber-600"
                      )}>
                        {a.status}
                      </span>
                    </div>
                  ))}
                </div>
              </Section>

              <Section title="Новые пользователи">
                <div className="space-y-2">
                  {stats.recentUsers?.length === 0 && (
                    <p className="text-xs text-gray-400 text-center py-4">Нет пользователей</p>
                  )}
                  {stats.recentUsers?.slice(0, 8).map((u: any) => (
                    <div key={u.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">{u.name || "—"}</p>
                        <p className="text-[10px] text-gray-400">{u.email || "—"}</p>
                      </div>
                      <span className="text-[10px] text-gray-400 flex-shrink-0">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString("ru-RU") : "—"}
                      </span>
                    </div>
                  ))}
                </div>
              </Section>
            </div>
          </div>
        )}

        {/* USERS */}
        {tab === "users" && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="relative flex-1 max-w-xs">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Поиск пользователей..."
                  value={searchUser}
                  onChange={(e) => setSearchUser(e.target.value)}
                  className="w-full bg-white border border-gray-200 rounded-lg pl-9 pr-3 py-2 text-xs text-gray-700 placeholder:text-gray-400 focus:outline-none focus:border-[#D6001C]"
                />
              </div>
              <span className="text-xs text-gray-500">Всего: {usersData?.total || 0}</span>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">ID</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Имя</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Email</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Роль</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Дата</th>
                  </tr>
                </thead>
                <tbody>
                  {(usersData?.users || [])
                    .filter((u: any) =>
                      !searchUser ||
                      u.name?.toLowerCase().includes(searchUser.toLowerCase()) ||
                      u.email?.toLowerCase().includes(searchUser.toLowerCase())
                    )
                    .map((u: any) => (
                    <tr key={u.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50">
                      <td className="px-4 py-3 text-xs text-gray-500">#{u.id}</td>
                      <td className="px-4 py-3 text-xs font-medium text-gray-700">{u.name || "—"}</td>
                      <td className="px-4 py-3 text-xs text-gray-500">{u.email || "—"}</td>
                      <td className="px-4 py-3"><span className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full">{u.role}</span></td>
                      <td className="px-4 py-3 text-xs text-gray-400">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString("ru-RU") : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TICKETS */}
        {tab === "tickets" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              {(["all", "open", "in_progress", "resolved", "closed"] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setTicketStatus(s === "all" ? undefined : s)}
                  className={cn(
                    "px-3 py-1.5 rounded-lg text-[10px] font-medium transition-all",
                    (ticketStatus === s || (s === "all" && !ticketStatus))
                      ? "bg-[#D6001C] text-white"
                      : "bg-white text-gray-600 border border-gray-200 hover:text-[#D6001C]"
                  )}
                >
                  {s === "all" ? "Все" : s === "open" ? "Открыты" : s === "in_progress" ? "В работе" : s === "resolved" ? "Решены" : "Закрыты"}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {(ticketsData?.tickets || []).length === 0 && (
                <div className="bg-white rounded-xl p-8 text-center">
                  <Ticket size={32} className="text-gray-300 mx-auto mb-2" />
                  <p className="text-xs text-gray-400">Нет тикетов</p>
                </div>
              )}
              {(ticketsData?.tickets || []).map((t: any) => (
                <div key={t.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-semibold text-gray-800">{t.subject}</h4>
                        <span className={cn(
                          "text-[10px] px-2 py-0.5 rounded-full",
                          t.status === "open" ? "bg-amber-100 text-amber-600" :
                          t.status === "in_progress" ? "bg-blue-100 text-blue-600" :
                          t.status === "resolved" ? "bg-green-100 text-green-600" :
                          "bg-gray-100 text-gray-600"
                        )}>{t.status}</span>
                        <span className={cn(
                          "text-[10px] px-2 py-0.5 rounded-full",
                          t.priority === "urgent" ? "bg-red-100 text-red-600" :
                          t.priority === "high" ? "bg-orange-100 text-orange-600" :
                          t.priority === "medium" ? "bg-blue-100 text-blue-600" :
                          "bg-gray-100 text-gray-600"
                        )}>{t.priority}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{t.userName || "—"} · {t.userEmail || "—"}</p>
                      <p className="text-xs text-gray-600 mt-2 bg-gray-50 rounded-lg p-3">{t.message}</p>
                      {t.adminReply && (
                        <div className="mt-2 bg-green-50 rounded-lg p-3 border border-green-200">
                          <p className="text-[10px] text-green-600 font-medium mb-1">Ответ администратора:</p>
                          <p className="text-xs text-gray-600">{t.adminReply}</p>
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col gap-1 flex-shrink-0">
                      {t.status !== "resolved" && (
                        <button
                          onClick={() => ticketUpdate.mutate({ token, ticketId: t.id, status: "resolved", adminReply: "Решено" })}
                          className="text-[10px] px-2 py-1 bg-green-100 text-green-600 rounded hover:bg-green-200 transition-colors"
                        >
                          <CheckCircle size={10} className="inline mr-1" />Решить
                        </button>
                      )}
                      {t.status !== "in_progress" && t.status !== "resolved" && (
                        <button
                          onClick={() => ticketUpdate.mutate({ token, ticketId: t.id, status: "in_progress" })}
                          className="text-[10px] px-2 py-1 bg-blue-100 text-blue-600 rounded hover:bg-blue-200 transition-colors"
                        >
                          <Clock size={10} className="inline mr-1" />В работу
                        </button>
                      )}
                      {t.status !== "closed" && (
                        <button
                          onClick={() => ticketUpdate.mutate({ token, ticketId: t.id, status: "closed" })}
                          className="text-[10px] px-2 py-1 bg-gray-100 text-gray-600 rounded hover:bg-gray-200 transition-colors"
                        >
                          <XCircle size={10} className="inline mr-1" />Закрыть
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* API KEYS */}
        {tab === "apikeys" && (
          <div className="space-y-4">
            {/* Created key alert */}
            {keyCreated && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <p className="text-xs text-green-700 font-medium mb-2">Ключ создан! Скопируйте — он больше не будет показан:</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 bg-white rounded-lg px-3 py-2 text-xs text-gray-700 border border-green-200 font-mono break-all">{keyCreated}</code>
                  <button
                    onClick={() => handleCopyKey(keyCreated)}
                    className="px-3 py-2 bg-green-600 text-white rounded-lg text-xs hover:bg-green-700 transition-colors flex-shrink-0"
                  >
                    {copied ? "Скопировано!" : "Копировать"}
                  </button>
                </div>
              </div>
            )}

            {/* Create key form */}
            {!showCreateKey ? (
              <button
                onClick={() => setShowCreateKey(true)}
                className="flex items-center gap-2 px-4 py-2 bg-[#D6001C] text-white text-xs font-medium rounded-lg hover:brightness-110 transition-all"
              >
                <Plus size={14} /> Создать ключ
              </button>
            ) : (
              <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-3">
                <h4 className="text-sm font-semibold text-gray-700">Новый API ключ</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-gray-500 uppercase">Название</label>
                    <input
                      type="text"
                      value={newKeyName}
                      onChange={(e) => setNewKeyName(e.target.value)}
                      placeholder="OpenAI для user #1"
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs text-gray-700 focus:outline-none focus:border-[#D6001C]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500 uppercase">Тип</label>
                    <select
                      value={newKeyType}
                      onChange={(e) => setNewKeyType(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-xs text-gray-700 focus:outline-none focus:border-[#D6001C]"
                    >
                      <option value="openai">OpenAI</option>
                      <option value="captcha">Captcha</option>
                      <option value="proxy">Proxy</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => createKey.mutate({ token, name: newKeyName, type: newKeyType })}
                    disabled={!newKeyName.trim() || createKey.isPending}
                    className={cn(
                      "px-4 py-2 rounded-lg text-xs font-medium text-white transition-all",
                      createKey.isPending ? "bg-gray-400" : "bg-[#D6001C] hover:brightness-110"
                    )}
                  >
                    {createKey.isPending ? "Создание..." : "Создать"}
                  </button>
                  <button
                    onClick={() => setShowCreateKey(false)}
                    className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg text-xs hover:bg-gray-200 transition-colors"
                  >
                    Отмена
                  </button>
                </div>
              </div>
            )}

            {/* Keys table */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">ID</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Название</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Тип</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Ключ</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-center px-4 py-3">Статус</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-left px-4 py-3">Создан</th>
                    <th className="text-[10px] uppercase text-gray-400 font-medium text-center px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody>
                  {(keysData?.keys || []).map((k: any) => (
                    <tr key={k.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50">
                      <td className="px-4 py-3 text-xs text-gray-500">#{k.id}</td>
                      <td className="px-4 py-3 text-xs font-medium text-gray-700">{k.name}</td>
                      <td className="px-4 py-3"><span className="text-[10px] px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full">{k.type}</span></td>
                      <td className="px-4 py-3 text-xs text-gray-400 font-mono">{k.key.substring(0, 16)}...</td>
                      <td className="px-4 py-3 text-center">
                        <span className={cn(
                          "text-[10px] px-2 py-0.5 rounded-full",
                          k.isActive ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-500"
                        )}>{k.isActive ? "Активен" : "Отключён"}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400">
                        {k.createdAt ? new Date(k.createdAt).toLocaleDateString("ru-RU") : "—"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => toggleKey.mutate({ token, keyId: k.id })}
                          className="text-gray-400 hover:text-[#D6001C] transition-colors"
                        >
                          {k.isActive ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SETTINGS */}
        {tab === "settings" && (
          <div className="max-w-2xl space-y-6">
            <Section title="Информация о системе">
              <div className="space-y-3">
                <div className="flex justify-between py-2 border-b border-gray-50">
                  <span className="text-xs text-gray-500">Версия</span>
                  <span className="text-xs font-medium text-gray-700">v1.3.6</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-50">
                  <span className="text-xs text-gray-500">Режим работы</span>
                  <span className="text-xs font-medium text-gray-700">Production</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-50">
                  <span className="text-xs text-gray-500">Платформ</span>
                  <span className="text-xs font-medium text-gray-700">10</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-50">
                  <span className="text-xs text-gray-500">AI Pipeline</span>
                  <span className="text-xs font-medium text-green-600">Активен</span>
                </div>
              </div>
            </Section>

            <Section title="Безопасность">
              <div className="space-y-3">
                <p className="text-xs text-gray-500">
                  Для изменения пароля администратора обратитесь к разработчику или используйте SQL-запрос.
                </p>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <p className="text-xs text-amber-700">
                    <AlertCircle size={12} className="inline mr-1" />
                    Рекомендуется сменить пароль по умолчанию после первого входа.
                  </p>
                </div>
              </div>
            </Section>
          </div>
        )}
      </div>
    </div>
  );
}

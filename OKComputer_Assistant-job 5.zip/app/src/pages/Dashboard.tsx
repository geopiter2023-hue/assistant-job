import { useState } from "react";
import { useNavigate } from "react-router";
import {
  Search, Bot, FileText, Sparkles, CheckCircle, Loader,
  AlertCircle, ExternalLink, X, ChevronRight, Building2, MapPin, CircleDollarSign,
  Briefcase, Clock, Zap, Eye,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";

interface ProcessedVacancy {
  vacancy: {
    id: string;
    title: string;
    company: string;
    salary: string;
    location: string;
    url: string;
  };
  analysis: {
    matchScore: number;
    keySkills: string[];
    aiSummary: string;
  };
  status: "processed" | "low_match" | "error";
  coverLetter?: string;
}

function VacancyDetail({ v, onClose }: { v: ProcessedVacancy; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white rounded-t-2xl sm:rounded-[14px] w-full max-w-lg max-h-[85vh] overflow-y-auto shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-gray-100 px-5 py-4 flex items-start justify-between rounded-t-2xl sm:rounded-t-[14px]">
          <div>
            <h3 className="text-base font-bold text-gray-800">{v.vacancy.title}</h3>
            <p className="text-xs text-gray-500 mt-0.5">{v.vacancy.company} · {v.vacancy.location}</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 p-1"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex items-center gap-3">
            <span className={cn("px-2.5 py-1 rounded-lg text-xs font-bold",
              v.analysis.matchScore >= 80 ? "bg-green-100 text-green-700" :
              v.analysis.matchScore >= 60 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
            )}>Совпадение {v.analysis.matchScore}%</span>
            {v.vacancy.salary && <span className="text-xs text-green-600 font-medium">{v.vacancy.salary}</span>}
          </div>

          {v.analysis.aiSummary && (
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
              <p className="text-xs font-medium text-blue-700 mb-1 flex items-center gap-1"><Bot size={12} /> AI-анализ вакансии</p>
              <p className="text-xs text-blue-600 leading-relaxed">{v.analysis.aiSummary}</p>
            </div>
          )}

          {v.analysis.keySkills.length > 0 && (
            <div>
              <p className="text-[10px] uppercase text-gray-400 font-medium mb-2">Ключевые навыки</p>
              <div className="flex flex-wrap gap-1.5">
                {v.analysis.keySkills.map((s, i) => (
                  <span key={i} className="px-2 py-1 bg-gray-100 rounded-md text-[10px] text-gray-600">{s}</span>
                ))}
              </div>
            </div>
          )}

          {v.coverLetter && (
            <div>
              <p className="text-[10px] uppercase text-gray-400 font-medium mb-2 flex items-center gap-1"><Sparkles size={10} /> Сопроводительное письмо</p>
              <div className="bg-amber-50 border border-amber-100 rounded-xl p-4">
                <p className="text-xs text-amber-800 leading-relaxed whitespace-pre-line">{v.coverLetter}</p>
              </div>
            </div>
          )}

          <a href={v.vacancy.url} target="_blank" rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full py-3 bg-[#D6001C] text-white text-sm font-bold rounded-xl hover:brightness-110 transition-all">
            <ExternalLink size={14} /> Открыть на HH.ru
          </a>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    totalFound: number;
    processed: number;
    lowMatch: number;
    errors: number;
    results: ProcessedVacancy[];
  } | null>(null);
  const [selectedVacancy, setSelectedVacancy] = useState<ProcessedVacancy | null>(null);

  const autoMutation = trpc.auto.autoApply.useMutation({
    onSuccess: (data) => {
      setIsProcessing(false);
      if ((data as any).error) {
        setError((data as any).error);
        setResult(null);
        return;
      }
      const d = data as any;
      setResult({
        totalFound: d.totalFound || 0,
        processed: d.processed || 0,
        lowMatch: d.lowMatch || 0,
        errors: d.errors || 0,
        results: (d.results || []).filter((r: any) => r.status === "processed"),
      });
      setError(null);
    },
    onError: (err) => {
      setIsProcessing(false);
      setError(err.message || "Ошибка соединения с сервером. Попробуйте позже.");
    },
  });

  const handleSearch = () => {
    if (!query.trim()) return;
    setIsProcessing(true);
    setResult(null);
    setError(null);

    autoMutation.mutate({
      userId: 1,
      query,
      platforms: ["hh"],
      resumeId: 1,
      candidateName: "Иван Петров",
      minMatchScore: 30,
      maxVacancies: 10,
    });
  };

  return (
    <div className="space-y-4">
      {/* Hero */}
      <div className="bg-white border border-gray-200 rounded-[12px] p-5 shadow-sm">
        <h2 className="text-lg font-bold text-gray-800">Поиск вакансий</h2>
        <p className="text-xs text-gray-500 mt-1">
          Система найдёт реальные вакансии на HH.ru, проанализирует их и подготовит сопроводительные письма. Резюме берётся с вашего аккаунта HH.ru.
        </p>

        {/* Search */}
        <div className="mt-4 flex gap-2">
          <div className="flex-1 relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Например: Директор по продажам"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-3 py-3 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:border-[#D6001C] transition-colors"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={isProcessing || !query.trim()}
            className={cn(
              "px-5 py-3 rounded-xl text-sm font-bold text-white transition-all flex items-center gap-2 flex-shrink-0",
              isProcessing ? "bg-gray-400 cursor-wait" : "bg-[#D6001C] hover:brightness-110 shadow-lg shadow-red-200"
            )}
          >
            {isProcessing ? <Loader size={16} className="animate-spin" /> : <Zap size={16} />}
            {isProcessing ? "Поиск..." : "Найти"}
          </button>
        </div>

        {/* Progress steps */}
        {isProcessing && (
          <div className="flex items-center justify-center gap-2 mt-4 text-[10px] text-gray-400">
            <span className="flex items-center gap-0.5"><Search size={9} /> HH.ru</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><Bot size={9} /> Анализ</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><FileText size={9} /> Резюме</span>
            <span>→</span>
            <span className="flex items-center gap-0.5"><Sparkles size={9} /> Письмо</span>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle size={18} className="text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium text-red-700">Ошибка</p>
              <p className="text-xs text-red-600 mt-1">{error}</p>
              {error.includes("блокирует") && (
                <div className="mt-3 bg-white rounded-lg p-3 border border-red-100 space-y-2">
                  <p className="text-xs font-medium text-red-700">Как исправить:</p>
                  <ol className="text-xs text-red-600 space-y-1 list-decimal pl-4">
                    <li>Установите систему на сервере в России (Москва/СПб)</li>
                    <li>Или настройте HTTP-прокси с российским IP в файле <code>.env</code>:<br/><code>HTTP_PROXY=http://user:pass@proxy.ru:8080</code></li>
                    <li>Или используйте VPN на сервере</li>
                  </ol>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      {result && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white border border-gray-200 rounded-[10px] p-4 shadow-sm text-center">
              <p className="text-xl font-bold text-gray-800">{result.totalFound}</p>
              <p className="text-[10px] text-gray-500 uppercase">Найдено</p>
            </div>
            <div className="bg-white border border-gray-200 rounded-[10px] p-4 shadow-sm text-center">
              <p className="text-xl font-bold text-green-600">{result.processed}</p>
              <p className="text-[10px] text-gray-500 uppercase">Подходят</p>
            </div>
            <div className="bg-white border border-gray-200 rounded-[10px] p-4 shadow-sm text-center">
              <p className="text-xl font-bold text-amber-600">{result.lowMatch}</p>
              <p className="text-[10px] text-gray-500 uppercase">Низкое совпадение</p>
            </div>
            <div className="bg-white border border-gray-200 rounded-[10px] p-4 shadow-sm text-center">
              <p className="text-xl font-bold text-red-500">{result.errors}</p>
              <p className="text-[10px] text-gray-500 uppercase">Ошибок</p>
            </div>
          </div>

          {/* Vacancy cards */}
          {result.results.length > 0 ? (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
                <CheckCircle size={14} className="text-green-500" />
                Подготовленные вакансии ({result.results.length})
              </h3>
              {result.results.map((r, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedVacancy(r)}
                  className="w-full text-left bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:border-[#D6001C]/30 hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-[#D6001C]">{r.vacancy.title}</h4>
                        <span className={cn("px-2 py-0.5 rounded-lg text-[10px] font-bold",
                          r.analysis.matchScore >= 80 ? "bg-green-100 text-green-700" :
                          r.analysis.matchScore >= 60 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                        )}>{r.analysis.matchScore}%</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 text-xs text-gray-500">
                        <span className="flex items-center gap-1"><Building2 size={10} />{r.vacancy.company}</span>
                        <span className="flex items-center gap-1"><MapPin size={10} />{r.vacancy.location}</span>
                        {r.vacancy.salary && <span className="flex items-center gap-1 text-green-600 font-medium"><CircleDollarSign size={10} />{r.vacancy.salary}</span>}
                      </div>
                      {r.analysis.aiSummary && (
                        <p className="text-xs text-gray-500 mt-2 line-clamp-2">{r.analysis.aiSummary}</p>
                      )}
                      {r.analysis.keySkills.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {r.analysis.keySkills.slice(0, 6).map((s, j) => (
                            <span key={j} className="px-2 py-0.5 bg-gray-100 rounded text-[10px] text-gray-500">{s}</span>
                          ))}
                        </div>
                      )}
                    </div>
                    <ChevronRight size={16} className="text-gray-300 flex-shrink-0 mt-1" />
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-xl p-8 text-center shadow-sm">
              <Search size={32} className="text-gray-300 mx-auto mb-3" />
              <p className="text-sm text-gray-500">Подходящих вакансий не найдено</p>
              <p className="text-xs text-gray-400 mt-1">Попробуйте изменить запрос или снизить требования к совпадению</p>
            </div>
          )}

          {/* Bottom actions */}
          <div className="flex gap-3">
            <button
              onClick={() => navigate("/applies")}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-[#D6001C] text-white text-sm font-bold rounded-xl hover:brightness-110 transition-all"
            >
              <FileText size={16} /> Смотреть мои отклики
            </button>
            <button
              onClick={() => { setResult(null); setQuery(""); }}
              className="flex items-center justify-center gap-2 px-5 py-3 bg-gray-100 text-gray-600 text-sm font-medium rounded-xl hover:bg-gray-200 transition-all"
            >
              Новый поиск
            </button>
          </div>
        </>
      )}

      {selectedVacancy && <VacancyDetail v={selectedVacancy} onClose={() => setSelectedVacancy(null)} />}
    </div>
  );
}

import { useState, useMemo } from "react";
import { Search, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import { vacanciesData, platformConfig } from "@/lib/data";
import PlatformBadge from "@/components/PlatformBadge";

export default function Vacancies() {
  const [search, setSearch] = useState("");
  const [platformFilter, setPlatformFilter] = useState<string>("all");
  const [expFilter, setExpFilter] = useState<"all" | "junior" | "middle" | "senior">("all");

  const filtered = useMemo(() => {
    return vacanciesData.filter((v) => {
      const matchSearch = !search || v.title.toLowerCase().includes(search.toLowerCase()) || v.company.toLowerCase().includes(search.toLowerCase()) || v.skills.some((s) => s.toLowerCase().includes(search.toLowerCase()));
      const matchPlatform = platformFilter === "all" || v.platform === platformFilter;
      let matchExp = true;
      if (expFilter === "junior") matchExp = v.experience === "1-3 года";
      else if (expFilter === "middle") matchExp = v.experience === "3-6 лет";
      else if (expFilter === "senior") matchExp = v.experience === "более 6 лет";
      return matchSearch && matchPlatform && matchExp;
    });
  }, [search, platformFilter, expFilter]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p>
          <p className="text-2xl font-bold text-hf-text-primary mt-1">{vacanciesData.length}</p>
        </div>
        {Object.entries(platformConfig).slice(0, 4).map(([key, cfg]) => (
          <div key={key} className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
            <p className="text-xs uppercase text-hf-text-secondary tracking-wider">{cfg.label}</p>
            <p className={cn("text-2xl font-bold mt-1", cfg.color)}>{vacanciesData.filter(v => v.platform === key).length}</p>
          </div>
        ))}
      </div>

      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
            <input type="text" placeholder="Поиск по вакансии, компании, навыкам..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg pl-9 pr-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors" />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setPlatformFilter("all")} className={cn("px-3 py-2 rounded-lg text-xs font-medium transition-all", platformFilter === "all" ? "bg-hf-red text-white" : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary")}>Все</button>
          {Object.entries(platformConfig).map(([key, cfg]) => (
            <button key={key} onClick={() => setPlatformFilter(key)} className={cn("px-3 py-2 rounded-lg text-xs font-medium transition-all", platformFilter === key ? "text-white" : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary")} style={platformFilter === key ? { backgroundColor: key === "hh" ? "#D6001C" : key === "zarplata" ? "#22C55E" : key === "rabota" ? "#F97316" : key === "superjob" ? "#EF4444" : key === "yandex_smena" ? "#8B5CF6" : key === "karierist" ? "#06B6D4" : key === "rabotaru" ? "#EC4899" : key === "avito" ? "#10B981" : key === "trudvsem" ? "#F59E0B" : "#6366F1" } : undefined}>{cfg.label}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          {(["all", "junior", "middle", "senior"] as const).map((e) => (
            <button key={e} onClick={() => setExpFilter(e)} className={cn("px-3 py-1.5 rounded-lg text-xs font-medium transition-all", expFilter === e ? "bg-hf-cyan text-white" : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary")}>{e === "all" ? "Все уровни" : e === "junior" ? "Junior" : e === "middle" ? "Middle" : "Senior"}</button>
          ))}
        </div>
      </div>

      <p className="text-sm text-hf-text-secondary">Найдено <span className="text-hf-text-primary font-medium">{filtered.length}</span> вакансий</p>

      <div className="hidden md:block bg-hf-elevated border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-hf-border-subtle">
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ВАКАНСИЯ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">КОМПАНИЯ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАРПЛАТА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ОПЫТ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ПЛОЩАДКА</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">НАВЫКИ</th>
              <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[60px]"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((v) => (
              <tr key={v.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-[#F5F5F880] transition-colors">
                <td className="px-5 py-3"><span className="text-sm text-hf-text-primary font-medium">{v.title}</span>{v.applied && <span className="ml-2 text-xs text-hf-green">✓</span>}</td>
                <td className="px-5 py-3 text-sm text-hf-text-secondary">{v.company}</td>
                <td className="px-5 py-3 text-sm text-hf-green font-medium">{v.salary}</td>
                <td className="px-5 py-3 text-center"><span className="text-xs text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded">{v.experience}</span></td>
                <td className="px-5 py-3 text-center"><PlatformBadge platform={v.platform} /></td>
                <td className="px-5 py-3"><div className="flex flex-wrap gap-1">{v.skills.slice(0, 3).map((s) => <span key={s} className="text-xs text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded">{s}</span>)}{v.skills.length > 3 && <span className="text-xs text-hf-text-muted">+{v.skills.length - 3}</span>}</div></td>
                <td className="px-5 py-3 text-center"><a href={v.url} target="_blank" rel="noopener noreferrer" className="text-hf-text-muted hover:text-hf-red transition-colors"><ExternalLink size={14} /></a></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="md:hidden space-y-3">
        {filtered.map((v) => (
          <div key={v.id} className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2"><span className="text-sm text-hf-text-primary font-medium">{v.title}</span>{v.applied && <span className="text-xs text-hf-green">✓</span>}</div>
                <p className="text-xs text-hf-text-secondary mt-1">{v.company}</p>
              </div>
              <a href={v.url} target="_blank" rel="noopener noreferrer" className="text-hf-text-muted hover:text-hf-red flex-shrink-0 mt-1"><ExternalLink size={14} /></a>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <span className="text-sm text-hf-green font-medium">{v.salary}</span>
              <span className="text-xs text-hf-text-secondary">{v.location}</span>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <PlatformBadge platform={v.platform} />
              <span className="text-xs text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded">{v.experience}</span>
            </div>
            <div className="flex flex-wrap gap-1 mt-2">{v.skills.map((s) => <span key={s} className="text-xs text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded">{s}</span>)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

import { Briefcase, ExternalLink, Info, CheckCircle, Settings } from "lucide-react";
import { useNavigate } from "react-router";

export default function Resumes() {
  const navigate = useNavigate();

  return (
    <div className="max-w-lg mx-auto space-y-6">
      {/* Info card */}
      <div className="bg-white border border-gray-200 rounded-[12px] p-6 shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Info size={20} className="text-blue-600" />
          </div>
          <div>
            <h2 className="text-base font-bold text-gray-800">Резюме с HH.ru</h2>
            <p className="text-xs text-gray-500">Как это работает</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex gap-3">
            <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-600 leading-relaxed">
              <strong className="text-gray-800">Резюме не нужно загружать.</strong> Система использует резюме,
              которые уже загружены в ваш аккаунт HH.ru. При отклике выбирается подходящее резюме автоматически.
            </p>
          </div>

          <div className="flex gap-3">
            <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-600 leading-relaxed">
              <strong className="text-gray-800">AI анализирует вакансию</strong> — читает требования и обязанности,
              сравнивает с вашим опытом и подстраивает сопроводительное письмо под каждую вакансию индивидуально.
            </p>
          </div>

          <div className="flex gap-3">
            <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-gray-600 leading-relaxed">
              <strong className="text-gray-800">Отклик происходит через HH.ru</strong> — система заходит
              на сайт под вашим логином и отправляет отклик с выбранным резюме и подготовленным письмом.
            </p>
          </div>
        </div>
      </div>

      {/* Setup card */}
      <div className="bg-amber-50 border border-amber-200 rounded-[12px] p-5">
        <div className="flex items-center gap-2 mb-3">
          <Settings size={16} className="text-amber-600" />
          <h3 className="text-sm font-bold text-amber-800">Что нужно настроить</h3>
        </div>
        <ol className="space-y-2">
          <li className="flex items-start gap-2 text-xs text-amber-700">
            <span className="font-bold">1.</span>
            <span>Введите логин и пароль от HH.ru в разделе «Настройки → Площадки»</span>
          </li>
          <li className="flex items-start gap-2 text-xs text-amber-700">
            <span className="font-bold">2.</span>
            <span>Убедитесь что в вашем аккаунте HH.ru есть хотя бы одно резюме</span>
          </li>
          <li className="flex items-start gap-2 text-xs text-amber-700">
            <span className="font-bold">3.</span>
            <span>Вернитесь на главную и нажмите «Найти» — система начнёт работу</span>
          </li>
        </ol>
        <button
          onClick={() => navigate("/settings")}
          className="mt-4 w-full py-2.5 bg-amber-500 text-white text-xs font-bold rounded-lg hover:bg-amber-600 transition-colors flex items-center justify-center gap-2"
        >
          <Settings size={14} /> Перейти в настройки
        </button>
      </div>

      {/* HH link */}
      <a
        href="https://hh.ru/applicant/resumes"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 py-3 bg-white border border-gray-200 text-gray-600 text-xs font-medium rounded-xl hover:border-[#D6001C]/30 hover:text-[#D6001C] transition-all"
      >
        <Briefcase size={14} /> Мои резюме на HH.ru <ExternalLink size={12} />
      </a>
    </div>
  );
}

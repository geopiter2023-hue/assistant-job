import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { ShieldCheck, ShieldAlert, Loader, Eye, EyeOff, Briefcase, ArrowRight, ChevronRight, AlertCircle, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { platformConfig } from "@/lib/data";
import type { JobPlatform } from "@/lib/data";
import { trpc } from "@/providers/trpc";

const allPlatforms = Object.keys(platformConfig) as JobPlatform[];

interface PlatformData {
  enabled: boolean;
  login: string;
  password: string;
}

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [platforms, setPlatforms] = useState<Record<JobPlatform, PlatformData>>(
    () => Object.fromEntries(
      allPlatforms.map((p) => [p, { enabled: false, login: "", password: "" }])
    ) as Record<JobPlatform, PlatformData>
  );
  const [checkingLogin, setCheckingLogin] = useState<Record<string, "idle" | "loading" | "success" | "error">>({});
  const [checkMessage, setCheckMessage] = useState<Record<string, string>>({});
  const [showPassword, setShowPassword] = useState<Record<string, boolean>>({});
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const saveMutation = trpc.profile.saveSettings.useMutation({
    onSuccess: () => {
      setSaved(true);
      setSaveError(null);
      setTimeout(() => setStep(3), 500);
    },
    onError: (err) => {
      setSaveError(err.message || "Ошибка сохранения");
    },
  });

  const checkMutation = trpc.profile.checkPlatformLogin.useMutation({
    onSuccess: (data, variables) => {
      setCheckingLogin(prev => ({ ...prev, [variables.platform]: data.success ? "success" : "error" }));
      if (data.message) {
        setCheckMessage(prev => ({ ...prev, [variables.platform]: data.message }));
      }
      setTimeout(() => {
        setCheckingLogin(prev => ({ ...prev, [variables.platform]: "idle" }));
      }, 4000);
    },
    onError: (err, variables) => {
      setCheckingLogin(prev => ({ ...prev, [variables.platform]: "error" }));
      setCheckMessage(prev => ({ ...prev, [variables.platform]: err.message || "Ошибка" }));
      setTimeout(() => {
        setCheckingLogin(prev => ({ ...prev, [variables.platform]: "idle" }));
      }, 4000);
    },
  });

  const enabledCount = Object.values(platforms).filter(p => p.enabled).length;

  const togglePlatform = (key: JobPlatform) => {
    setPlatforms(prev => ({
      ...prev,
      [key]: { ...prev[key], enabled: !prev[key].enabled },
    }));
  };

  const updateField = (key: JobPlatform, field: "login" | "password", value: string) => {
    setPlatforms(prev => ({
      ...prev,
      [key]: { ...prev[key], [field]: value },
    }));
  };

  const handleCheck = useCallback((key: JobPlatform) => {
    const p = platforms[key];
    if (!p.login.trim() || !p.password.trim()) return;
    setCheckingLogin(prev => ({ ...prev, [key]: "loading" }));
    checkMutation.mutate({ platform: key, login: p.login, password: p.password });
  }, [platforms, checkMutation]);

  const handleSave = () => {
    const platformsPayload = Object.fromEntries(
      Object.entries(platforms).map(([k, v]) => [k, { enabled: v.enabled, login: v.login, password: v.password }])
    );
    saveMutation.mutate({
      userId: 1,
      platforms: platformsPayload as any,
    });
  };

  // Step 1 — Welcome
  if (step === 1) {
    return (
      <div className="max-w-lg mx-auto space-y-6 text-center">
        <div className="bg-white border border-hf-border-subtle rounded-[12px] p-8 shadow-card">
          <div className="w-16 h-16 bg-hf-red/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Briefcase size={32} className="text-hf-red" />
          </div>
          <h1 className="text-xl font-bold text-hf-text-primary mb-2">
            Добро пожаловать в Assistant Job
          </h1>
          <p className="text-sm text-hf-text-secondary mb-6">
            Автоматизированная система поиска и откликов на вакансии. Выберите job-площадки, где у вас есть аккаунты, и система будет автоматически искать и откликаться на подходящие вакансии.
          </p>
          <button
            onClick={() => setStep(2)}
            className="w-full py-3 bg-hf-red text-white text-sm font-bold rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
          >
            Выбрать площадки <ArrowRight size={16} />
          </button>
        </div>
      </div>
    );
  }

  // Step 3 — Done
  if (step === 3) {
    return (
      <div className="max-w-lg mx-auto space-y-6 text-center">
        <div className="bg-white border border-hf-border-subtle rounded-[12px] p-8 shadow-card">
          <div className="w-16 h-16 bg-hf-green/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck size={32} className="text-hf-green" />
          </div>
          <h1 className="text-xl font-bold text-hf-text-primary mb-2">
            Готово!
          </h1>
          <p className="text-sm text-hf-text-secondary mb-6">
            {enabledCount} площадок настроено. Теперь перейдите к поиску вакансий.
          </p>
          <button
            onClick={() => {
              localStorage.setItem("aj_onboarding_done", "1");
              navigate("/");
            }}
            className="w-full py-3 bg-hf-red text-white text-sm font-bold rounded-lg hover:brightness-110 transition-all flex items-center justify-center gap-2"
          >
            Начать поиск <ArrowRight size={16} />
          </button>
        </div>
      </div>
    );
  }

  // Step 2 — Platforms
  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-xl font-bold text-hf-text-primary">Выберите площадки</h1>
        <p className="text-sm text-hf-text-secondary mt-1">
          Включите job-площадки, где у вас есть аккаунт, и введите данные для входа
        </p>
      </div>

      {/* Platform list */}
      <div className="space-y-3">
        {allPlatforms.map((key) => {
          const cfg = platformConfig[key];
          const plat = platforms[key];
          return (
            <div
              key={key}
              className={cn(
                "bg-white border rounded-[10px] p-4 shadow-card transition-all",
                plat.enabled ? "border-hf-red/30" : "border-hf-border-subtle"
              )}
            >
              {/* Platform header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {/* Toggle */}
                  <button
                    onClick={() => togglePlatform(key)}
                    className={cn(
                      "w-12 h-7 rounded-full transition-colors relative flex-shrink-0",
                      plat.enabled ? "bg-hf-red" : "bg-hf-border-subtle"
                    )}
                  >
                    <span className={cn(
                      "absolute top-[2px] w-6 h-6 rounded-full bg-white shadow transition-transform",
                      plat.enabled ? "translate-x-[22px]" : "translate-x-[2px]"
                    )} />
                  </button>
                  <div>
                    <span className="text-sm font-medium text-hf-text-primary">{cfg.label}</span>
                    <span className={cn("ml-2 text-[10px] px-2 py-0.5 rounded font-medium", cfg.bg, cfg.color)}>
                      {cfg.domain}
                    </span>
                  </div>
                </div>
                <Globe size={16} className="text-hf-text-muted" />
              </div>

              {/* Credentials (when enabled) */}
              {plat.enabled && (
                <div className="mt-4 pl-[60px] space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Логин</label>
                      <input
                        type="text"
                        placeholder="Email или телефон"
                        value={plat.login}
                        onChange={(e) => updateField(key, "login", e.target.value)}
                        className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Пароль</label>
                      <div className="relative">
                        <input
                          type={showPassword[key] ? "text" : "password"}
                          placeholder="Пароль"
                          value={plat.password}
                          onChange={(e) => updateField(key, "password", e.target.value)}
                          className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 pr-10 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(prev => ({ ...prev, [key]: !prev[key] }))}
                          className="absolute right-2 top-1/2 -translate-y-1/2 text-hf-text-muted hover:text-hf-text-primary p-1"
                          tabIndex={-1}
                        >
                          {showPassword[key] ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Check login */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleCheck(key)}
                      disabled={checkingLogin[key] === "loading" || !plat.login.trim() || !plat.password.trim()}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border",
                        checkingLogin[key] === "success" && "bg-hf-green/10 text-hf-green border-hf-green/20",
                        checkingLogin[key] === "error" && "bg-red-50 text-red-500 border-red-200",
                        (!checkingLogin[key] || checkingLogin[key] === "idle") && "bg-hf-highlight text-hf-text-secondary border-hf-border-subtle hover:text-hf-red hover:border-hf-red/30",
                        "disabled:opacity-50 disabled:cursor-not-allowed"
                      )}
                    >
                      {checkingLogin[key] === "loading" && <Loader size={12} className="animate-spin" />}
                      {checkingLogin[key] === "success" && <ShieldCheck size={12} />}
                      {checkingLogin[key] === "error" && <ShieldAlert size={12} />}
                      {(!checkingLogin[key] || checkingLogin[key] === "idle") && <ShieldCheck size={12} />}
                      {checkingLogin[key] === "loading" ? "Проверка..." :
                       checkingLogin[key] === "success" ? "Формат OK" :
                       checkingLogin[key] === "error" ? "Ошибка" :
                       "Проверить вход"}
                    </button>
                    {checkMessage[key] && (
                      <span className="text-[10px] text-hf-text-secondary">{checkMessage[key]}</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom action */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        {saveError && (
          <div className="mb-3 bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2 text-xs text-red-600">
            <AlertCircle size={14} className="flex-shrink-0" /> {saveError}
          </div>
        )}
        <div className="flex items-center justify-between">
          <p className="text-xs text-hf-text-secondary">
            Выбрано площадок: <span className="font-bold text-hf-red">{enabledCount}</span>
          </p>
          <button
            onClick={handleSave}
            disabled={enabledCount === 0 || saveMutation.isPending}
            className={cn(
              "flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-bold transition-all",
              enabledCount === 0
                ? "bg-hf-border-subtle text-hf-text-muted cursor-not-allowed"
                : saveMutation.isPending
                  ? "bg-hf-red opacity-70 text-white cursor-wait"
                  : "bg-hf-red text-white hover:brightness-110 shadow-lg shadow-hf-red/25"
            )}
          >
            {saveMutation.isPending ? <Loader size={14} className="animate-spin" /> : <ChevronRight size={14} />}
            {saveMutation.isPending ? "Сохранение..." : saved ? "Сохранено!" : "Продолжить"}
          </button>
        </div>
      </div>
    </div>
  );
}

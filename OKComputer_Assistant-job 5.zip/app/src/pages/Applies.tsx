import { useState } from "react";
import { Check, X, Search, Eye, FileText, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import PlatformBadge from "@/components/PlatformBadge";

function StatusBadge({ status, label }: { status: string; label: string }) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium",
      status === "success" ? "bg-[#10B98120] text-hf-green" :
      status === "pending" ? "bg-[#F59E0B20] text-amber-600" :
      "bg-[#EF444420] text-hf-red"
    )}>
      {status === "success" ? <Check size={12} strokeWidth={2.5} /> :
       status === "pending" ? <AlertCircle size={12} strokeWidth={2.5} /> :
       <X size={12} strokeWidth={2.5} />}{label}
    </span>
  );
}

function statusLabel(status: string): string {
  if (status === "success") return "Успешно";
  if (status === "pending") return "В ожидании";
  return "Ошибка";
}

function DetailModal({ app, onClose }: { app: any; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white border border-hf-border-subtle rounded-[14px] p-6 max-w-md w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-hf-text-primary">Детали отклика</h3>
          <button onClick={onClose} className="text-hf-text-muted hover:text-hf-text-primary transition-colors"><X size={20} /></button>
        </div>
        <div className="space-y-3">
          <div><p className="text-xs text-hf-text-secondary uppercase">Вакансия</p><p className="text-sm text-hf-text-primary font-medium">{app.vacancy}</p></div>
          <div><p className="text-xs text-hf-text-secondary uppercase">Компания</p><p className="text-sm text-hf-text-primary">{app.company || "—"}</p></div>
          <div className="flex gap-6">
            <div><p className="text-xs text-hf-text-secondary uppercase">Статус</p><StatusBadge status={app.status} label={statusLabel(app.status)} /></div>
            <div><p className="text-xs text-hf-text-secondary uppercase">Площадка</p><PlatformBadge platform={app.platform} /></div>
          </div>
          {app.salary && <div><p className="text-xs text-hf-text-secondary uppercase">Зарплата</p><p className="text-sm text-hf-green font-medium">{app.salary}</p></div>}
          {app.location && <div><p className="text-xs text-hf-text-secondary uppercase">Локация</p><p className="text-sm text-hf-text-primary">{app.location}</p></div>}
          {app.coverLetter && <div><p className="text-xs text-hf-text-secondary uppercase">Сопроводительное</p><div className="bg-hf-highlight rounded-lg p-3 mt-1"><p className="text-xs text-hf-text-secondary leading-relaxed">{app.coverLetter}</p></div></div>}
          {app.createdAt && <div><p className="text-xs text-hf-text-secondary uppercase">Время</p><p className="text-sm text-hf-text-muted">{new Date(app.createdAt).toLocaleString("ru-RU")}</p></div>}
        </div>
      </div>
    </div>
  );
}

export default function Applies() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "success" | "error" | "pending">("all");
  const [selectedApp, setSelectedApp] = useState<any | null>(null);

  // Загрузка реальных откликов из БД
  const { data: appliesList, isLoading } = trpc.applies.list.useQuery({ userId: 1, limit: 50 });
  const { data: statsData } = trpc.applies.stats.useQuery({ userId: 1 });

  const applications = appliesList || [];

  const filtered = applications.filter((a: any) => {
    const matchSearch = !search ||
      (a.vacancy && a.vacancy.toLowerCase().includes(search.toLowerCase())) ||
      (a.company && a.company.toLowerCase().includes(search.toLowerCase()));
    const matchStatus = statusFilter === "all" || a.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = statsData || { total: 0, success: 0, error: 0, conversionRate: "0" };

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p>
          <p className="text-2xl font-bold text-hf-text-primary mt-1">{stats.total}</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Успешно</p>
          <p className="text-2xl font-bold text-hf-green mt-1">{stats.success}</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Ошибок</p>
          <p className="text-2xl font-bold text-hf-red mt-1">{stats.error}</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Успешность</p>
          <p className="text-2xl font-bold text-hf-red mt-1">{stats.conversionRate}%</p>
        </div>
      </div>

      {/* Search + filter */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
            <input
              type="text"
              placeholder="Поиск по вакансии или компании..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-hf-base border border-hf-border-subtle rounded-lg pl-9 pr-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
            />
          </div>
          <div className="flex gap-2">
            {(["all", "success", "pending", "error"] as const).map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={cn(
                  "px-3 py-2 rounded-lg text-xs font-medium transition-all",
                  statusFilter === s
                    ? (s === "success" ? "bg-hf-green text-white" : s === "error" ? "bg-hf-red text-white" : s === "pending" ? "bg-amber-500 text-white" : "bg-hf-red text-white")
                    : "bg-hf-base text-hf-text-secondary border border-hf-border-subtle hover:text-hf-text-primary"
                )}
              >
                {s === "all" ? "Все" : s === "success" ? "Успешно" : s === "pending" ? "В ожидании" : "Ошибка"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Empty state */}
      {applications.length === 0 && !isLoading && (
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-8 shadow-card text-center">
          <FileText size={40} className="text-hf-border-subtle mx-auto mb-3" />
          <p className="text-sm text-hf-text-secondary mb-1">Пока нет откликов</p>
          <p className="text-xs text-hf-text-muted mb-4">Ваши отклики будут появляться здесь после запуска поиска</p>
          <button
            onClick={() => window.location.hash = "/"}
            className="px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all"
          >
            Начать поиск
          </button>
        </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-8 shadow-card text-center">
          <div className="w-6 h-6 border-2 border-hf-red border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          <p className="text-xs text-hf-text-secondary">Загрузка откликов...</p>
        </div>
      )}

      {/* Desktop table */}
      {applications.length > 0 && (
        <>
          <div className="hidden md:block bg-white border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="border-b border-hf-border-subtle">
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[100px]">СТАТУС</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ВАКАНСИЯ</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">КОМПАНИЯ</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ПЛОЩАДКА</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАРПЛАТА</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-right px-5 py-3">ВРЕМЯ</th>
                  <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[60px]"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((app: any) => (
                  <tr key={app.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-hf-highlight/50 transition-colors">
                    <td className="px-5 py-3.5 text-center"><StatusBadge status={app.status} label={statusLabel(app.status)} /></td>
                    <td className="px-5 py-3.5"><span className="text-sm text-hf-red">{app.vacancy}</span></td>
                    <td className="px-5 py-3.5 text-sm text-hf-text-primary">{app.company || "—"}</td>
                    <td className="px-5 py-3.5 text-center"><PlatformBadge platform={app.platform} /></td>
                    <td className="px-5 py-3.5 text-sm text-hf-green">{app.salary || "—"}</td>
                    <td className="px-5 py-3.5 text-sm text-hf-text-muted text-right">
                      {app.createdAt ? new Date(app.createdAt).toLocaleDateString("ru-RU") : "—"}
                    </td>
                    <td className="px-5 py-3.5 text-center"><button onClick={() => setSelectedApp(app)} className="text-hf-text-muted hover:text-hf-red transition-colors"><Eye size={14} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden space-y-3">
            {filtered.map((app: any) => (
              <button key={app.id} onClick={() => setSelectedApp(app)} className="w-full text-left bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card hover:bg-hf-highlight/30 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0"><span className="text-sm text-hf-red block truncate">{app.vacancy}</span><p className="text-xs text-hf-text-secondary mt-0.5">{app.company || "—"}</p></div>
                  <StatusBadge status={app.status} label={statusLabel(app.status)} />
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-2"><PlatformBadge platform={app.platform} />{app.salary && <span className="text-xs text-hf-green">{app.salary}</span>}</div>
                  <span className="text-xs text-hf-text-muted">
                    {app.createdAt ? new Date(app.createdAt).toLocaleDateString("ru-RU") : "—"}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </>
      )}

      {selectedApp && <DetailModal app={selectedApp} onClose={() => setSelectedApp(null)} />}
    </div>
  );
}

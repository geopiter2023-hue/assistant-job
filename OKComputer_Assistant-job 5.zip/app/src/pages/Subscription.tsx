import { useState } from "react";
import { Check, Crown, Zap, Shield, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { subscriptionPlans } from "@/lib/data";
import type { SubscriptionPlan } from "@/lib/data";

function PlanCard({
  plan,
  onSelect,
}: {
  plan: SubscriptionPlan;
  onSelect: (plan: SubscriptionPlan) => void;
}) {
  return (
    <div
      className={cn(
        "relative rounded-[14px] p-5 lg:p-6 transition-all duration-200",
        "border bg-hf-elevated shadow-card",
        plan.popular
          ? "border-hf-amber shadow-[0_0_20px_rgba(245,158,11,0.1)]"
          : plan.current
          ? "border-hf-green shadow-[0_0_20px_rgba(16,185,129,0.1)]"
          : "border-hf-border-subtle hover:border-[#3B82F640] hover:shadow-card-hover"
      )}
    >
      {/* Badge */}
      {plan.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-hf-amber text-hf-base text-xs font-bold rounded-full">
            <Crown size={12} />
            Популярный
          </span>
        </div>
      )}
      {plan.current && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-hf-green text-hf-base text-xs font-bold rounded-full">
            <Check size={12} />
            Ваш тариф
          </span>
        </div>
      )}

      {/* Plan header */}
      <div className="text-center mb-5">
        <div
          className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3",
            plan.popular
              ? "bg-gradient-to-br from-hf-amber to-[#F59E0B80]"
              : plan.current
              ? "bg-gradient-to-br from-hf-green to-[#10B98180]"
              : "bg-gradient-to-br from-hf-red to-[#3B82F680]"
          )}
        >
          {plan.popular ? (
            <Zap size={22} className="text-white" strokeWidth={2.5} />
          ) : plan.current ? (
            <Shield size={22} className="text-white" strokeWidth={2.5} />
          ) : (
            <User size={22} className="text-white" strokeWidth={2.5} />
          )}
        </div>
        <h3 className="text-lg font-bold text-hf-text-primary">{plan.name}</h3>
        <p className="text-xs text-hf-text-secondary mt-1">{plan.description}</p>
      </div>

      {/* Price */}
      <div className="text-center mb-5 pb-5 border-b border-hf-border-subtle">
        <span className="text-3xl font-bold text-hf-text-primary">
          {plan.price === 0 ? "Бесплатно" : `${plan.price.toLocaleString("ru-RU")} ₽`}
        </span>
        {plan.price > 0 && <span className="text-sm text-hf-text-secondary ml-1">{plan.period}</span>}
      </div>

      {/* Features */}
      <ul className="space-y-3 mb-6">
        {plan.features.map((feature, i) => (
          <li key={i} className="flex items-start gap-2.5">
            <Check
              size={16}
              className={cn(
                "flex-shrink-0 mt-0.5",
                plan.popular ? "text-hf-amber" : plan.current ? "text-hf-green" : "text-hf-red"
              )}
            />
            <span className="text-sm text-hf-text-secondary">{feature}</span>
          </li>
        ))}
      </ul>

      {/* Button */}
      {plan.current ? (
        <button className="w-full py-2.5 rounded-lg text-sm font-medium bg-hf-green/10 text-hf-green border border-hf-green/30 cursor-default">
          Активен
        </button>
      ) : (
        <button
          onClick={() => onSelect(plan)}
          className={cn(
            "w-full py-2.5 rounded-lg text-sm font-medium transition-all hover:scale-[1.02] active:scale-[0.98]",
            plan.popular
              ? "bg-gradient-to-r from-hf-amber to-[#F59E0BCC] text-hf-base font-semibold hover:shadow-lg"
              : plan.price === 0
              ? "bg-hf-base border border-hf-border-subtle text-hf-text-primary hover:border-hf-red"
              : "bg-hf-red text-white hover:brightness-110"
          )}
        >
          {plan.price === 0 ? "Начать бесплатно" : "Выбрать тариф"}
        </button>
      )}
    </div>
  );
}

export default function Subscription() {
  const [showPayment, setShowPayment] = useState<SubscriptionPlan | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"card" | "crypto">("card");
  const [promoCode, setPromoCode] = useState("");

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-hf-text-primary">Выберите подходящий тариф</h2>
        <p className="text-sm text-hf-text-secondary max-w-lg mx-auto">
          Assistant Job работает по подписке. Выберите тариф в зависимости от интенсивности вашего поиска работы.
          Все тарифы включают доступ к hh.ru и Хабр Карьера.
        </p>
      </div>

      {/* Usage stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card text-center">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Текущий тариф</p>
          <p className="text-lg font-bold text-hf-green mt-1">Бизнес</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card text-center">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">До следующего списания</p>
          <p className="text-lg font-bold text-hf-red mt-1">12 дней</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card text-center">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Откликов сегодня</p>
          <p className="text-lg font-bold text-hf-cyan mt-1">12 / ∞</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card text-center">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Платформы</p>
          <p className="text-lg font-bold text-hf-text-primary mt-1">hh + Хабр</p>
        </div>
      </div>

      {/* Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
        {subscriptionPlans.map((plan) => (
          <PlanCard key={plan.id} plan={plan} onSelect={setShowPayment} />
        ))}
      </div>

      {/* FAQ */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <h3 className="text-base font-semibold text-hf-text-primary mb-4">Частые вопросы</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { q: "Можно ли сменить тариф?", a: "Да, вы можете повысить или понизить тариф в любой момент. Разница будет пересчитана пропорционально." },
            { q: "Есть ли пробный период?", a: "Да, 7 дней бесплатного тестирования Профессионального тарифа." },
            { q: "Как отменить подписку?", a: "Отмена в один клик в разделе Подписка. Доступ сохранится до конца оплаченного периода." },
            { q: "Что такое сессия?", a: "Один запуск бота — поиск вакансий и отправка откликов по заданным параметрам." },
          ].map((item, i) => (
            <div key={i} className="space-y-1">
              <p className="text-sm font-medium text-hf-text-primary">{item.q}</p>
              <p className="text-xs text-hf-text-secondary leading-relaxed">{item.a}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Modal */}
      {showPayment && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={() => setShowPayment(null)}
        >
          <div
            className="bg-hf-elevated border border-hf-border-subtle rounded-[14px] p-6 max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-hf-text-primary">Оплата тарифа</h3>
                <p className="text-sm text-hf-text-secondary">
                  {showPayment.name} — {showPayment.price.toLocaleString("ru-RU")} ₽{showPayment.period}
                </p>
              </div>
              <button
                onClick={() => setShowPayment(null)}
                className="text-hf-text-muted hover:text-hf-text-primary transition-colors p-1"
              >
                ✕
              </button>
            </div>

            {/* Payment method */}
            <div className="space-y-3 mb-5">
              <p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Способ оплаты</p>
              <div className="flex gap-2">
                <button
                  onClick={() => setPaymentMethod("card")}
                  className={cn(
                    "flex-1 py-2.5 rounded-lg text-sm font-medium border transition-all",
                    paymentMethod === "card"
                      ? "bg-hf-red text-white border-hf-red"
                      : "bg-hf-base text-hf-text-secondary border-hf-border-subtle hover:text-hf-text-primary"
                  )}
                >
                  Банковская карта
                </button>
                <button
                  onClick={() => setPaymentMethod("crypto")}
                  className={cn(
                    "flex-1 py-2.5 rounded-lg text-sm font-medium border transition-all",
                    paymentMethod === "crypto"
                      ? "bg-hf-amber text-hf-base border-hf-amber"
                      : "bg-hf-base text-hf-text-secondary border-hf-border-subtle hover:text-hf-text-primary"
                  )}
                >
                  Криптовалюта
                </button>
              </div>
            </div>

            {/* Promo code */}
            <div className="space-y-2 mb-5">
              <p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Промокод</p>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Введите промокод"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="flex-1 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
                />
                <button className="px-4 py-2 bg-hf-base text-hf-text-secondary text-sm rounded-lg border border-hf-border-subtle hover:text-hf-text-primary transition-colors">
                  Применить
                </button>
              </div>
            </div>

            {/* Summary */}
            <div className="bg-hf-base rounded-lg p-4 space-y-2 mb-5">
              <div className="flex justify-between text-sm">
                <span className="text-hf-text-secondary">Тариф</span>
                <span className="text-hf-text-primary">{showPayment.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-hf-text-secondary">Период</span>
                <span className="text-hf-text-primary">1 месяц</span>
              </div>
              <div className="border-t border-hf-border-subtle pt-2 flex justify-between">
                <span className="text-hf-text-primary font-medium">Итого</span>
                <span className="text-hf-text-primary font-bold text-lg">{showPayment.price.toLocaleString("ru-RU")} ₽</span>
              </div>
            </div>

            <button className="w-full py-3 rounded-lg text-sm font-semibold text-white bg-gradient-to-r from-hf-red to-hf-cyan hover:brightness-110 transition-all">
              Оплатить {showPayment.price.toLocaleString("ru-RU")} ₽
            </button>

            <p className="text-xs text-hf-text-muted text-center mt-3">
              Оплачивая, вы соглашаетесь с условиями использования
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

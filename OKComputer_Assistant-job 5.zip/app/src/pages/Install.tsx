import { useState } from "react";
import { Check, Copy, Terminal, FolderOpen, Settings, Play, AlertTriangle, FileText, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

interface Step {
  number: number;
  title: string;
  description: string;
  code?: string;
  codeLang?: string;
  icon: React.ElementType;
  tip?: string;
}

const steps: Step[] = [
  {
    number: 1,
    title: "Клонирование репозитория",
    description: "Склонируйте проект с GitHub на свой компьютер:",
    code: "git clone https://github.com/your-org/assistant-job.git\ncd assistant-job",
    icon: FolderOpen,
    tip: "Убедитесь, что у вас установлен Git. Если нет — скачайте с git-scm.com",
  },
  {
    number: 2,
    title: "Установка зависимостей",
    description: "Установите все необходимые пакеты через npm:",
    code: "npm install",
    icon: Terminal,
    tip: "Требуется Node.js версии 18+. Проверьте: node --version",
  },
  {
    number: 3,
    title: "Настройка окружения",
    description: "Создайте файл .env в корне проекта с вашими данными:",
    code: "# Копируем шаблон\ncp .env.example .env\n\n# Редактируем файл\nnano .env",
    icon: Settings,
    tip: "Заполните логины и пароли от hh.ru и Хабр Карьера в настройках через UI",
  },
  {
    number: 4,
    title: "Запуск в режиме разработки",
    description: "Запустите локальный сервер для разработки:",
    code: "npm run dev",
    icon: Play,
    tip: "Откройте http://localhost:5173 в браузере. При изменениях страница обновится автоматически.",
  },
  {
    number: 5,
    title: "Сборка для production",
    description: "Соберите оптимизированную версию для деплоя:",
    code: "npm run build",
    icon: FileText,
    tip: "Готовые файлы появятся в папке dist/ — их можно загрузить на любой статический хостинг.",
  },
];

const requirements = [
  { name: "Node.js", version: ">= 18.0.0", icon: Terminal },
  { name: "npm", version: ">= 9.0.0", icon: Terminal },
  { name: "Git", version: ">= 2.30.0", icon: FolderOpen },
  { name: "Браузер", version: "Chrome / Firefox / Safari", icon: ExternalLink },
];

function CodeBlock({ code, lang }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative mt-3">
      <div className="flex items-center justify-between px-3 py-1.5 bg-hf-base border border-hf-border-subtle rounded-t-lg">
        <span className="text-[10px] text-hf-text-muted uppercase tracking-wider">{lang || "bash"}</span>
        <button
          onClick={handleCopy}
          className={cn(
            "flex items-center gap-1 text-xs transition-colors",
            copied ? "text-hf-green" : "text-hf-text-muted hover:text-hf-text-primary"
          )}
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? "Скопировано" : "Копировать"}
        </button>
      </div>
      <pre className="bg-hf-base border-x border-b border-hf-border-subtle rounded-b-lg p-3 overflow-x-auto">
        <code className="text-sm text-hf-text-primary font-mono whitespace-pre">{code}</code>
      </pre>
    </div>
  );
}

export default function Install() {
  return (
    <div className="max-w-3xl space-y-6">
      {/* Header */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-hf-blue to-hf-cyan flex items-center justify-center">
            <Terminal size={22} className="text-white" strokeWidth={2} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-hf-text-primary">Установка Assistant Job</h2>
            <p className="text-xs text-hf-text-secondary">Версия v1 — пошаговая инструкция</p>
          </div>
        </div>
        <p className="text-sm text-hf-text-secondary leading-relaxed">
          Следуйте шагам ниже, чтобы установить и запустить Assistant Job на своём компьютере.
          Весь процесс займёт не более 5 минут.
        </p>
      </div>

      {/* Requirements */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <h3 className="text-sm font-semibold text-hf-text-primary mb-4">Системные требования</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {requirements.map((req) => (
            <div
              key={req.name}
              className="flex items-center gap-3 px-3 py-2.5 bg-hf-base rounded-lg border border-hf-border-subtle"
            >
              <req.icon size={16} className="text-hf-blue flex-shrink-0" />
              <div>
                <p className="text-sm text-hf-text-primary font-medium">{req.name}</p>
                <p className="text-xs text-hf-text-secondary">{req.version}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Steps */}
      <div className="space-y-4">
        {steps.map((step) => (
          <div
            key={step.number}
            className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card hover:shadow-card-hover transition-all duration-200"
          >
            <div className="flex items-start gap-4">
              {/* Step number */}
              <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-hf-blue/20 border border-hf-blue/30 flex items-center justify-center">
                <span className="text-sm font-bold text-hf-blue">{step.number}</span>
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-hf-text-primary">{step.title}</h3>
                <p className="text-xs text-hf-text-secondary mt-1">{step.description}</p>

                {step.code && <CodeBlock code={step.code} lang={step.codeLang} />}

                {step.tip && (
                  <div className="flex items-start gap-2 mt-3 px-3 py-2 bg-hf-amber/10 rounded-lg border border-hf-amber/20">
                    <AlertTriangle size={12} className="text-hf-amber flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-hf-amber leading-relaxed">{step.tip}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick start card */}
      <div className="bg-gradient-to-r from-hf-blue/10 to-hf-cyan/10 border border-hf-blue/20 rounded-[10px] p-5 shadow-card">
        <h3 className="text-sm font-semibold text-hf-text-primary mb-2">Быстрый старт</h3>
        <p className="text-xs text-hf-text-secondary mb-3">
          Если все зависимости уже установлены, достаточно трёх команд:
        </p>
        <CodeBlock
          code={"git clone https://github.com/your-org/assistant-job.git\ncd assistant-job\nnpm install && npm run dev"}
          lang="bash"
        />
      </div>

      {/* After install */}
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <h3 className="text-sm font-semibold text-hf-text-primary mb-3">Что делать после установки?</h3>
        <ol className="space-y-2">
          {[
            "Откройте http://localhost:5173 в браузере",
            "Перейдите в раздел ⚙️ Настройки",
            "Заполните данные профиля (ФИО, email, телефон)",
            "Укажите параметры поиска (запрос, регион, зарплата)",
            "Настройте шаблон сопроводительного письма",
            "Введите логины и пароли от hh.ru и Хабр Карьера",
            "Настройте режим имитации человека (задержки, stealth, прокси)",
            "Вернитесь на дашборд и нажмите «Запустить»",
          ].map((item, i) => (
            <li key={i} className="flex items-start gap-2.5">
              <span className="flex-shrink-0 w-5 h-5 rounded bg-hf-blue/20 border border-hf-blue/30 flex items-center justify-center text-[10px] font-bold text-hf-blue mt-0.5">
                {i + 1}
              </span>
              <span className="text-sm text-hf-text-secondary">{item}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Troubleshooting */}
      <div className="bg-hf-elevated border border-hf-red/20 rounded-[10px] p-5 shadow-card">
        <h3 className="text-sm font-semibold text-hf-text-primary mb-3 flex items-center gap-2">
          <AlertTriangle size={14} className="text-hf-red" />
          Возможные проблемы
        </h3>
        <div className="space-y-3">
          {[
            { q: "Ошибка 'command not found: npm'", a: "Установите Node.js с nodejs.org — npm входит в комплект" },
            { q: "Порт 5173 занят", a: "Запустите на другом порту: npm run dev -- --port 3000" },
            { q: "Ошибка 'Cannot find module'", a: "Удалите node_modules и package-lock.json, затем заново: npm install" },
            { q: "Браузер не открывается автоматически", a: "Откройте вручную: http://localhost:5173" },
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-3">
              <span className="text-xs text-hf-red font-medium flex-shrink-0 mt-0.5">{i + 1}.</span>
              <div>
                <p className="text-sm text-hf-text-primary font-medium">{item.q}</p>
                <p className="text-xs text-hf-text-secondary mt-0.5">{item.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Version info */}
      <div className="text-center py-4">
        <p className="text-xs text-hf-text-muted">
          Assistant Job <span className="text-hf-blue font-medium">v1.0.0</span> — Browser Automation Edition
        </p>
      </div>
    </div>
  );
}

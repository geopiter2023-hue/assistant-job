import { useState } from "react";
import {
  Clock,
  CheckCircle,
  XCircle,
  Calendar,
  Plus,
  Trash2,
  Bot,
  Play,
  Pause,
  RotateCcw,
  Zap,
  Shield,
  Globe,
  Search,
  ChevronDown,
  ChevronUp,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { tasksData } from "@/lib/data";
import type { BotTask } from "@/lib/data";
import PlatformBadge from "@/components/PlatformBadge";
import type { JobPlatform } from "@/lib/data";

const allPlatforms: { key: JobPlatform; label: string }[] = [
  { key: "hh", label: "HH.ru" },
  { key: "zarplata", label: "Зарплата.ру" },
  { key: "rabota", label: "Работа.ру" },
  { key: "superjob", label: "SuperJob" },
  { key: "yandex_smena", label: "Яндекс Смена" },
  { key: "karierist", label: "Карьерист.ру" },
  { key: "rabotaru", label: "Работа.ру" },
  { key: "avito", label: "Avito" },
  { key: "trudvsem", label: "Trudvsem.ru" },
  { key: "gorodrabot", label: "ГородРабот.ру" },
];

const intervalOptions = [
  { value: 5, label: "Каждые 5 минут" },
  { value: 10, label: "Каждые 10 минут" },
  { value: 15, label: "Каждые 15 минут" },
  { value: 30, label: "Каждые 30 минут" },
  { value: 60, label: "Каждый час" },
  { value: 120, label: "Каждые 2 часа" },
  { value: 240, label: "Каждые 4 часа" },
  { value: 480, label: "Каждые 8 часов" },
  { value: 720, label: "Каждые 12 часов" },
  { value: 1440, label: "Раз в день" },
];

function StatusIcon({ status }: { status: BotTask["status"] }) {
  switch (status) {
    case "running": return <Clock size={14} className="text-hf-cyan animate-spin" />;
    case "completed": return <CheckCircle size={14} className="text-hf-green" />;
    case "failed": return <XCircle size={14} className="text-hf-red" />;
    case "scheduled": return <Calendar size={14} className="text-hf-amber" />;
  }
}

function StatusBadge({ status }: { status: BotTask["status"] }) {
  const config = {
    running: { label: "Выполняется", bg: "bg-[#06B6D420]", text: "text-hf-cyan" },
    completed: { label: "Завершена", bg: "bg-[#10B98120]", text: "text-hf-green" },
    failed: { label: "Ошибка", bg: "bg-[#EF444420]", text: "text-hf-red" },
    scheduled: { label: "Запланирована", bg: "bg-[#F59E0B20]", text: "text-hf-amber" },
  };
  const c = config[status];
  return <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium", c.bg, c.text)}><StatusIcon status={status} />{c.label}</span>;
}

export default function Tasks() {
  const { user } = useAuth();
  const utils = trpc.useUtils();

  // Queries
  const { data: schedules = [] } = trpc.scheduler.list.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user, staleTime: 10000, refetchInterval: 30000 }
  );
  const { data: sessions = [] } = trpc.session.list.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user, staleTime: 10000 }
  );
  const { data: resumes = [] } = trpc.resume.list.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user }
  );

  // Mutations
  const createSchedule = trpc.scheduler.create.useMutation({
    onSuccess: () => { utils.scheduler.list.invalidate(); setShowCreate(false); }
  });
  const toggleSchedule = trpc.scheduler.toggle.useMutation({
    onSuccess: () => utils.scheduler.list.invalidate()
  });
  const deleteSchedule = trpc.scheduler.delete.useMutation({
    onSuccess: () => utils.scheduler.list.invalidate()
  });
  const runScheduleNow = trpc.scheduler.runNow.useMutation({
    onSuccess: (data) => {
      utils.scheduler.list.invalidate();
      utils.session.list.invalidate();
      setRunResult(data);
      setTimeout(() => setRunResult(null), 5000);
    }
  });
  const deleteSession = trpc.session.delete.useMutation({
    onSuccess: () => utils.session.list.invalidate()
  });

  // UI State
  const [showCreate, setShowCreate] = useState(false);
  const [expandedSchedule, setExpandedSchedule] = useState<number | null>(null);
  const [runResult, setRunResult] = useState<{ found: number; applied: number } | null>(null);

  // Form state
  const [formName, setFormName] = useState("");
  const [formKeywords, setFormKeywords] = useState("");
  const [formInterval, setFormInterval] = useState(30);
  const [formPlatforms, setFormPlatforms] = useState<string[]>(["hh"]);
  const [formResumeId, setFormResumeId] = useState<number | undefined>();
  const [formUseAi, setFormUseAi] = useState(true);
  const [formAutoApply, setFormAutoApply] = useState(false);
  const [formMaxApplies, setFormMaxApplies] = useState(10);
  const [formSalaryFrom, setFormSalaryFrom] = useState("");
  const [formSalaryTo, setFormSalaryTo] = useState("");
  const [formRemoteOnly, setFormRemoteOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const togglePlatform = (key: string) => {
    setFormPlatforms(prev =>
      prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]
    );
  };

  const selectAllPlatforms = () => {
    setFormPlatforms(allPlatforms.map(p => p.key));
  };

  const handleCreateSchedule = () => {
    if (!formName.trim() || !formKeywords.trim() || !user) return;
    createSchedule.mutate({
      userId: user.id,
      name: formName,
      keywords: formKeywords,
      intervalMinutes: formInterval,
      platforms: formPlatforms,
      resumeId: formResumeId,
      useAiPipeline: formUseAi,
      autoApply: formAutoApply,
      maxAppliesPerRun: formMaxApplies,
      filters: {
        salaryFrom: formSalaryFrom ? parseInt(formSalaryFrom) : undefined,
        salaryTo: formSalaryTo ? parseInt(formSalaryTo) : undefined,
        remoteOnly: formRemoteOnly,
      },
      isActive: true,
    });
    // Reset form
    setFormName(""); setFormKeywords(""); setFormInterval(30);
    setFormPlatforms(["hh"]); setFormResumeId(undefined);
    setFormUseAi(true); setFormAutoApply(false); setFormMaxApplies(10);
    setFormSalaryFrom(""); setFormSalaryTo(""); setFormRemoteOnly(false);
  };

  // Convert DB schedules to UI format
  const activeSchedules = schedules.filter((s: any) => s.isActive);

  // Convert DB sessions to BotTask format
  const tasks: BotTask[] = sessions.length > 0 ? sessions.map((s: any) => ({
    id: String(s.id), name: s.name, status: s.status as BotTask["status"],
    platform: s.platform as BotTask["platform"],
    query: s.query, resultsFound: s.resultsFound ?? 0, appliesSent: s.appliesSent ?? 0,
    createdAt: s.createdAt ? new Date(s.createdAt).toLocaleString("ru-RU") : "",
    completedAt: s.completedAt ? new Date(s.completedAt).toLocaleString("ru-RU") : undefined,
    emulationMode: s.emulationMode ?? true,
  })) : tasksData;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-hf-text-primary">Автоматический поиск</h2>
          <p className="text-sm text-hf-text-secondary mt-0.5">
            Расписания мониторинга вакансий и авто-откликов
            {activeSchedules.length > 0 && (
              <span className="ml-2 text-hf-cyan font-medium">• {activeSchedules.length} активно</span>
            )}
          </p>
        </div>
        {user && (
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="flex items-center gap-2 px-4 py-2.5 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all self-start shadow-lg shadow-hf-red/20"
          >
            <Plus size={16} />Новое расписание
          </button>
        )}
      </div>

      {/* Create Schedule Form */}
      {showCreate && (
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-5 shadow-card space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-hf-border-subtle">
            <Zap size={18} className="text-hf-amber" />
            <h3 className="text-sm font-semibold text-hf-text-primary">Создать расписание поиска</h3>
          </div>

          {/* Name */}
          <div>
            <label className="block text-xs text-hf-text-secondary mb-1.5">Название расписания</label>
            <input
              type="text"
              placeholder="Например: Поиск Python разработчиков"
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2.5 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
            />
          </div>

          {/* Keywords */}
          <div>
            <label className="block text-xs text-hf-text-secondary mb-1.5">Ключевые слова поиска</label>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
              <input
                type="text"
                placeholder="Python разработчик"
                value={formKeywords}
                onChange={(e) => setFormKeywords(e.target.value)}
                className="w-full bg-hf-base border border-hf-border-subtle rounded-lg pl-9 pr-3 py-2.5 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
              />
            </div>
          </div>

          {/* Interval */}
          <div>
            <label className="block text-xs text-hf-text-secondary mb-1.5">Интервал проверки</label>
            <select
              value={formInterval}
              onChange={(e) => setFormInterval(Number(e.target.value))}
              className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2.5 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors"
            >
              {intervalOptions.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>

          {/* Platforms */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs text-hf-text-secondary">Площадки для поиска</label>
              <button onClick={selectAllPlatforms} className="text-xs text-hf-red hover:underline">Выбрать все</button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {allPlatforms.map(p => (
                <button
                  key={p.key}
                  onClick={() => togglePlatform(p.key)}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium border transition-all",
                    formPlatforms.includes(p.key)
                      ? "bg-hf-red/15 border-hf-red/40 text-hf-red"
                      : "bg-hf-base border-hf-border-subtle text-hf-text-secondary hover:border-hf-text-muted"
                  )}
                >
                  {formPlatforms.includes(p.key) ? <CheckCircle size={12} /> : <Globe size={12} />}
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Resume */}
          {resumes.length > 0 && (
            <div>
              <label className="block text-xs text-hf-text-secondary mb-1.5">Резюме для отклика</label>
              <select
                value={formResumeId ?? ""}
                onChange={(e) => setFormResumeId(e.target.value ? Number(e.target.value) : undefined)}
                className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2.5 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors"
              >
                <option value="">— Выберите резюме —</option>
                {resumes.map((r: any) => (
                  <option key={r.id} value={r.id}>{r.title}{r.isDefault ? " (по умолчанию)" : ""}</option>
                ))}
              </select>
            </div>
          )}

          {/* Filters toggle */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1.5 text-xs text-hf-text-secondary hover:text-hf-text-primary transition-colors"
          >
            <Settings size={12} />
            Фильтры
            {showFilters ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>

          {showFilters && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-hf-base/50 rounded-lg border border-hf-border-subtle">
              <div>
                <label className="block text-xs text-hf-text-secondary mb-1">Зарплата от, ₽</label>
                <input
                  type="number"
                  placeholder="100000"
                  value={formSalaryFrom}
                  onChange={(e) => setFormSalaryFrom(e.target.value)}
                  className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red"
                />
              </div>
              <div>
                <label className="block text-xs text-hf-text-secondary mb-1">Зарплата до, ₽</label>
                <input
                  type="number"
                  placeholder="500000"
                  value={formSalaryTo}
                  onChange={(e) => setFormSalaryTo(e.target.value)}
                  className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red"
                />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2 cursor-pointer pb-2">
                  <input
                    type="checkbox"
                    checked={formRemoteOnly}
                    onChange={(e) => setFormRemoteOnly(e.target.checked)}
                    className="rounded border-hf-border-subtle"
                  />
                  <span className="text-xs text-hf-text-secondary">Только удалённо</span>
                </label>
              </div>
            </div>
          )}

          {/* AI & Auto-apply toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="flex items-center gap-3 p-3 bg-hf-base/50 rounded-lg border border-hf-border-subtle cursor-pointer hover:border-hf-red/30 transition-colors">
              <div className={cn("w-10 h-6 rounded-full flex items-center px-0.5 transition-colors", formUseAi ? "bg-hf-red justify-end" : "bg-hf-border-subtle justify-start")}>
                <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
              </div>
              <input type="checkbox" checked={formUseAi} onChange={(e) => setFormUseAi(e.target.checked)} className="sr-only" />
              <div>
                <div className="text-sm font-medium text-hf-text-primary flex items-center gap-1.5"><Bot size={13} className="text-hf-cyan" />AI-пайплайн</div>
                <div className="text-xs text-hf-text-secondary">Анализ + адаптация резюме + письмо</div>
              </div>
            </label>

            <label className={cn("flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors", formAutoApply ? "bg-hf-green/5 border-hf-green/30" : "bg-hf-base/50 border-hf-border-subtle hover:border-hf-border-subtle")}>
              <div className={cn("w-10 h-6 rounded-full flex items-center px-0.5 transition-colors", formAutoApply ? "bg-hf-green justify-end" : "bg-hf-border-subtle justify-start")}>
                <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
              </div>
              <input type="checkbox" checked={formAutoApply} onChange={(e) => setFormAutoApply(e.target.checked)} className="sr-only" />
              <div>
                <div className="text-sm font-medium text-hf-text-primary flex items-center gap-1.5"><Zap size={13} className={formAutoApply ? "text-hf-green" : "text-hf-text-muted"} />{formAutoApply ? "Авто-отклик" : "Ручное подтверждение"}</div>
                <div className="text-xs text-hf-text-secondary">{formAutoApply ? "Отклик без одобрения" : "Черновик → ваше одобрение → отклик"}</div>
              </div>
            </label>
          </div>

          {/* Max applies */}
          <div>
            <label className="block text-xs text-hf-text-secondary mb-1.5">Макс. откликов за запуск: <span className="text-hf-text-primary font-medium">{formMaxApplies}</span></label>
            <input
              type="range"
              min={1}
              max={50}
              value={formMaxApplies}
              onChange={(e) => setFormMaxApplies(Number(e.target.value))}
              className="w-full accent-hf-red"
            />
            <div className="flex justify-between text-xs text-hf-text-muted mt-0.5">
              <span>1</span><span>10</span><span>25</span><span>50</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <button
              onClick={handleCreateSchedule}
              disabled={!formName.trim() || !formKeywords.trim() || createSchedule.isPending}
              className="flex items-center gap-2 px-5 py-2.5 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {createSchedule.isPending ? <Clock size={16} className="animate-spin" /> : <Zap size={16} />}
              Создать и запустить
            </button>
            <button
              onClick={() => setShowCreate(false)}
              className="px-5 py-2.5 bg-hf-base text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary transition-colors"
            >
              Отмена
            </button>
          </div>
        </div>
      )}

      {/* Run Result */}
      {runResult && (
        <div className="bg-hf-green/10 border border-hf-green/30 rounded-[10px] p-4 flex items-center gap-3">
          <CheckCircle size={20} className="text-hf-green flex-shrink-0" />
          <div>
            <p className="text-sm font-medium text-hf-green">Запуск выполнен!</p>
            <p className="text-xs text-hf-text-secondary">Найдено: {runResult.found} вакансий, отправлено: {runResult.applied} откликов</p>
          </div>
        </div>
      )}

      {/* Schedules List */}
      {schedules.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-hf-text-primary flex items-center gap-2">
            <Calendar size={15} /> Расписания ({schedules.length})
          </h3>

          {schedules.map((schedule: any) => {
            const isExpanded = expandedSchedule === schedule.id;
            const nextRun = schedule.nextRunAt ? new Date(schedule.nextRunAt) : null;
            const lastRun = schedule.lastRunAt ? new Date(schedule.lastRunAt) : null;
            const platforms: string[] = (schedule.platforms as string[]) ?? ["hh"];

            return (
              <div
                key={schedule.id}
                className={cn(
                  "bg-hf-elevated border rounded-[10px] shadow-card transition-all",
                  schedule.isActive ? "border-hf-red/30" : "border-hf-border-subtle"
                )}
              >
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-hf-text-primary">{schedule.name}</span>
                        {schedule.isActive ? (
                          <span className="inline-flex items-center gap-1 text-xs text-hf-cyan bg-hf-cyan/10 px-2 py-0.5 rounded-full">
                            <Bot size={10} /> Активно
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-hf-text-muted bg-hf-base px-2 py-0.5 rounded-full">
                            <Pause size={10} /> Остановлено
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5">
                        <span className="text-xs text-hf-text-secondary flex items-center gap-1"><Search size={10} />{schedule.keywords}</span>
                        <span className="text-xs text-hf-text-secondary flex items-center gap-1"><Clock size={10} />{intervalOptions.find(o => o.value === schedule.intervalMinutes)?.label ?? `Каждые ${schedule.intervalMinutes} мин`}</span>
                        {nextRun && schedule.isActive && (
                          <span className="text-xs text-hf-amber flex items-center gap-1"><Calendar size={10} />Следующий: {nextRun.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}</span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {platforms.slice(0, 5).map(p => (
                          <PlatformBadge key={p} platform={p as JobPlatform} />
                        ))}
                        {platforms.length > 5 && (
                          <span className="text-xs text-hf-text-muted">+{platforms.length - 5}</span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button
                        onClick={() => runScheduleNow.mutate({ id: schedule.id })}
                        disabled={runScheduleNow.isPending}
                        className="p-2 text-hf-green hover:bg-hf-green/10 rounded-lg transition-colors"
                        title="Запустить сейчас"
                      >
                        <Play size={15} />
                      </button>
                      <button
                        onClick={() => toggleSchedule.mutate({ id: schedule.id })}
                        className={cn(
                          "p-2 rounded-lg transition-colors",
                          schedule.isActive ? "text-hf-amber hover:bg-hf-amber/10" : "text-hf-green hover:bg-hf-green/10"
                        )}
                        title={schedule.isActive ? "Остановить" : "Запустить"}
                      >
                        {schedule.isActive ? <Pause size={15} /> : <Play size={15} />}
                      </button>
                      <button
                        onClick={() => setExpandedSchedule(isExpanded ? null : schedule.id)}
                        className="p-2 text-hf-text-muted hover:text-hf-text-primary hover:bg-hf-base rounded-lg transition-colors"
                      >
                        {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                      </button>
                      <button
                        onClick={() => { if (confirm("Удалить расписание?")) deleteSchedule.mutate({ id: schedule.id }); }}
                        className="p-2 text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 rounded-lg transition-colors"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div className="border-t border-hf-border-subtle px-4 py-3 space-y-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      <div className="bg-hf-base/50 rounded-lg p-2.5">
                        <span className="text-hf-text-muted">Всего запусков</span>
                        <p className="text-hf-text-primary font-semibold text-sm mt-0.5">{schedule.totalRuns ?? 0}</p>
                      </div>
                      <div className="bg-hf-base/50 rounded-lg p-2.5">
                        <span className="text-hf-text-muted">Всего откликов</span>
                        <p className="text-hf-text-primary font-semibold text-sm mt-0.5">{schedule.totalApplies ?? 0}</p>
                      </div>
                      <div className="bg-hf-base/50 rounded-lg p-2.5">
                        <span className="text-hf-text-muted">Макс за запуск</span>
                        <p className="text-hf-text-primary font-semibold text-sm mt-0.5">{schedule.maxAppliesPerRun ?? 10}</p>
                      </div>
                      <div className="bg-hf-base/50 rounded-lg p-2.5">
                        <span className="text-hf-text-muted">Последний запуск</span>
                        <p className="text-hf-text-primary font-semibold text-sm mt-0.5">{lastRun ? lastRun.toLocaleString("ru-RU", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—"}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs">
                      {schedule.useAiPipeline && (
                        <span className="inline-flex items-center gap-1 text-hf-cyan bg-hf-cyan/10 px-2 py-1 rounded"><Bot size={10} />AI-пайплайн</span>
                      )}
                      {schedule.autoApply ? (
                        <span className="inline-flex items-center gap-1 text-hf-green bg-hf-green/10 px-2 py-1 rounded"><Zap size={10} />Авто-отклик</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-hf-amber bg-hf-amber/10 px-2 py-1 rounded"><Shield size={10} />Ручное подтверждение</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Sessions History */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-hf-text-primary flex items-center gap-2">
          <RotateCcw size={15} /> История запусков ({tasks.length})
        </h3>

        {/* Desktop table */}
        <div className="hidden md:block bg-hf-elevated border border-hf-border-subtle rounded-[10px] shadow-card overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-hf-border-subtle">
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАПУСК</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">ЗАПРОС</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ПЛОЩАДКА</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">НАЙДЕНО</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">ОТКЛИКОВ</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-left px-5 py-3">СТАТУС</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3">РЕЖИМ</th>
                <th className="text-xs uppercase text-hf-text-secondary font-medium text-center px-5 py-3 w-[50px]"></th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((t) => (
                <tr key={t.id} className="border-b border-hf-border-subtle last:border-b-0 hover:bg-[#1E2A4260] transition-colors">
                  <td className="px-5 py-3.5 text-sm text-hf-text-primary font-medium">{t.name}</td>
                  <td className="px-5 py-3.5 text-sm text-hf-text-secondary">{t.query}</td>
                  <td className="px-5 py-3.5 text-center"><PlatformBadge platform={t.platform as JobPlatform} /></td>
                  <td className="px-5 py-3.5 text-sm text-hf-text-primary text-center">{t.resultsFound}</td>
                  <td className="px-5 py-3.5 text-sm text-hf-text-primary text-center">{t.appliesSent}</td>
                  <td className="px-5 py-3.5"><StatusBadge status={t.status} /></td>
                  <td className="px-5 py-3.5 text-center"><span className="inline-flex items-center gap-1 text-xs text-hf-amber bg-hf-amber/10 px-2 py-0.5 rounded"><Bot size={10} />Браузер</span></td>
                  <td className="px-5 py-3.5 text-center"><button onClick={() => deleteSession.mutate({ id: Number(t.id) })} className="text-hf-text-muted hover:text-hf-red transition-colors p-1"><Trash2 size={14} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="md:hidden space-y-3">
          {tasks.map((t) => (
            <div key={t.id} className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm text-hf-text-primary font-medium">{t.name}</span>
                    <StatusBadge status={t.status} />
                  </div>
                  <p className="text-xs text-hf-text-secondary mt-1">{t.query}</p>
                </div>
                <button onClick={() => deleteSession.mutate({ id: Number(t.id) })} className="text-hf-text-muted hover:text-hf-red transition-colors flex-shrink-0 p-1">
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-3 mt-3">
                <PlatformBadge platform={t.platform as JobPlatform} />
                <span className="text-xs text-hf-text-secondary">{t.resultsFound} найдено</span>
                <span className="text-xs text-hf-text-secondary">{t.appliesSent} откликов</span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className="inline-flex items-center gap-1 text-xs text-hf-amber bg-hf-amber/10 px-2 py-0.5 rounded"><Bot size={10} />Имитация человека</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Info */}
      <div className="flex items-start gap-2.5 p-3 bg-hf-cyan/5 rounded-lg border border-hf-cyan/10">
        <Bot size={14} className="text-hf-cyan flex-shrink-0 mt-0.5" />
        <p className="text-xs text-hf-text-secondary">
          Фоновый воркер проверяет расписания каждую минуту. При достижении времени запуска — выполняет поиск вакансий на выбранных площадках, запускает AI-пайплайн и отправляет отклики. Все действия выполняются в режиме имитации человека через браузер.
        </p>
      </div>
    </div>
  );
}

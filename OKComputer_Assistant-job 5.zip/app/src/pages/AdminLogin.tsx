import { useState } from "react";
import { Shield, Eye, EyeOff, Loader, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loginMutation = trpc.admin.login.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        localStorage.setItem("aj_admin_token", data.token);
        window.location.hash = "#/ushakov/dashboard";
        window.location.reload();
      } else {
        setError(data.message || "Ошибка входа");
      }
    },
    onError: (err) => {
      setError(err.message || "Ошибка сервера");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!username.trim() || !password.trim()) return;
    loginMutation.mutate({ username, password });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F3F4F6] p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#D6001C] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-red-200">
            <Shield size={32} className="text-white" />
          </div>
          <h1 className="text-xl font-bold text-[#333333]">Assistant Job</h1>
          <p className="text-sm text-[#999999] mt-1">Панель администратора</p>
          <p className="text-xs text-[#999999] mt-0.5">/ushakov</p>
        </div>

        {/* Login form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-xl p-6 space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
              <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-red-600">{error}</p>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#666666] uppercase tracking-wider">Логин</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
              className="w-full bg-[#F8F8F8] border border-[#E5E5E5] rounded-lg px-3 py-2.5 text-sm text-[#333] placeholder:text-[#BBBBBB] focus:outline-none focus:border-[#D6001C] transition-colors"
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-medium text-[#666666] uppercase tracking-wider">Пароль</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-[#F8F8F8] border border-[#E5E5E5] rounded-lg px-3 py-2.5 pr-10 text-sm text-[#333] placeholder:text-[#BBBBBB] focus:outline-none focus:border-[#D6001C] transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-[#BBBBBB] hover:text-[#666] p-1"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loginMutation.isPending}
            className={cn(
              "w-full py-3 rounded-lg text-sm font-bold text-white transition-all flex items-center justify-center gap-2",
              loginMutation.isPending
                ? "bg-[#999] cursor-wait"
                : "bg-[#D6001C] hover:brightness-110 shadow-lg shadow-red-200"
            )}
          >
            {loginMutation.isPending ? (
              <><Loader size={16} className="animate-spin" /> Вход...</>
            ) : (
              <><Shield size={16} /> Войти</>
            )}
          </button>
        </form>

        <p className="text-center text-xs text-[#BBBBBB] mt-6">
          Assistant Job Admin v1.0
        </p>
      </div>
    </div>
  );
}

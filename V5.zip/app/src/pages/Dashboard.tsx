import { useState } from "react";
import { Search, Play, Settings, FileText, Zap, Bot, CheckCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router";

/*
 * ==========================================
 * УПРОЩЁННЫЙ ДАШБОРД = ПОИСК
 * ==========================================
 * Объединено: Дашборд + Вакансии + AI Отклики + Задачи
 * Одна кнопка: "Найти и откликнуться"
 */

export default function Dashboard() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [showResult, setShowResult] = useState(false);

  // Quick stats (demo)
  const stats = {
    totalApplies: 247,
    todayApplies: 12,
    successRate: "87%",
  };

  const handleSearch = () => {
    if (!query.trim()) return;
    setIsSearching(true);
    setShowResult(false);
    // Simulate search + AI pipeline + apply
    setTimeout(() => {
      setIsSearching(false);
      setShowResult(true);
    }, 2500);
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      {/* Title */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-hf-text-primary">Найти вакансии</h1>
        <p className="text-sm text-hf-text-secondary mt-1">
          Введите должность — система найдёт вакансии, проанализирует их и откликнется за вас
        </p>
      </div>

      {/* Search Box */}
      <div className="bg-white border border-hf-border-subtle rounded-[12px] p-5 shadow-card">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-hf-text-muted" />
            <input
              type="text"
              placeholder="Python разработчик, QA инженер, Product Manager..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full bg-hf-highlight border border-hf-border-subtle rounded-lg pl-10 pr-4 py-3 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
            />
          </div>
        </div>

        {/* ONE BUTTON */}
        <button
          onClick={handleSearch}
          disabled={!query.trim() || isSearching}
          className={cn(
            "w-full mt-4 py-3.5 rounded-lg text-sm font-bold text-white transition-all duration-200 flex items-center justify-center gap-2",
            isSearching
              ? "bg-hf-text-muted cursor-wait"
              : "bg-hf-red hover:brightness-110 active:scale-[0.98] shadow-lg shadow-hf-red/25"
          )}
        >
          {isSearching ? (
            <>
              <Clock size={16} className="animate-spin" />
              Ищем вакансии → Анализируем → Откликаемся...
            </>
          ) : (
            <>
              <Zap size={16} />
              Найти и откликнуться
            </>
          )}
        </button>

        {/* What happens */}
        <div className="flex items-center justify-center gap-4 mt-3">
          <span className="flex items-center gap-1 text-[10px] text-hf-text-muted">
            <Search size={10} /> Поиск
          </span>
          <span className="text-hf-text-muted">→</span>
          <span className="flex items-center gap-1 text-[10px] text-hf-text-muted">
            <Bot size={10} /> AI-анализ
          </span>
          <span className="text-hf-text-muted">→</span>
          <span className="flex items-center gap-1 text-[10px] text-hf-text-muted">
            <FileText size={10} /> Резюме + письмо
          </span>
          <span className="text-hf-text-muted">→</span>
          <span className="flex items-center gap-1 text-[10px] text-hf-text-muted">
            <Play size={10} /> Отклик
          </span>
        </div>
      </div>

      {/* Quick links */}
      <div className="flex gap-3 justify-center">
        <button
          onClick={() => navigate("/settings")}
          className="flex items-center gap-2 px-4 py-2.5 bg-white border border-hf-border-subtle rounded-lg text-sm text-hf-text-secondary hover:text-hf-text-primary hover:border-hf-red/30 transition-all shadow-card"
        >
          <Settings size={16} /> Настроить площадки
        </button>
        <button
          onClick={() => navigate("/resumes")}
          className="flex items-center gap-2 px-4 py-2.5 bg-white border border-hf-border-subtle rounded-lg text-sm text-hf-text-secondary hover:text-hf-text-primary hover:border-hf-red/30 transition-all shadow-card"
        >
          <FileText size={16} /> Мои резюме
        </button>
      </div>

      {/* Result card */}
      {showResult && (
        <div className="bg-hf-green/5 border border-hf-green/20 rounded-[10px] p-5 animate-fade-in-up">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle size={20} className="text-hf-green" />
            <h3 className="text-sm font-bold text-hf-green">Готово! Отклики отправлены</h3>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-white rounded-lg p-3">
              <p className="text-xl font-bold text-hf-red">7</p>
              <p className="text-[10px] text-hf-text-secondary">вакансий найдено</p>
            </div>
            <div className="bg-white rounded-lg p-3">
              <p className="text-xl font-bold text-hf-green">5</p>
              <p className="text-[10px] text-hf-text-secondary">откликов отправлено</p>
            </div>
            <div className="bg-white rounded-lg p-3">
              <p className="text-xl font-bold text-hf-blue">2</p>
              <p className="text-[10px] text-hf-text-secondary">на рассмотрении</p>
            </div>
          </div>
          <button
            onClick={() => navigate("/applies")}
            className="w-full mt-3 py-2 bg-hf-green text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all"
          >
            Смотреть мои отклики
          </button>
        </div>
      )}

      {/* Mini stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 text-center shadow-card">
          <p className="text-2xl font-bold text-hf-red">{stats.totalApplies}</p>
          <p className="text-[10px] text-hf-text-secondary uppercase tracking-wider mt-1">Всего откликов</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 text-center shadow-card">
          <p className="text-2xl font-bold text-hf-green">{stats.todayApplies}</p>
          <p className="text-[10px] text-hf-text-secondary uppercase tracking-wider mt-1">Сегодня</p>
        </div>
        <div className="bg-white border border-hf-border-subtle rounded-[10px] p-4 text-center shadow-card">
          <p className="text-2xl font-bold text-hf-blue">{stats.successRate}</p>
          <p className="text-[10px] text-hf-text-secondary uppercase tracking-wider mt-1">Успешных</p>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Plus, Trash2, Pencil, Star, Check, X, Download, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";

interface Resume {
  id: string;
  title: string;
  summary: string;
  skills: string;
  experience: string;
  education: string;
  languages: string;
  desiredSalary: string;
  desiredPosition: string;
  isDefault: boolean;
  source?: "manual" | "hh";
}

// Реальные резюме загружаются из БД через tRPC

function ResumeCard({ resume, onEdit, onDelete, onSetDefault }: {
  resume: Resume;
  onEdit: (r: Resume) => void;
  onDelete: (id: string) => void;
  onSetDefault: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className={cn(
      "bg-hf-elevated border rounded-[10px] shadow-card transition-all",
      resume.isDefault ? "border-hf-red/40 shadow-[0_0_12px_rgba(59,130,246,0.08)]" : "border-hf-border-subtle"
    )}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm font-semibold text-hf-text-primary">{resume.title}</h3>
              {resume.isDefault && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-hf-red/20 text-hf-red border border-hf-red/30">
                  <Star size={10} /> По умолчанию
                </span>
              )}
              {resume.source === "hh" && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-hf-red/10 text-hf-red border border-hf-red/20">
                  <Globe size={10} /> HH.ru
                </span>
              )}
            </div>
            <p className="text-xs text-hf-text-secondary mt-1 line-clamp-2">{resume.summary}</p>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {!resume.isDefault && (
              <button onClick={() => onSetDefault(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-amber hover:bg-hf-amber/10 transition-colors" title="Сделать основным">
                <Star size={14} />
              </button>
            )}
            <button onClick={() => onEdit(resume)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 transition-colors" title="Редактировать">
              <Pencil size={14} />
            </button>
            <button onClick={() => onDelete(resume.id)} className="p-1.5 rounded-md text-hf-text-muted hover:text-hf-red hover:bg-hf-red/10 transition-colors" title="Удалить">
              <Trash2 size={14} />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {resume.skills.split(",").slice(0, 6).map((s) => (
            <span key={s.trim()} className="text-[11px] text-hf-text-secondary bg-hf-base px-2 py-0.5 rounded border border-hf-border-subtle">{s.trim()}</span>
          ))}
          {resume.skills.split(",").length > 6 && <span className="text-[11px] text-hf-text-muted">+{resume.skills.split(",").length - 6}</span>}
        </div>

        <button onClick={() => setExpanded(!expanded)} className="text-xs text-hf-red hover:underline mt-3 transition-colors">
          {expanded ? "Скрыть детали" : "Показать детали"}
        </button>

        {expanded && (
          <div className="mt-3 space-y-3 pt-3 border-t border-hf-border-subtle">
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</p><p className="text-xs text-hf-text-primary mt-1 whitespace-pre-line">{resume.experience}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</p><p className="text-xs text-hf-text-primary mt-1">{resume.education}</p></div>
            <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</p><p className="text-xs text-hf-text-primary mt-1">{resume.languages}</p></div>
            <div className="flex gap-4">
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Зарплата</p><p className="text-xs text-hf-green font-medium mt-1">{resume.desiredSalary}</p></div>
              <div><p className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Позиция</p><p className="text-xs text-hf-text-primary mt-1">{resume.desiredPosition}</p></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ResumeForm({ initial, onSave, onCancel }: {
  initial?: Resume;
  onSave: (data: Omit<Resume, "id">) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    title: initial?.title ?? "",
    summary: initial?.summary ?? "",
    skills: initial?.skills ?? "",
    experience: initial?.experience ?? "",
    education: initial?.education ?? "",
    languages: initial?.languages ?? "",
    desiredSalary: initial?.desiredSalary ?? "",
    desiredPosition: initial?.desiredPosition ?? "",
    isDefault: initial?.isDefault ?? false,
  });

  return (
    <div className="bg-hf-elevated border border-hf-red/30 rounded-[10px] p-5 shadow-card">
      <h3 className="text-sm font-semibold text-hf-text-primary mb-4">{initial ? "✏️ Редактировать резюме" : "➕ Новое резюме"}</h3>
      <div className="space-y-3">
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Название резюме</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="Python разработчик" /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Краткое описание</label><textarea value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} rows={3} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="О себе..." /></div>
        <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Навыки (через запятую)</label><textarea value={form.skills} onChange={(e) => setForm({ ...form, skills: e.target.value })} rows={2} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="Python, Django..." /></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label><textarea value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} rows={4} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red resize-none" placeholder="Должность, компания..." /></div>
          <div className="space-y-3">
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Образование</label><input value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" /></div>
            <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Языки</label><input value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" /></div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Ожидаемая зарплата</label><input value={form.desiredSalary} onChange={(e) => setForm({ ...form, desiredSalary: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="300 000 - 500 000 ₽" /></div>
          <div><label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Желаемая позиция</label><input value={form.desiredPosition} onChange={(e) => setForm({ ...form, desiredPosition: e.target.value })} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 focus:outline-none focus:border-hf-red" placeholder="Senior Python Developer" /></div>
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" checked={form.isDefault} onChange={(e) => setForm({ ...form, isDefault: e.target.checked })} className="accent-hf-red" />
          <span className="text-sm text-hf-text-primary">Использовать по умолчанию</span>
        </label>
        <div className="flex gap-2 pt-2">
          <button onClick={() => onSave(form)} className="flex items-center gap-2 px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110"><Check size={14} />{initial ? "Сохранить" : "Создать"}</button>
          <button onClick={onCancel} className="px-4 py-2 bg-hf-base text-hf-text-secondary text-sm font-medium rounded-lg border border-hf-border-subtle hover:text-hf-text-primary"><X size={14} className="inline mr-1" />Отмена</button>
        </div>
      </div>
    </div>
  );
}

// ─── HH Import Modal ───
function HhImportModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<"token" | "loading" | "list" | "done">("token");
  const [accessToken, setAccessToken] = useState("");
  const [hhResumes, setHhResumes] = useState<Array<{ id: string; title: string; url: string; skills: string; salary: string; lastUpdated: string }>>([]);
  const [error, setError] = useState("");

  const importMutation = trpc.resume.importFromHh.useMutation({
    onSuccess: () => {
      setStep("done");
    },
    onError: (err) => {
      setError(err.message);
      setStep("token");
    }
  });

  const handleLoadResumes = async () => {
    if (!accessToken.trim()) { setError("Введите access token"); return; }
    setError("");
    setStep("loading");

    try {
      // Реальный запрос к HH.ru API
      const response = await fetch("https://api.hh.ru/resumes/mine", {
        headers: {
          "Authorization": `Bearer ${accessToken}`,
          "User-Agent": "AssistantJob/1.0",
          "Accept": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Ошибка API HH.ru: ${response.status}. Проверьте токен.`);
      }

      const data = await response.json();
      const items = (data.items || []).map((item: any) => ({
        id: item.id,
        title: item.title || "Без названия",
        url: item.alternate_url || `https://hh.ru/resume/${item.id}`,
        skills: (item.skill_set || []).join(", "),
        salary: item.salary
          ? `${item.salary.from ? item.salary.from + " ₽" : ""}${item.salary.to ? " — " + item.salary.to + " ₽" : ""}`
          : "Не указана",
        lastUpdated: item.updated_at
          ? new Date(item.updated_at).toLocaleDateString("ru-RU")
          : "",
      }));

      setHhResumes(items);
      setStep(items.length > 0 ? "list" : "done");
    } catch (err: any) {
      setError(err.message || "Ошибка загрузки. Проверьте токен.");
      setStep("token");
    }
  };

  const handleImportSelected = () => {
    importMutation.mutate({ userId: 1, accessToken });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-hf-elevated border border-hf-border-subtle rounded-[14px] p-6 max-w-lg w-full shadow-2xl max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-hf-red/10 border border-hf-red/20 flex items-center justify-center">
              <Globe size={16} className="text-hf-red" />
            </div>
            <div>
              <h3 className="text-base font-bold text-hf-text-primary">Импорт с HH.ru</h3>
              <p className="text-xs text-hf-text-secondary">Реальные данные из вашего аккаунта</p>
            </div>
          </div>
          <button onClick={onClose} className="text-hf-text-muted hover:text-hf-text-primary transition-colors p-1"><X size={20} /></button>
        </div>

        {/* Step 1: Token */}
        {step === "token" && (
          <div className="space-y-4">
            <div className="bg-hf-base rounded-lg p-4 border border-hf-border-subtle">
              <p className="text-xs text-hf-text-secondary mb-3">
                Для импорта нужен <strong>access token</strong> от HH.ru API. 
                Это безопаснее логина/пароля — мы не храним ваши данные.
              </p>
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Access Token HH.ru</label>
                  <input
                    type="text"
                    value={accessToken}
                    onChange={(e) => { setAccessToken(e.target.value); setError(""); }}
                    placeholder="ABCDEF123456..."
                    className="w-full bg-hf-elevated border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary mt-1 placeholder:text-hf-text-muted"
                  />
                </div>
              </div>
              {error && <p className="text-xs text-hf-red mt-2">{error}</p>}

              {/* Instructions */}
              <details className="mt-3">
                <summary className="text-xs text-hf-blue cursor-pointer">Как получить access token?</summary>
                <div className="mt-2 text-[11px] text-hf-text-secondary space-y-1 bg-hf-highlight rounded p-3">
                  <p>1. Зайдите на <a href="https://dev.hh.ru/admin" target="_blank" rel="noopener" className="text-hf-blue underline">dev.hh.ru/admin</a></p>
                  <p>2. Создайте приложение (если нет)</p>
                  <p>3. Получите токен через OAuth или запросите у поддержки</p>
                  <p className="text-hf-amber">⚠ Без токена импорт работает в демо-режиме</p>
                </div>
              </details>
            </div>
            <button
              onClick={handleLoadResumes}
              className="w-full py-2.5 rounded-lg text-sm font-medium text-white bg-hf-red hover:brightness-110 transition-all"
            >
              Загрузить мои резюме
            </button>
          </div>
        )}

        {/* Step 2: Loading */}
        {step === "loading" && (
          <div className="text-center py-8 space-y-4">
            <div className="relative w-16 h-16 mx-auto">
              <div className="absolute inset-0 rounded-full border-4 border-hf-border-subtle" />
              <div className="absolute inset-0 rounded-full border-4 border-hf-red border-t-transparent animate-spin" />
              <Globe size={24} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-hf-red" />
            </div>
            <div>
              <p className="text-sm text-hf-text-primary font-medium">Загрузка резюме с HH.ru...</p>
              <p className="text-xs text-hf-text-secondary mt-1">Подключение к API</p>
            </div>
          </div>
        )}

        {/* Step 3: List */}
        {step === "list" && (
          <div className="space-y-3">
            <p className="text-xs text-hf-text-secondary">
              Найдено <span className="text-hf-text-primary font-medium">{hhResumes.length}</span> резюме:
            </p>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {hhResumes.map((r) => (
                <div key={r.id} className="flex items-center justify-between p-3 rounded-lg border border-hf-border-subtle">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-hf-text-primary font-medium truncate">{r.title}</p>
                    <p className="text-xs text-hf-text-secondary mt-0.5">{r.salary}</p>
                    {r.skills && <p className="text-[10px] text-hf-text-muted mt-0.5 truncate">{r.skills}</p>}
                  </div>
                  <div className="text-right flex-shrink-0 ml-3">
                    <p className="text-[10px] text-hf-text-muted">{r.lastUpdated}</p>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={handleImportSelected}
              disabled={importMutation.isPending}
              className="w-full py-2.5 rounded-lg text-sm font-medium text-white bg-hf-red hover:brightness-110 transition-all disabled:opacity-50"
            >
              {importMutation.isPending ? "Импорт..." : `Импортировать ${hhResumes.length} резюме`}
            </button>
          </div>
        )}

        {/* Step 4: Done */}
        {step === "done" && (
          <div className="text-center py-6 space-y-4">
            <Check size={48} className="text-hf-green mx-auto" />
            <div>
              <p className="text-sm font-bold text-hf-green">Готово!</p>
              <p className="text-xs text-hf-text-secondary mt-1">
                {importMutation.data?.imported ?? hhResumes.length} резюме импортировано
              </p>
            </div>
            <button onClick={onClose} className="px-6 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all">
              Закрыть
            </button>
          </div>
        )}

        {/* Preview step removed — now auto-import all */}
      </div>
    </div>
  );
}

export default function Resumes() {
  const { user } = useAuth();
  const { data: dbResumes = [] } = trpc.resume.list.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user }
  );
  const [resumesList, setResumesList] = useState<Resume[]>([]);

  // Sync with DB
  useEffect(() => {
    if (dbResumes.length > 0) {
      setResumesList(dbResumes.map((r: any) => ({ ...r, id: String(r.id) })));
    }
  }, [dbResumes]);
  const [editing, setEditing] = useState<Resume | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showHhImport, setShowHhImport] = useState(false);

  const handleCreate = (data: Omit<Resume, "id">) => {
    const newResume: Resume = { ...data, id: String(Date.now()), source: "manual" };
    if (data.isDefault) setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: false })).concat(newResume));
    else setResumesList((prev) => [...prev, newResume]);
    setShowCreate(false);
  };

  const handleUpdate = (data: Omit<Resume, "id">) => {
    if (!editing) return;
    if (data.isDefault) setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : { ...r, isDefault: false })));
    else setResumesList((prev) => prev.map((r) => (r.id === editing.id ? { ...data, id: editing.id } : r)));
    setEditing(null);
  };

  const handleDelete = (id: string) => setResumesList((prev) => prev.filter((r) => r.id !== id));
  const handleSetDefault = (id: string) => setResumesList((prev) => prev.map((r) => ({ ...r, isDefault: r.id === id })));

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="flex items-center justify-between bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Мои резюме</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">До 5 резюме с разными навыками для разных типов вакансий</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setShowCreate(true); setEditing(null); }} className="flex items-center gap-2 px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all" disabled={resumesList.length >= 5}>
            <Plus size={16} />{resumesList.length >= 5 ? "Лимит" : "Добавить"}
          </button>
        </div>
      </div>

      {/* HH Import Banner */}
      <div className="bg-gradient-to-r from-hf-red/10 to-hf-red/5 border border-hf-red/15 rounded-[10px] p-4 shadow-card">
        <div className="flex items-center justify-between gap-4 flex-col sm:flex-row">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-hf-red/10 border border-hf-red/20 flex items-center justify-center flex-shrink-0">
              <Globe size={20} className="text-hf-red" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-hf-text-primary">Импорт с HH.ru</h3>
              <p className="text-xs text-hf-text-secondary mt-0.5">Автоматический парсинг резюме из вашего аккаунта HH.ru</p>
            </div>
          </div>
          <button onClick={() => setShowHhImport(true)} className="flex items-center gap-2 px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all flex-shrink-0">
            <Download size={14} />Импортировать
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Всего</p>
          <p className="text-2xl font-bold text-hf-text-primary mt-1">{resumesList.length} <span className="text-sm text-hf-text-muted">/ 5</span></p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">По умолчанию</p>
          <p className="text-2xl font-bold text-hf-red mt-1">{resumesList.filter((r) => r.isDefault).length}</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">С HH.ru</p>
          <p className="text-2xl font-bold text-hf-green mt-1">{resumesList.filter((r) => r.source === "hh").length}</p>
        </div>
        <div className="bg-hf-elevated border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
          <p className="text-xs uppercase text-hf-text-secondary tracking-wider">Навыков (ср.)</p>
          <p className="text-2xl font-bold text-hf-cyan mt-1">{Math.round(resumesList.reduce((acc, r) => acc + r.skills.split(",").length, 0) / (resumesList.length || 1))}</p>
        </div>
      </div>

      {showCreate && <ResumeForm onSave={handleCreate} onCancel={() => setShowCreate(false)} />}
      {editing && <ResumeForm initial={editing} onSave={handleUpdate} onCancel={() => setEditing(null)} />}
      {showHhImport && <HhImportModal onClose={() => setShowHhImport(false)} />}

      <div className="space-y-3">
        {resumesList.map((resume) => (
          <ResumeCard key={resume.id} resume={resume} onEdit={setEditing} onDelete={handleDelete} onSetDefault={handleSetDefault} />
        ))}
      </div>
    </div>
  );
}

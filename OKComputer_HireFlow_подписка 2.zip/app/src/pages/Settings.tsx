import { useState } from "react";
import { Save, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import { platformConfig } from "@/lib/data";
import type { JobPlatform } from "@/lib/data";
import { useNavigate } from "react-router";

/*
 * ==========================================
 * УПРОЩЁННЫЕ НАСТРОЙКИ
 * ==========================================
 * Убрано: stealth, прокси, капча, слайдеры задержек, Telegram
 * Оставлено: профиль, поиск, письмо, площадки, простые настройки бота
 */

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  searchQuery: string;
  region: string;
  salaryFrom: string;
  salaryTo: string;
  experience: string;
  remote: boolean;
  coverLetter: string;
  maxApplies: number;
  platforms: Record<JobPlatform, { enabled: boolean; login: string; password: string }>;
}

const allPlatforms = Object.keys(platformConfig) as JobPlatform[];

const initialForm: FormState = {
  fullName: "Иван Петров",
  email: "ivan@example.com",
  phone: "+7 (999) 123-45-67",
  searchQuery: "Python разработчик",
  region: "Москва",
  salaryFrom: "200000",
  salaryTo: "500000",
  experience: "between1And3",
  remote: true,
  coverLetter: `Здравствуйте!\n\nМеня заинтересовала вакансия "{position}" в компании {company}.\n\nУ меня есть релевантный опыт и я хотел бы стать частью вашей команды.\n\nС уважением,\n{candidate_name}`,
  maxApplies: 20,
  platforms: Object.fromEntries(
    allPlatforms.map((p) => [p, { enabled: p === "hh" || p === "zarplata", login: "", password: "" }])
  ) as Record<JobPlatform, { enabled: boolean; login: string; password: string }>,
};

function SectionTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-4">
      <h3 className="text-base font-semibold text-hf-red">{title}</h3>
      {subtitle && <p className="text-xs text-hf-text-secondary mt-0.5">{subtitle}</p>}
    </div>
  );
}

function Input({ label, type = "text", value, onChange, placeholder }: {
  label: string; type?: string; value: string; onChange: (val: string) => void; placeholder?: string;
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      <input
        type={type}
        className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

function PasswordInput({ label, value, onChange }: { label: string; value: string; onChange: (val: string) => void }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">{label}</label>
      <input
        type="password"
        className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

function Toggle({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div onClick={onChange} className={cn("w-10 h-6 rounded-full transition-colors relative flex-shrink-0 mt-0.5", checked ? "bg-hf-red" : "bg-hf-border-subtle")}>
        <span className={cn("absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform", checked ? "translate-x-[18px]" : "translate-x-0.5")} />
      </div>
      <div>
        <span className="text-sm text-hf-text-primary group-hover:text-hf-red transition-colors">{label}</span>
        {description && <p className="text-xs text-hf-text-secondary mt-0.5">{description}</p>}
      </div>
    </label>
  );
}

export default function Settings() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [saved, setSaved] = useState(false);
  const navigate = useNavigate();

  const update = <K extends keyof Omit<FormState, "platforms">>(field: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  };

  const updatePlatform = (platform: JobPlatform, key: "enabled" | "login" | "password", value: boolean | string) => {
    setForm((prev) => ({
      ...prev,
      platforms: { ...prev.platforms, [platform]: { ...prev.platforms[platform], [key]: value } },
    }));
    setSaved(false);
  };

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 3000); };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between bg-white border border-hf-border-subtle rounded-[10px] p-4 shadow-card">
        <div>
          <h2 className="text-base font-semibold text-hf-text-primary">Настройки</h2>
          <p className="text-xs text-hf-text-secondary mt-0.5">Профиль, поиск, площадки</p>
        </div>
        <button onClick={handleSave} className={cn("flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all", saved ? "bg-hf-green text-white" : "bg-hf-red text-white hover:brightness-110")}>
          <Save size={14} />{saved ? "Сохранено!" : "Сохранить"}
        </button>
      </div>

      {/* Profile */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Профиль" subtitle="Ваши контактные данные для откликов" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input label="ФИО" value={form.fullName} onChange={(v) => update("fullName", v)} />
          <Input label="Email" type="email" value={form.email} onChange={(v) => update("email", v)} />
          <Input label="Телефон" value={form.phone} onChange={(v) => update("phone", v)} />
        </div>
      </div>

      {/* Search */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Поиск" subtitle="Какие вакансии искать" />
        <div className="space-y-4">
          <Input label="Ключевые слова" value={form.searchQuery} onChange={(v) => update("searchQuery", v)} placeholder="Python разработчик" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Input label="Регион" value={form.region} onChange={(v) => update("region", v)} />
            <Input label="Зарплата от" type="number" value={form.salaryFrom} onChange={(v) => update("salaryFrom", v)} />
            <Input label="Зарплата до" type="number" value={form.salaryTo} onChange={(v) => update("salaryTo", v)} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Опыт работы</label>
              <select value={form.experience} onChange={(e) => update("experience", e.target.value)} className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red transition-colors">
                <option value="noExperience">Нет опыта</option>
                <option value="between1And3">1-3 года</option>
                <option value="between3And6">3-6 лет</option>
                <option value="moreThan6">Более 6 лет</option>
              </select>
            </div>
            <div className="flex items-center pt-5">
              <Toggle label="Только удалённо" checked={form.remote} onChange={() => update("remote", !form.remote)} />
            </div>
          </div>
        </div>
      </div>

      {/* Cover Letter */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <div className="flex items-center gap-2 mb-3">
          <FileText size={16} className="text-hf-red" />
          <h3 className="text-base font-semibold text-hf-red">Сопроводительное письмо</h3>
        </div>
        <p className="text-xs text-hf-text-secondary mb-3">
          Переменные: {"{company}"}, {"{position}"}, {"{candidate_name}"} — автозамена при отправке
        </p>
        <textarea
          className="w-full bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary placeholder:text-hf-text-muted focus:outline-none focus:border-hf-red transition-colors resize-none"
          rows={6}
          value={form.coverLetter}
          onChange={(e) => update("coverLetter", e.target.value)}
        />
      </div>

      {/* Platforms */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Площадки" subtitle="Выберите, где искать вакансии" />
        <div className="space-y-3">
          {allPlatforms.map((key) => {
            const cfg = platformConfig[key];
            const plat = form.platforms[key];
            return (
              <div key={key} className={cn("border rounded-lg p-3 transition-all", plat.enabled ? "border-hf-red/30 bg-hf-red/[0.02]" : "border-hf-border-subtle")}>
                <div className="flex items-center justify-between">
                  <Toggle label={cfg.label} checked={plat.enabled} onChange={() => updatePlatform(key, "enabled", !plat.enabled)} />
                  <span className={cn("text-[10px] px-2 py-0.5 rounded font-medium", cfg.bg, cfg.color)}>{cfg.domain}</span>
                </div>
                {plat.enabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 pl-[52px]">
                    <Input label={`Логин`} value={plat.login} onChange={(v) => updatePlatform(key, "login", v)} />
                    <PasswordInput label={`Пароль`} value={plat.password} onChange={(v) => updatePlatform(key, "password", v)} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Simple Bot Settings */}
      <div className="bg-white border border-hf-border-subtle rounded-[10px] p-5 shadow-card">
        <SectionTitle title="Настройки бота" subtitle="Простые параметры" />
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-hf-text-secondary uppercase tracking-wider">Макс. откликов за запуск</label>
              <input
                type="number"
                min={1}
                max={50}
                value={form.maxApplies}
                onChange={(e) => update("maxApplies", Number(e.target.value))}
                className="w-20 bg-hf-base border border-hf-border-subtle rounded-lg px-3 py-2 text-sm text-hf-text-primary focus:outline-none focus:border-hf-red"
              />
            </div>
          </div>
          <p className="text-xs text-hf-text-muted">
            Все технические настройки (stealth, задержки, прокси) включены автоматически для безопасной работы.
            AI-анализ и генерация письма используют настройки из профиля.
          </p>
        </div>
      </div>

      {/* Resume link */}
      <div className="bg-hf-red/5 border border-hf-red/20 rounded-[10px] p-4 text-center">
        <p className="text-sm text-hf-text-secondary mb-2">Управление резюме</p>
        <button
          onClick={() => navigate("/resumes")}
          className="px-4 py-2 bg-hf-red text-white text-sm font-medium rounded-lg hover:brightness-110 transition-all"
        >
          Перейти к резюме
        </button>
      </div>
    </div>
  );
}

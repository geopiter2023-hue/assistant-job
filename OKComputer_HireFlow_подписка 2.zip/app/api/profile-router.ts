import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles } from "@db/schema";
import { eq } from "drizzle-orm";

export const profileRouter = createRouter({
  get: publicQuery
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, input.userId));
      return result[0] ?? null;
    }),

  update: publicQuery
    .input(
      z.object({
        userId: z.number(),
        fullName: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        region: z.string().optional(),
        salaryFrom: z.string().optional(),
        salaryTo: z.string().optional(),
        experience: z.string().optional(),
        remoteOnly: z.boolean().optional(),
        coverLetter: z.string().optional(),
        skipCompanies: z.string().optional(),
        hhLogin: z.string().optional(),
        hhPassword: z.string().optional(),
        habrLogin: z.string().optional(),
        habrPassword: z.string().optional(),
        platformHh: z.boolean().optional(),
        platformHabr: z.boolean().optional(),
        telegramToken: z.string().optional(),
        telegramChatId: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const existing = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, input.userId));

      const updateData: Record<string, unknown> = {};
      Object.entries(input).forEach(([key, value]) => {
        if (key !== "userId" && value !== undefined) {
          updateData[key] = value;
        }
      });

      if (existing[0]) {
        await db
          .update(profiles)
          .set(updateData)
          .where(eq(profiles.userId, input.userId));
        return { id: existing[0].id };
      }

      const result = await db.insert(profiles).values({
        userId: input.userId,
        ...updateData,
      }).returning({ id: profiles.id });
      return { id: result[0].id };
    }),
});

import puppeteer from 'puppeteer-core';

async function test() {
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: '/home/kimi/.cache/puppeteer/chrome/linux-148.0.7778.97/chrome-linux64/chrome',
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
  });
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

  console.log('[Test] Navigating to hh.ru...');
  try {
    await page.goto('https://hh.ru/search/vacancy?text=Python&area=1', {
      waitUntil: 'domcontentloaded',
      timeout: 30000,
    });
    console.log('[Test] Page loaded!');
    await new Promise(r => setTimeout(r, 3000));

    const title = await page.title();
    console.log('[Test] Title:', title);

    const links = await page.evaluate(() => {
      return Array.from(document.querySelectorAll('a[href*="/vacancy/"]'))
        .map(a => ({
          text: (a as HTMLElement).innerText?.trim(),
          href: a.getAttribute('href'),
        }))
        .filter(x => x.text && x.text.length > 3);
    });
    console.log('[Test] Found', links.length, 'vacancy links');
    links.slice(0, 5).forEach(l => console.log('  -', l.text?.substring(0, 60)));

  } catch (e) {
    console.error('[Test] Error:', (e as Error).message);
  }
  await browser.close();
}
test();

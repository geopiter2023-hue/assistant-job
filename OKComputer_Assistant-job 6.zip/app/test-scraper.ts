import { searchVacancies, closeBrowser } from './api/scraper';

async function test() {
  try {
    console.log('[Test] Searching HH.ru for "Руководитель проекта"...');
    const results = await searchVacancies('Руководитель проекта', ['hh'], { area: 'Москва' });
    console.log(`\n[Test] Found ${results.length} vacancies with details:`);
    for (const v of results) {
      console.log(`\n  📌 ${v.title}`);
      console.log(`     🏢 ${v.company} | 💰 ${v.salary || 'не указана'} | 📍 ${v.location}`);
      console.log(`     📝 ${v.description?.substring(0, 150)}...`);
      console.log(`     🔗 ${v.url}`);
    }
  } catch (e) {
    console.error('[Test] Error:', (e as Error).message);
  } finally {
    await closeBrowser();
  }
}
test();

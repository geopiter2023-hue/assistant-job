/**
 * Scraper — поиск вакансий через Puppeteer (реальный браузер)
 * Сервер в Москве, HH.ru работает через Puppeteer.
 */

import puppeteer from "puppeteer-core";

export interface ScrapedVacancy {
  id: string;
  title: string;
  company: string;
  salary: string;
  location: string;
  experience: string;
  employment: string;
  description: string;
  requirements: string[];
  responsibilities: string[];
  conditions: string[];
  keySkills: string[];
  url: string;
  platform: string;
  publishedAt: string;
}

// Singleton browser
let browser: puppeteer.Browser | null = null;

async function getBrowser(): Promise<puppeteer.Browser> {
  if (!browser) {
    browser = await puppeteer.launch({
      headless: true,
      executablePath: "/home/kimi/.cache/puppeteer/chrome/linux-148.0.7778.97/chrome-linux64/chrome",
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-web-security",
        "--disable-features=IsolateOrigins,site-per-process",
        "--disable-blink-features=AutomationControlled",
      ],
    });
  }
  return browser;
}

// Поиск на HH.ru
async function searchHhRu(
  query: string,
  options?: { area?: string; salary?: number; experience?: string; remote?: boolean }
): Promise<ScrapedVacancy[]> {
  const vacancies: ScrapedVacancy[] = [];
  let page: puppeteer.Page | null = null;

  try {
    const bw = await getBrowser();
    page = await bw.newPage();
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );
    await page.setExtraHTTPHeaders({
      "Accept-Language": "ru-RU,ru;q=0.9",
    });

    // Блокируем ненужные ресурсы
    await page.setRequestInterception(true);
    page.on("request", (req) => {
      const type = req.resourceType();
      if (["image", "stylesheet", "font", "media"].includes(type)) {
        req.abort();
      } else {
        req.continue();
      }
    });

    const areaId = options?.area === "Санкт-Петербург" ? "2" : "1";
    const searchUrl = `https://hh.ru/search/vacancy?text=${encodeURIComponent(query)}&area=${areaId}&page=0`;

    console.log(`[Scraper] Loading: ${searchUrl}`);
    await page.goto(searchUrl, { waitUntil: "domcontentloaded", timeout: 30000 });
    await new Promise((r) => setTimeout(r, 4000));

    // Парсим вакансии из DOM
    const cards = await page.evaluate(() => {
      const results: any[] = [];

      // Ищем все ссылки на вакансии
      const vacancyEls = document.querySelectorAll('[data-qa="vacancy-serp__vacancy"]');
      vacancyEls.forEach((el) => {
        const titleEl = el.querySelector('[data-qa="vacancy-serp__vacancy-title"]');
        const title = titleEl?.textContent?.trim() || "";
        const href = titleEl?.getAttribute("href") || "";

        const companyEl = el.querySelector('[data-qa="vacancy-serp__vacancy-employer"]');
        const company = companyEl?.textContent?.trim() || "";

        const salaryEl = el.querySelector('[data-qa="vacancy-serp__vacancy-compensation"]');
        const salary = salaryEl?.textContent?.trim() || "";

        const locEl = el.querySelector('[data-qa="vacancy-serp__vacancy-address"]');
        const location = locEl?.textContent?.trim() || "";

        const expEl = el.querySelector('[data-qa="vacancy-serp__vacancy-work-experience"]');
        const experience = expEl?.textContent?.trim() || "";

        if (title && href) {
          results.push({ title, href, company, salary, location, experience });
        }
      });

      // Fallback: ищем по ссылкам
      if (results.length === 0) {
        document.querySelectorAll('a[href*="/vacancy/"]').forEach((a) => {
          const title = a.textContent?.trim() || "";
          const href = a.getAttribute("href") || "";
          if (title.length > 3 && title.length < 100 && !title.includes("hh.ru")) {
            // Ищем родительский элемент для доп. данных
            const parent = a.closest('[class*="vacancy"], [class*="serp-item"]');
            const company = parent?.querySelector('[class*="company"], [class*="employer"]')?.textContent?.trim() || "";
            results.push({ title, href, company, salary: "", location: "", experience: "" });
          }
        });
      }

      return results;
    });

    console.log(`[Scraper] Found ${cards.length} vacancies on search page`);

    // Загружаем детали для каждой вакансии
    for (let i = 0; i < Math.min(cards.length, 10); i++) {
      const card = cards[i];
      try {
        const vid = card.href.match(/\/vacancy\/(\d+)/)?.[1] || String(i);
        const url = card.href.startsWith("http") ? card.href : `https://hh.ru${card.href}`;

        await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
        await new Promise((r) => setTimeout(r, 2500));

        const details = await page.evaluate(() => {
          const descEl = document.querySelector('[data-qa="vacancy-description"]');
          const description = descEl?.textContent?.trim() || "";

          const skills: string[] = [];
          document.querySelectorAll('[data-qa="bloko-tag__text"]').forEach((el) => {
            const t = el.textContent?.trim();
            if (t) skills.push(t);
          });

          const empEl = document.querySelector('[data-qa="vacancy-view-employment-mode"]');
          const employment = empEl?.textContent?.trim() || "Полная занятость";

          return { description, skills, employment };
        });

        const { requirements, responsibilities, conditions } = splitDescription(details.description);

        vacancies.push({
          id: `hh_${vid}`,
          title: card.title,
          company: card.company || "—",
          salary: card.salary || "",
          location: card.location || "",
          experience: card.experience || "",
          employment: details.employment,
          description: details.description,
          requirements,
          responsibilities,
          conditions,
          keySkills: [...new Set(details.skills)],
          url,
          platform: "hh",
          publishedAt: new Date().toISOString(),
        });

        console.log(`[Scraper] ✓ ${card.title} @ ${card.company || "?"}`);
      } catch (e) {
        console.error(`[Scraper] ✗ Error parsing ${card.title}:`, (e as Error).message);
      }
    }

    return vacancies;
  } catch (err) {
    console.error("[Scraper] Error:", (err as Error).message);
    throw err;
  } finally {
    if (page) await page.close();
  }
}

function splitDescription(text: string) {
  const requirements: string[] = [];
  const responsibilities: string[] = [];
  const conditions: string[] = [];

  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  let section = "";

  for (const line of lines) {
    if (/обязанности/i.test(line)) { section = "resp"; continue; }
    if (/требовани/i.test(line)) { section = "req"; continue; }
    if (/услови/i.test(line)) { section = "cond"; continue; }

    if (section === "resp" && line.length > 5) responsibilities.push(line);
    if (section === "req" && line.length > 5) requirements.push(line);
    if (section === "cond" && line.length > 5) conditions.push(line);
  }

  return { requirements, responsibilities, conditions };
}

export async function searchVacancies(
  query: string,
  platforms: string[],
  options?: { area?: string; salary?: number; experience?: string; remote?: boolean }
): Promise<ScrapedVacancy[]> {
  const all: ScrapedVacancy[] = [];

  for (const platform of platforms) {
    try {
      if (platform === "hh") {
        const results = await searchHhRu(query, options);
        all.push(...results);
      } else {
        console.log(`[Scraper] Platform ${platform} not implemented`);
      }
    } catch (err) {
      console.error(`[Scraper] Platform ${platform} error:`, err);
    }
  }

  return all;
}

export async function closeBrowser() {
  if (browser) {
    await browser.close();
    browser = null;
  }
}
